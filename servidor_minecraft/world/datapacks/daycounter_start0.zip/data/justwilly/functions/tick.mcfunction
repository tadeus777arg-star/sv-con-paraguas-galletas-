execute store result score $day daycounter run time query day
title @a actionbar [{"text":"DAY ","color":"white"},{"score":{"objective":"daycounter","name":"$day"}}]
