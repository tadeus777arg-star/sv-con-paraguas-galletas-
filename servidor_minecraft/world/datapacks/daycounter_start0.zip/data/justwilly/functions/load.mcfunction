scoreboard objectives add daycounter dummy
