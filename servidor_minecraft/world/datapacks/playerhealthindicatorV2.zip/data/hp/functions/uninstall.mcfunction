scoreboard objectives remove HP
scoreboard objectives remove uninstall