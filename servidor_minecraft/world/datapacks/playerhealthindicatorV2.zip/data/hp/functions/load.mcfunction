scoreboard objectives add HP health {"color":"red","text":"❤"}
scoreboard objectives setdisplay below_name HP
