#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:netherite_sword",Count:1b,tag:{display:{Name:'{"text":"X-Finity Blade (Chaos)","color":"red","bold":true,"italic":true}'},HideFlags:0,CustomModelData:666445,xbladec:1b,Enchantments:[{id:"minecraft:sharpness",lvl:4s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:unbreaking",lvl:3s}]}}]}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1