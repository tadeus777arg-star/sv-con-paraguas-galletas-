#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:carrot_on_a_stick",Count:1b,tag:{display:{Name:'{"text":"Tome: Overshield"}'},CustomModelData:234446,HideFlags:1,tome_h:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]}}]}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1