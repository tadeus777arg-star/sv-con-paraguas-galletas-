#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge block ~ ~ ~ {Items:[{Slot:4b,id:"minecraft:carrot_on_a_stick",Count:1b,tag:{display:{Name:'{"text":"Staff: Firebender (12 Charges)"}'},CustomModelData:343434,staffd12:1b}}]}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 0.2 1