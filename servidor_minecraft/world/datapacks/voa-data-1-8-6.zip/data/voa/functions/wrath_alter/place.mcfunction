# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:bedrock replace

execute positioned ^ ^ ^0.5 align xyz run summon armor_stand ~ ~ ~ {Fire:9999999,Small:1b,Marker:1b,Invisible:1b,CustomNameVisible:0b,Tags:["wrath_alter"],CustomName:'{"text":"Ancient Force","bold":true,"italic":true}',ArmorItems:[{},{},{},{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:1600000}}]}
scoreboard players add @e[tag=wrath_alter,type=minecraft:armor_stand] harvest_cool 0
kill @s
