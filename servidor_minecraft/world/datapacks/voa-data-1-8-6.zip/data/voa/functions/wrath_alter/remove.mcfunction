#SUMMON DROPS
summon item ~ ~0.5 ~ {Item:{id:"minecraft:item_frame",Count:1b,tag:{display:{Name:'{"text":"Wrath Alter"}'},CustomModelData:1600000,EntityTag:{Silent:1b,Tags:["wrath_alter"],Item:{id:'minecraft:item_frame',Count:1b,tag:{CustomModelData:1600000}},Invulnerable:1b,Invisible:1b,Fixed:1b}}}}


#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:bedrock"}},distance=0..2,sort=nearest,limit=1]


#KILL ITEM FRAME
kill @s