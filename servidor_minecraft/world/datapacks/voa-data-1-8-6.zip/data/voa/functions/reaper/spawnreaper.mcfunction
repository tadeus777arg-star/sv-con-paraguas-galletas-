#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
execute if score out math matches 1 run summon husk ~ ~ ~ {Silent:1b,CustomNameVisible:0b,PersistenceRequired:1b,DeathLootTable:"voa:entities/reaper_loot",Health:30f,CanBreakDoors:1b,DrownedConversionTime:99999,Tags:["reaper"],CustomName:'{"text":"Reaper"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:931022}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:jump_boost",amplifier:1b,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:30},{Name:generic.follow_range,Base:40},{Name:generic.movement_speed,Base:0.20},{Name:generic.attack_damage,Base:16},{Name:zombie.spawn_reinforcements,Base:0}]}

#### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=reaper,type=minecraft:husk,sort=nearest,limit=1] sound_cool 0

#Execute for Spectral-Schimitar
tag @e[tag=reaper,type=minecraft:husk] add ghost

#Kills Marker
tag @s add summoned