#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

tag @s remove frenzied

execute if entity @e[tag=!frenzied,tag=reaper,type=minecraft:husk,sort=nearest,limit=1] run data merge entity @e[tag=!frenzied,tag=reaper,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931022}}],Attributes:[{Name:generic.movement_speed,Base:0.20}]}
particle minecraft:ambient_entity_effect ~ ~ ~ 0 0 0 .15 200
