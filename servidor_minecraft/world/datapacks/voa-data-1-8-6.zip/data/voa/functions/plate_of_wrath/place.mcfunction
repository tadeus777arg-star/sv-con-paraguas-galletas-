# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:quartz_slab
tag @s add placed 



