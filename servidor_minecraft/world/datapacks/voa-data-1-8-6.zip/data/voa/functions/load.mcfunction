#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

tellraw @a {"text":"--- Vaults of Abandon Datapack Loaded ---","color":"green"}

#----------------------------------------------------------------------------------- Scoreboards -----------------------------------------------------------------------------------------------------#
scoreboard objectives add cm_wraith dummy
scoreboard objectives add cm_abomination dummy
scoreboard objectives add cm_abyssalhorror dummy
scoreboard objectives add mob_demo_time dummy
scoreboard objectives add head_animate dummy
scoreboard objectives add harvest_cool dummy
scoreboard objectives add animate dummy
scoreboard objectives add skychecker dummy
scoreboard objectives add timeofday dummy
scoreboard objectives add sound_cool dummy
scoreboard objectives add atk_cool dummy
scoreboard objectives add atk_dash_cool dummy
scoreboard objectives add atk_teleport dummy
scoreboard objectives add atk_flamethrower dummy
scoreboard objectives add atk_snare_cool dummy
scoreboard objectives add boss_cool dummy
scoreboard objectives add boss_health dummy
scoreboard objectives add proxy dummy
scoreboard objectives add proxy_ooze dummy
scoreboard objectives add heal_cool dummy
scoreboard objectives add yposition dummy
scoreboard objectives add xposition dummy
scoreboard objectives add zposition dummy
scoreboard objectives add coaltrain minecraft.used:minecraft.iron_sword
scoreboard objectives add irony minecraft.used:minecraft.iron_sword
scoreboard objectives add embezzler minecraft.used:minecraft.diamond_sword
scoreboard objectives add xblade_d minecraft.used:minecraft.netherite_sword
scoreboard objectives add bonelk minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonelk_cool dummy
scoreboard objectives add boneskt minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesktrld minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesktracking dummy
scoreboard objectives add bonesktready dummy
scoreboard objectives add boneskt_cool dummy
scoreboard objectives add bonespt minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesptrld minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonesptracking dummy
scoreboard objectives add bonesptready dummy
scoreboard objectives add bonespt_cool dummy
scoreboard objectives add bonedoub minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonedrld minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bonedracking dummy
scoreboard objectives add bonedready dummy
scoreboard objectives add d_bone_cool dummy
scoreboard objectives add d_bone_2nd_shot_cool dummy
scoreboard objectives add staff_h_cool dummy
scoreboard objectives add staff_h minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_l_cool dummy
scoreboard objectives add staff_l minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_d_cool dummy
scoreboard objectives add staff_d minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add staff_c_cool dummy
scoreboard objectives add xblade_c_cool dummy
scoreboard objectives add staff_c minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add tome_h minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add tome_c minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add tome_c_cool dummy
scoreboard objectives add tome_l minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add Bdb_x1 dummy
scoreboard objectives add Bdb_y1 dummy
scoreboard objectives add Bdb_z1 dummy
scoreboard objectives add Bdb_x2 dummy
scoreboard objectives add Bdb_y2 dummy
scoreboard objectives add Bdb_z2 dummy
scoreboard objectives add bdb_cool dummy
scoreboard objectives add byb_cool dummy
scoreboard objectives add tf_rc dummy
scoreboard objectives add buildingtime dummy
scoreboard objectives add titanhealth dummy
scoreboard objectives add demonhealth dummy
scoreboard objectives add locketuse minecraft.used:minecraft.totem_of_undying
scoreboard objectives add locket_h_delay dummy
scoreboard objectives add locket_l_delay dummy
scoreboard objectives add locket_c_delay dummy
scoreboard objectives add brooch_h_delay dummy
scoreboard objectives add brooch_l_delay dummy
scoreboard objectives add brooch_c_delay dummy
scoreboard objectives add brooch_d_delay dummy
scoreboard objectives add MotionX dummy
scoreboard objectives add MotionY dummy
scoreboard objectives add MotionZ dummy
scoreboard objectives add PowerX dummy
scoreboard objectives add PowerY dummy
scoreboard objectives add PowerZ dummy

#----------------------------------------------------------------------------------- GENERATION Scoreboards -----------------------------------------------------------------------------------------------------#
scoreboard objectives add coords dummy
scoreboard objectives add constant dummy 
scoreboard players set #16 constant 16
scoreboard objectives add surfacecheck dummy
scoreboard objectives add biome dummy

#----------------------------------------------------------------------------------- Random Logic Scoreboards --------------------------------------------------------------------------------------------------------#
scoreboard objectives add dist dummy
scoreboard objectives add math dummy
scoreboard players reset * dist
scoreboard objectives add constant dummy
scoreboard players set #2 constant 2
scoreboard players set #lcg constant 1103515245

#----------------------------------------------------------------------------------- Natural Generation ---------------------------------------------------------------------------------------------#
##--- Monastery Spawn - Start ---##
#Monastery Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spawnoblisk"]}} 1
##--- Monastery Spawn End ---##

##--- Monastery QC Marker - Start ---##
#Monastery Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{display:{Name:'{"text":"Oblisk QC"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["obliskqc"]}} 1
##--- Monastery Spawn End ---##

##--- Manor1 Spawn - Start ---##
#Manor1 Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{display:{Name:'{"text":"Manor1"}'},EntityTag:{Tags:["spawnmanor1"]}} 1
##--- Manor1 Spawn End ---##

##--- Manor2 Spawn - Start ---##
#Manor2 Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{display:{Name:'{"text":"Manor2"}'},EntityTag:{Tags:["spawnmanor2"]}} 1
##--- Manor2 Spawn End ---##

##--- Manor3 Spawn - Start ---##
#Manor3 Spawn - Armor Stand Item -- THIS KICKSTARTS THE WHOLE Structure Generation
#/give @p armor_stand{display:{Name:'{"text":"Manor3"}'},EntityTag:{Tags:["spawnmanor3"]}} 1
##--- Manor2 Spawn End ---##

#----------------------------------------------------------------------------------- Structure Generation - Fixes - Sponges ----------------------------------------------------------------------------------#

##Sponge-hall
#/give @p armor_stand{display:{Name:'{"text":"Sponge-Hallway"}'},EntityTag:{Tags:["spongehall"]}} 1

##Sponge-hall-endcap (bottom floor)
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Bottom"}'},EntityTag:{Tags:["spongecapbottom"]}} 1

##Sponge-hall-endcap (middle/upper floor)
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Middle"}'},EntityTag:{Tags:["spongecapmidtop"]}} 1

##Sponge-hall-PLAYER
#/give @p armor_stand{display:{Name:'{"text":"Sponge-Hallway-PLAYER"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spongehallplayer"]}} 1

##Sponge-hall-endcap (bottom floor)-PLAYER
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Bottom-PLAYER"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spongecapbottomplayer"]}} 1

##Sponge-hall-endcap (middle/upper floor)-PLAYER
#give @p armor_stand{display:{Name:'{"text":"Sponge-Endcap-Middle-PLAYER"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["spongecapmidtopplayer"]}} 1

##Sponge-ENTRY STAIRS
#/give @p armor_stand{display:{Name:'{"text":"Basement_sponge_monastery"}'},EntityTag:{Tags:["basement_sponge_monastery"]}} 1


#----------------------------------------------------------------------------------- Structure Generation - Manor - ROOMS ----------------------------------------------------------------------------------#

##Tnt-hall
#/give @p armor_stand{display:{Name:'{"text":"tntHall"}'},EntityTag:{Tags:["tnthall"]}} 1
#East West
#/give @p armor_stand{display:{Name:'{"text":"tntHallEW"}'},EntityTag:{Tags:["tnthallew"]}} 1

##Manor Distance Stopper - Set in surfance_manor
#/summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["manor"]}


#----------------------------------------------------------------------------------- Structure Generation - Monastery - ROOMS ----------------------------------------------------------------------------------#
##--- 9x9 Oblisk Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"9x9Oblisk"}'},EntityTag:{Tags:["9x9oblisk"]}} 1

##--- Tower Oblisk Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"towerOblisk"}'},EntityTag:{Tags:["toweroblisk"]}} 1

##--- Garden Oblisk Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Garden Oblisk"}'},EntityTag:{Tags:["gardenoblisk"]}} 1

##--- Vault-BASEMENT-Start Oblisk Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-Start"}'},EntityTag:{Tags:["vaultstart"]}} 1


#----------------------------------------------------------------------------------- Structure Generation - VAULT BRICK LAYER - ROOMS ----------------------------------------------------------------------------------#
##--- Vault-NORTH-Hallway Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-North-Hallway"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["vaultnorthhallway"]}} 1

##--- Vault-NORTH-Hallway Marker - QC CAP ----##
#/give @p armor_stand{display:{Name:'{"text":"North QC Cap"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:0b,NoBasePlate:1b,Tags:["qcnorth"]}} 1

##--- Vault-SOUTH-Hallway Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-South-Hallway"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["vaultsouthhallway"]}} 1

##--- Vault-SOUTH-Hallway Marker - QC CAP ----##
#/give @p armor_stand{display:{Name:'{"text":"South QC Cap"}'},EntityTag:{NoGravity:1b,Marker:1b,Invisible:0b,NoBasePlate:1b,Tags:["qcsouth"]}} 1

##--- Vault-EW-Hallway Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault-EASTWEST-Hallway"}'},EntityTag:{Tags:["vaulteastwesthallway"]}} 1

##--- 7x7 Small Brick Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"7x7Small Brick Room"}'},EntityTag:{Tags:["7x7sbr"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"7x7Small Brick Room East-West"}'},EntityTag:{Tags:["7x7sbrew"]}} 1

##--- 10x10 Large Brick Room Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"10x10 Large Brick Room"}'},EntityTag:{Tags:["10x10lbr"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"10x10 Large Brick Room East-West"}'},EntityTag:{Tags:["10x10lbrew"]}} 1

##--- Stairs Brick Layer Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Stairs Brick Layer"}'},EntityTag:{Tags:["sbl"]}} 1

##--- Vault Piece Brick Layer Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Vault Piece Brick Layer"}'},EntityTag:{Tags:["5x5vp"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"Vault Piece Brick Layer East-West"}'},EntityTag:{Tags:["5x5vpew"]}} 1

##--- Fort - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Fort Room"}'},EntityTag:{Tags:["fort"]}} 1

##--- Fort Bossroom - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Boss Fort Room"}'},EntityTag:{Tags:["fortboss"]}} 1


#----------------------------------------------------------------------------------- Structure Generation - BASEMENT - ROOMS ----------------------------------------------------------------------------------#

##--- Basement Main - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Basement"}'},EntityTag:{Tags:["basement"]}} 1

##--- Basement Main - Rooms ----##
#/give @p armor_stand{display:{Name:'{"text":"Basement_room"}'},EntityTag:{Tags:["basement_room"]}} 1

##--- Basement Main - Sponge ----##
#/give @p armor_stand{display:{Name:'{"text":"Basement_sponge"}'},EntityTag:{Tags:["basement_sponge"]}} 1

#----------------------------------------------------------------------------------- Structure Generation - Monolith - Spawn ----------------------------------------------------------------------------------#

##--- Monolith Main - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Monolith_Start"}'},EntityTag:{Tags:["monolith_start"]}} 1

##--- Monolith Section 2 - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Monolith_Section_2"}'},EntityTag:{Tags:["monolith_2"]}} 1

##--- Monolith Section 3 - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Monolith_Section_3"}'},EntityTag:{Tags:["monolith_3"]}} 1

#----------------------------------------------------------------------------------- Structure Generation - Market - Spawn ----------------------------------------------------------------------------------#

##--- Market Main - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Start"}'},EntityTag:{Tags:["market_start"]}} 1

##--- Market - Obsidian Core - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Obi"}'},EntityTag:{Tags:["market_obi"]}} 1

##--- Market - Stall - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Stall"}'},EntityTag:{Tags:["market_stall"]}} 1

##--- Market - Long - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Long"}'},EntityTag:{Tags:["market_long"]}} 1

##--- Market - Large - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Large"}'},EntityTag:{Tags:["market_large"]}} 1

##--- Market - Dark Room - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"Market_Dark"}'},EntityTag:{Tags:["market_dark"]}} 1

##Market Distance Stopper - Set in surface_end
#/summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["market"]}

#----------------------------------------------------------------------------------- Spanwers  --------------------------------------------------------------------------------------------------------#
##--- Full Spawner - 100% to Spawn - (Spawns Zombie, Skeleton, Knight)
#/give @p armor_stand{display:{Name:'{"text":"100 Full Spawner"}'},EntityTag:{Tags:["100fullspawner"]}} 1

##--- 75% Per Spawner - 75% to Spawn - (Spawns Zombie, Skeleton, Knight)
#/give @p armor_stand{display:{Name:'{"text":"75 Full Spawner"}'},EntityTag:{Tags:["75fullspawner"]}} 1

##--- 50 Per Spawner - 50% to Spawn - (Spawns Zombie, Skeleton, Knight)
#/give @p armor_stand{display:{Name:'{"text":"50 Per Spawner"}'},EntityTag:{Tags:["50perspawner"]}} 1

##--- Pest Spawner - 50% to Spawn - (Spawns SilverFish, Spider, CaveSpider)
#/give @p armor_stand{display:{Name:'{"text":"Pest Spawner"}'},EntityTag:{Tags:["pestspawner"]}} 1

#----------------------------------------------------------------------------------- Custom Mobs ------------------------------------------------------------------------------------------------------#
##--- Wraith Mob START ##
# Fake player Scores for keeping track of Wraith
# Increases every eligible mob scanned
scoreboard players add wraith_count cm_wraith 0
#/give @p armor_stand{display:{Name:'{"text":"Wraith-Spawn-100"}'},EntityTag:{Tags:["spawnwraith100"]}} 1
##--- Wraith Mob END! ##


##--- Spectre Mob START ##
#--- Vault-Spectre - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Spectre-Spawn"}'},EntityTag:{Tags:["spawnspectre"]}} 1
#/give @p armor_stand{display:{Name:'{"text":"Spectre-Spawn-100"}'},EntityTag:{Tags:["spawnspectre100"]}} 1
##--- Spectre Mob END! ##


##--- Reaper Mob START ##
#--- Vault-Spectre - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Reaper-Spawn"}'},EntityTag:{Tags:["spawnreaper"]}} 1
##--- Reaper Mob END! ##


##--- Abomination Mob START ###
# Fake player Scores for keeping track of Abomination
# Increases every eligible mob scanned
scoreboard players add abomination_count cm_abomination 0
#Abomination Spawn END! ##
##--- Abomination Mob END! ##


##--- Gila Monster Mob START ##
#--- Gila Monster - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Gila Monster - Spawn"}'},EntityTag:{Tags:["spawngila"]}} 1
##--- Gila Monster Mob END! ##


##--- Abyssal Horror Mob START ###
#placeholder until spawn function is implemented
# Fake player Scores for keeping track of Abyssal Horror
# Increases every eligible mob scanned
scoreboard players add abyssalhorror_count cm_abyssalhorror 0
##--- Abyssal Horror Mob END! ##


##--- Legionnaire Brute START ##
#--- Legionnaire Brute - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Legionnaire-Brute-Spawn"}'},EntityTag:{Tags:["legionbrute"]}} 1
##--- Legionnaire Brute END! ##


##--- Grotesque Titan Mob START ##
#--- Vault-GT - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Grotesque-Titan-Spawn"}'},EntityTag:{Tags:["spawntitan"]}} 1
##--- Grotesque Titan Mob END! ##


##--- Wraped Titan Mob START ##
#--- Vault-WT - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Warped-Titan-Spawn"}'},EntityTag:{Tags:["spawnwarpedtitan"]}} 1
##--- Warped Titan Mob END! ##


##--- Axolotl Mob Chance START ##
#--- Axolotl - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Axo-Spawn"}'},EntityTag:{Tags:["axochance"]}} 1
##--- Axolotl Mob Chance END! ##


##---Willowbee Spawn Egg#
#/give @p phantom_spawn_egg{display:{Name:'{"text":"Willowbee Spawn Egg"}'},CustomModelData:555576,EntityTag:{Tags:["willowbeeegg"]}} 1
##-NEW EGG - USE THIS MODEL!
#/give @p armor_stand{display:{Name:'{"text":"Willowbee Spawn Egg"}'},CustomModelData:100100,EntityTag:{Tags:["willowbeeegg"]}} 1
##---Willowbee Spawn Egg END! ##


##--- Dream_Eater START ##
#--- Legionnaire Brute - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Dream-Eater-Spawn"}'},EntityTag:{Tags:["spawndreameater"]}} 1
##--- Dream_Eater END! ##


##--- Shopkeeper NorthSouth Marker Only - lbr17
#/give @p armor_stand{display:{Name:'{"text":"Shopkeeper"}'},EntityTag:{Tags:["shopkeeper"]}} 1

##--- MACRO CREEPERS
#/give @p armor_stand{display:{Name:'{"text":"Macro_Creeper"}'},EntityTag:{Tags:["marco_creeper"]}} 1


##--- Flower  - BOSS - START ###
#Flower Boss Bar
bossbar add bossbar:flower "Flower"
bossbar set bossbar:flower color blue
bossbar set bossbar:flower style notched_6
bossbar set bossbar:flower max 800
##--- Flower - BOSS - END ###

##--- Nether_demon  - BOSS - START ###
#Nether_Demon Boss Bar
bossbar add bossbar:nether_demon "Tzeench - Nether Demon"
bossbar set bossbar:nether_demon color red
bossbar set bossbar:nether_demon style notched_6
bossbar set bossbar:nether_demon max 300
##--- Nether_demon - BOSS - END ###

##--- Ender_demon - BOSS - START ###
#/give @p armor_stand{display:{Name:'{"text":"Ender Demon"}'},EntityTag:{Tags:["spawnenderdemon"]}} 1
##--- WAKE-UP Marker- 
#/give @p armor_stand{display:{Name:'{"text":"Wake-Up-Demon"}'},Marker:1b,NoBasePlate:1b,NoGravity:1b,EntityTag:{Invisible:1b,Tags:["wakeup"]}} 1
##--- Market Gas Main Dropdown Blocker Marker- 
#/give @p armor_stand{display:{Name:'{"text":"Market_Main_Dropdown_Gas"}'},EntityTag:{NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["wakeup_dropdown"]}} 1
##--- WAKE-UP MIDDLE Marker- 
#/give @p armor_stand{display:{Name:'{"text":"Wake-Up-Demon-MIDDLE"}'},EntityTag:{NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["wakeup","wakeup_middle"]}} 1
##--- Ender_demon  - BOSS - START ###
#Nether_Demon Boss Bar
bossbar add bossbar:ender_demon "Greedox - Ender Demon"
bossbar set bossbar:ender_demon color red
bossbar set bossbar:ender_demon style notched_6
bossbar set bossbar:ender_demon max 750
##--- Ender_demon - BOSS - END ###


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ End Dimension ENEMIES (Market/Monolith)---#

##--- Ethereal Single Spawn - (Armor Stand Spawn) ##
#--- Ethereal Spawner - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Ethereal-Spawn"}'},EntityTag:{Tags:["legendaryspawn"]}} 1
##--- Ethereal Brute END! ##

##--- Ethereal Pirate Single Spawn - (Armor Stand Spawn) ##
#--- Ethereal Pirate Spawner - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Ethereal-Pirate-Spawn"}'},EntityTag:{Tags:["legendarypiratespawn"]}} 1
##--- Ethereal Brute END! ##

##--- Common End Spawner - (Spawner)
#/give @p armor_stand{display:{Name:'{"text":"Common End Spawner"}'},EntityTag:{Tags:["commonendspawner"]}} 1

##--- Enchanted Brew - (Armor Stand Spawn) ##
#/give @p armor_stand{display:{Name:'{"text":"Enchanted Brew"}'},EntityTag:{Tags:["brewspawn"]}} 1

##--- Shulker - (Armor Stand Spawn) ##
#/give @p armor_stand{display:{Name:'{"text":"Shulker- Spawn"}'},EntityTag:{Tags:["shulkerspawn"]}} 1

##--- Endermite Spawner - (Armor Stand Spawn) ##
#/give @p armor_stand{display:{Name:'{"text":"Endermite Spawner"}'},EntityTag:{Tags:["endermitespawn"]}} 1


#----------------------------------------------------------------------------------- Alters/Plates ----------------------------------------------------------------------------------------------------#
##Plates------------------------- ##
##--- Plate of Weath#
#THIS CODE BELOW WAS PRIMARILY USED FOR TESTING ITEM UPON RELOADING THE DATAPACK!#
#/give @p item_frame{display:{Name:'{"text":"Plate of Wealth"}'},CustomModelData:222223,EntityTag:{Silent:1b,Tags:["wealth"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:222223}},Invulnerable:1b,Invisible:1b,Fixed:1b,Facing:1}} 1
#Summon Code - Chance to spawn Plate
#/give @p armor_stand{display:{Name:'{"text":"Wealth Plate Oblisk"}'},EntityTag:{Tags:["wealthplateOblisk"]}} 1
##Weath Plate END! ##

##--- Plate of Wrath ##
#THIS CODE BELOW WAS PRIMARILY USED FOR TEST UPON RELOADING THE DATAPACK!#
#give @p item_frame{display:{Name:'{"text":"Plate of Wrath"}'},CustomModelData:222222,EntityTag:{Silent:1b,Tags:["wrath"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:222222}},Invulnerable:1b,Invisible:1b,Fixed:1b,Facing:1}} 1
#Summon Code - Chance to spawn Plate
#/give @p armor_stand{display:{Name:'{"text":"Wrath Plate Oblisk"}'},EntityTag:{Tags:["wrathplateOblisk"]}} 1
##Plate of Wrath END! ##



##Alters------------------------- ##

##--- Wealth Alter Block#
#/give @p item_frame{display:{Name:'{"text":"Alter of Wealth"}'},CustomModelData:151111,EntityTag:{Silent:1b,Tags:["wealth_alter"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:151111}},Invulnerable:1b,Invisible:1b,Fixed:1b}} 1
#--- Wealth Alter Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"wealthOblisk"}'},EntityTag:{Tags:["wealthOblisk"]}} 1
#Wealth Alter Block END! ##
##--- Alter of Wealth END! ##

##--- Wrath Alter Block#
#/give @p item_frame{display:{Name:'{"text":"Wrath Alter"}'},CustomModelData:1600000,EntityTag:{Silent:1b,Tags:["wrath_alter"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:1600000}},Invulnerable:1b,Invisible:1b,Fixed:1b}} 1
#--- Wrath Alter Marker - Start ----##
#/give @p armor_stand{display:{Name:'{"text":"wrathOblisk"}'},EntityTag:{Tags:["wrathOblisk"]}} 1
#Wrath Alter Block END! ##


#----------------------------------------------------------------------------------- ESSENCE ----------------------------------------------------------------------------------------------------------#

##---Chaos Essence ##
#give @p red_dye{display:{Name:'{"text":"Chaos Essence"}'},CustomModelData:131313,chaos:1b} 1
##---Chaos Essence END!##


##---Harmony Essence ##
#give @p blue_dye{display:{Name:'{"text":"Harmony Essence"}'},CustomModelData:141414,harmony:1b} 1
##---Harmony Essence END!##


##---Lucky Essence ##
#give @p yellow_dye{display:{Name:'{"text":"Lucky Essence"}'},CustomModelData:151515,lucky:1b} 1
##---Lucky Essence END!##


#----------------------------------------------------------------------------------- ORBS/Runes --------------------------------------------------------------------------------------------------------#

##Rune Core ##
#give @p white_dye{display:{Name:'{"text":"Rune Core"}'},CustomModelData:331313,rune:1b} 1
##Rune Core END!##


##Chaos Orb ##
#give @p red_dye{display:{Name:'{"text":"Chaos Orb"}'},CustomModelData:231313,chaos_orb:1b} 1
##Chaos Orb END!##


##Harmony Orb ##
#give @p blue_dye{display:{Name:'{"text":"Harmony Orb"}'},CustomModelData:241414,harmony_orb:1b} 1
##Harmony Orb END!##


##Lucky Orb ##
#give @p yellow_dye{display:{Name:'{"text":"Lucky Orb"}'},CustomModelData:251515,lucky_orb:1b} 1
##Lucky Orb END!##


##Dangerous Orb ##
#give @p orange_dye{display:{Name:'{"text":"Dangerous Orb"}'},CustomModelData:251515,dangerous_orb:1b} 1
##Dangerous Orb END!##


#----------------------------------------------------------------------------------- Magic Staffs -------------------------------------------------------------------------------------------------------#

##Basic Staff ##
#/give @p stick{display:{Name:'{"text":"Unenchanted Staff"}'},CustomModelData:303030,staff:1b} 1
##Basic Staff END! ##


##Chaos Staff ## STILL NEED TO BE CHANGED UP
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: Levitate (12 Charges)"}'},CustomModelData:313131,staffc12:1b} 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_c_cool 0
##Chaos Staff END! ##


##Harmoneous Staff ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: First Aid (12 Charges)"}'},CustomModelData:323232,staffh12:1b} 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_h_cool 0
##Harmoneous Staff END! ##


##Lucky Staff ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: Chicken Claw (12 Charges)"}'},CustomModelData:333333,staffl12:1b} 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_l_cool 0
##Lucky Staff END! ##


##Dangerous Staff ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: Firebender (12 Charges)"}'},CustomModelData:343434,staffd12:1b} 1
##### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
#Initializes scoreboard so the player can use.
scoreboard players add @a staff_d_cool 0
##Dangerous Staff END! ##


#----------------------------------------------------------------------------------- X-Finity Blade -------------------------------------------------------------------------------------------------------#

##--- X-Finity Blade (Coreless) ##
#/give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Coreless)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666444,xblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s}]} 1
##--- X-Finity Blade (Coreless) ##


##--- X-Finity Blade (Chaos) ##
#/give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Chaos)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666445,xbladec:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:sweeping",lvl:2s}]} 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_c_cool 0
###--- X-Finity Blade (Chaos) ## END! ##


#####--- X-Finity Blade (Harmony) ## ##
#/give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Harmony)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666447,xbladeh:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:smite",lvl:2s}]} 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_h_cool 0
#####--- X-Finity Blade (Harmony) ## ## END! ##


#####--- X-Finity Blade (Lucky) ## 
#/give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Lucky)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666446,xbladel:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:looting",lvl:2s}]} 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_l_cool 0
#####--- X-Finity Blade (Lucky) ## 


#####--- X-Finity Blade (Dangerous) ## ##
#/give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Dangerous)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666448,xbladed:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:fire_aspect",lvl:2s}]} 1
###### NEED TO SET UP THE CODE BELOW FOR STAFF VVV ##### 
##Initializes scoreboard so the player can use.
#scoreboard players add @a staff_d_cool 0
#####--- X-Finity Blade (Dangerous) END! ##

#----------------------------------------------------------------------------------- Magic Tome -------------------------------------------------------------------------------------------------------#

##Magic Tome ##
#/give @p book{display:{Name:'{"text":"Magic Tome"}'},HideFlags:1,CustomModelData:234444,tome:1b} 1


##Chaos Tome ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Tome: Stasis Field"}'},HideFlags:1,CustomModelData:234445,tome_c:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]} 1
scoreboard players add @a tome_c_cool 0


##Harmoneous Tome ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Tome: Overshield"}'},HideFlags:1,CustomModelData:234446,tome_h:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]} 1


##Lucky Tome ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Tome: Ring of Rabbit"}'},HideFlags:1,CustomModelData:234447,tome_l:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]} 1

#----------------------------------------------------------------------------------- Lockets ----------------------------------------------------------------------------------------------------------#

##Locket ##
#/give @p stick{display:{Name:'{"text":"Void Locket (Uncharged)"}'},CustomModelData:313131,locket:1b} 1
##Locket ##

##Chaos locket ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Locket (Chaos)","color":"dark_red","italic":true}'},CustomModelData:343434,chaos_locket:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.movement_speed",Name:"generic.movement_speed",Amount:.03,Operation:0,UUID:[I;636540408,-1416674768,-1872543044,1476573078],Slot:"offhand"}]} 1
##Locket ##

##Harmony locket ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Locket (Harmony)","color":"dark_blue","italic":true}'},CustomModelData:323232,harmony_locket:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.max_health",Name:"generic.max_health",Amount:2,Operation:0,UUID:[I;-1469019499,132926910,-1900573208,-1526803814],Slot:"offhand"}]} 1
##Locket ##

##Lucky locket ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Locket (Lucky)","color":"gold","italic":true}'},CustomModelData:333333,lucky_locket:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"generic.attack_damage",Amount:2,Operation:0,UUID:[I;1995580107,1582252514,-1124160897,1922393043],Slot:"offhand"}]} 1
##Locket ##

#----------------------------------------------------------------------------------- Brooches ----------------------------------------------------------------------------------------------------------#

##Brooch ##
#/give @p stick{display:{Name:'{"text":"Void Brooch (Uncharged)"}'},CustomModelData:310000,brooch:1b} 1
##Locket ##

##Chaos Brooch ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Brooch (Chaos)","color":"dark_red","italic":true}'},CustomModelData:310003,chaos_brooch:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.movement_speed",Name:"generic.movement_speed",Amount:.03,Operation:0,UUID:[I;1835196807,949242174,-1918275355,-719654972],Slot:"offhand"},{AttributeName:"generic.max_health",Name:"generic.max_health",Amount:2,Operation:0,UUID:[I;-547430598,-850049035,-1937997458,1780123303],Slot:"offhand"}]} 1
##Locket ##

##Harmony Brooch ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Brooch (Harmony)","color":"dark_blue","italic":true}'},CustomModelData:310001,harmony_brooch:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.max_health",Name:"generic.max_health",Amount:2,Operation:0,UUID:[I;302782504,-2096215402,-1533302072,-1217361833],Slot:"offhand"},{AttributeName:"generic.attack_speed",Name:"generic.attack_speed",Amount:.15,Operation:0,UUID:[I;-1961732271,-1609151555,-1641685806,314239344],Slot:"offhand"}]} 1
##Locket ##

##Lucky Brooch ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Brooch (Lucky)","color":"gold","italic":true}'},CustomModelData:310002,lucky_brooch:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"generic.attack_damage",Amount:2,Operation:0,UUID:[I;-1315921611,-1924316329,-1982917647,1228809139],Slot:"offhand"},{AttributeName:"generic.max_health",Name:"generic.max_health",Amount:2,Operation:0,UUID:[I;-1385731152,-1461695934,-1955120564,-183675435],Slot:"offhand"}]} 1
##Locket ##

##Dangerous Brooch ##
#/give @p totem_of_undying{display:{Name:'{"text":"Void Brooch (Dangerous)"}'},CustomModelData:310004,dangerous_brooch:1b,Enchantments:[{}],AttributeModifiers:[{AttributeName:"generic.max_health",Name:"generic.max_health",Amount:2,Operation:0,UUID:[I;355943829,2003650051,-2027521901,-962241686],Slot:"offhand"},{AttributeName:"generic.attack_damage",Name:"generic.attack_damage",Amount:2,Operation:0,UUID:[I;-806249531,-225950427,-1589168482,1315328606],Slot:"offhand"},{AttributeName:"generic.movement_speed",Name:"generic.movement_speed",Amount:.03,Operation:0,UUID:[I;-1215083307,725766135,-1356371452,1210592881],Slot:"offhand"},{AttributeName:"generic.attack_speed",Name:"generic.attack_speed",Amount:.15,Operation:0,UUID:[I;1771305129,539512816,-1637982716,1155211467],Slot:"offhand"}]} 1
##Locket ##

#----------------------------------------------------------------------------------- Items -----------------------------------------------------------------------------------------------------------#

##--- Bonelock ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Bonelock Pistol"}'},CustomModelData:977777,bonelock:1b} 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a bonelk_cool 0
##--- Bonelock END! ##


##--- Bonesket ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Bonesket"}'},HideFlags:1,CustomModelData:977778,bonesket:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s},{id:"minecraft:sharpness",lvl:3s}]} 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a boneskt_cool 0
scoreboard players add @a bonesktready 0
scoreboard players add @a bonesktracking 0
##--- Bonesket END! ##


##--- Bonesplitter ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Bonesplitter"}'},HideFlags:1,CustomModelData:888888,bonesplitter:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s}]} 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a bonespt_cool 0
scoreboard players add @a bonesptready 0
scoreboard players add @a bonesptracking 0
##--- Bonesplitter END! ##


##--- Double-Bone ##
#/give @p carrot_on_a_stick{display:{Name:'{"text":"Double-Bone-87"}'},HideFlags:1,CustomModelData:888900,dbone:1b} 1
#Initializes scoreboard so the player can shoot.
scoreboard players add @a d_bone_cool 0
scoreboard players add @a bonedready 0
scoreboard players add @a bonedracking 0
scoreboard players add @a d_bone_2nd_shot_cool 0
##--- Double-Bone END! ##


##--- Boneshot (Ammo for Bone Weapons) ##
#/give @p stick{display:{Name:'{"text":"boneshot"}'},CustomModelData:262626,boneshot:1b} 3
##--- Bonelock END! ##


##--- Bone Dust Bomb ##
#/give @p snowball{display:{Name:'{"text":"Bone Dust Bomb"}'},CustomModelData:100421,bdb:1b} 1
##--- Bone Dust Bomb END! ##


##--- Dyna Bomb ##
#/give @p snowball{display:{Name:'{"text":"Dyna-Bomb"}'},CustomModelData:100422,bynab:1b} 1
##--- Dyna Bomb END! ##


##--- Skeel Blade ##
#THIS CODE BELOW WAS PRIMARILY USED FOR TESTING ITEM UPON RELOADING THE DATAPACK!#
#give @p iron_sword{display:{Name:'{"text":"Skeel Blade","bold":true,"italic":true}'},HideFlags:1,Unbreakable:0b,Damage:1.0,CustomModelData:555555,skeelblade:1b,Enchantments:[{id:"minecraft:knockback",lvl:3s},{id:"minecraft:sweeping",lvl:4s}]} 1
#/give @p diamond_sword{display:{Name:'{"text":"Elite Skeel Blade","bold":true,"italic":true}'},HideFlags:1,Unbreakable:0b,Damage:1.0,CustomModelData:555556,eliteskeelblade:1b,Enchantments:[{id:"minecraft:knockback",lvl:4s},{id:"minecraft:sweeping",lvl:5s}]} 1
#/give @p netherite_sword{display:{Name:'{"text":"Ultimate Skeel Blade","bold":true,"italic":true}'},HideFlags:1,Unbreakable:0b,CustomModelData:555557,ulitimateskeelblade:1b,Enchantments:[{id:"minecraft:knockback",lvl:5s},{id:"minecraft:sweeping",lvl:6s}]} 1
##--- Skeel Blade END! ##


##--- Pestkeeper ##
#/give @p iron_sword{display:{Name:'{"text":"Pest Keeper","bold":true,"italic":true}'},HideFlags:1,CustomModelData:555557,pestkeeper:1b,Enchantments:[{id:"minecraft:sharpness",lvl:1s},{id:"minecraft:bane_of_arthropods",lvl:5s},{id:"minecraft:sweeping",lvl:4s},{id:"minecraft:unbreaking",lvl:2s}]} 1
scoreboard players add @a irony 0
##--- Pestkeeper END! ##


##--- Coal-Train ##
#/give @p iron_sword{display:{Name:'{"text":"Coal Train","bold":true,"italic":true}'},HideFlags:1,CustomModelData:555559,coaltrain:1b,Enchantments:[{id:"minecraft:sharpness",lvl:2s},{id:"minecraft:fire_aspect",lvl:3s},{id:"minecraft:knockback",lvl:2s},{id:"minecraft:unbreaking",lvl:2s}]} 1
scoreboard players add @a coaltrain 0
##--- Pestkeeper END! ##


##--- Spectral-Schimitar ##
#/give @p netherite_sword{display:{Name:'{"text":"Spectral-Scimitar","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666333,schimitar:1b,Enchantments:[{id:"minecraft:smite",lvl:5s},{id:"minecraft:sweeping",lvl:4s},{id:"minecraft:unbreaking",lvl:5s}]} 1
##--- Spectral-Schimitar END! ##


##--- Cakeblade ##
#/give @p diamond_sword{display:{Name:'{"text":"Cake Blade","bold":true,"italic":true}'},HideFlags:1,CustomModelData:355557,cakeblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:looting",lvl:3s},{id:"minecraft:mending",lvl:1s}]} 1
##--- CakeBlade END! ##


##--- Cookie Monster ##
#/give @p netherite_sword{display:{Name:'{"text":"Cookie Monster","bold":true,"italic":true}'},HideFlags:0,CustomModelData:500001,cookieblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:5s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:looting",lvl:3s},{id:"minecraft:unbreaking",lvl:3s}]} 1
##--- Cookie Monster END! ##


##--- Embezzler ##
#/give @p diamond_sword{display:{Name:'{"text":"Emerald Embezzler","bold":true,"italic":true}'},HideFlags:1,CustomModelData:555559,emeraldblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:looting",lvl:3s},{id:"minecraft:mending",lvl:1s}]} 1
scoreboard players add @a embezzler 0
##--- Embezzler END! ##


##--- Psionic Sabre ##
#/give @p netherite_sword{display:{Name:'{"text":"Psionic Sabre","bold":true,"italic":true}'},HideFlags:0,CustomModelData:500000,psi_sabre:1b,Enchantments:[{id:"minecraft:sharpness",lvl:6s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:unbreaking",lvl:3s}]} 1
##--- Psionic Sabre END! ##


##--- Ice Sword ##
#/give @p netherite_sword{display:{Name:'{"text":"Ice Sword","bold":true,"italic":true}'},HideFlags:0,CustomModelData:500002,ice_sword:1b,Enchantments:[{id:"minecraft:sharpness",lvl:6s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:unbreaking",lvl:3s}]} 1
##--- Ice Sword END! ##


##--- Magic Bench Block#
#/give @p item_frame{display:{Name:'{"text":"Magic Bench"}'},CustomModelData:727272,EntityTag:{Silent:1b,Tags:["magic_bench"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:727272}},Invulnerable:1b,Invisible:1b,Fixed:1b}} 1
#Summon Code - Chance MAGIC BENCH
#/give @p armor_stand{display:{Name:'{"text":"Magic Bench Marker"}'},EntityTag:{Tags:["magicbenchmarker"]}} 1
##--- Magic Bench Block END! ##


##--- Enchancting Table Chance Marker# - lbr2
#/give @p armor_stand{display:{Name:'{"text":"Enchancting Table Chance Marker"}'},EntityTag:{Tags:["enchantingtablechance"]}} 1
##--- Enchancting Table Chance Marker END! ##


##--- Treasure Chance Marker# - base12 - manor3
#/give @p armor_stand{display:{Name:'{"text":"Treasure Chance Marker"}'},EntityTag:{Tags:["treasurechance"]}} 1
##--- Treasure Chance Marker##

#----------------------------------------------------------------------------------- DUNGEON CHESTS -----------------------------------------------------------------------------------------------------------#

##---Vault-Light Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/vault_light"} replace
#/setblock ~ ~ ~-1 trapped_chest{LootTable:"voa:blocks/vault_light"} replace
#--- Vault-Light - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Light-Chest"}'},EntityTag:{Tags:["spawnvaultlight"]}} 1
##TRAPROOM
#/give @p armor_stand{display:{Name:'{"text":"trapchest"}'},EntityTag:{Tags:["trapchest"]}} 1
##---Vault-Light Chest END! ##

##---End-Light Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/end_light"} replace
#--- End-Light - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"End-Light-Chest"}'},EntityTag:{Tags:["spawnendlight"]}} 1
##---End-Light Chest END! ##



##---Vault-Medium Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/vault_medium"} replace
#/setblock ~ ~ ~-1 trapped_chest{LootTable:"voa:blocks/vault_medium"} replace
#--- Vault-Medium - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Med-Chest"}'},EntityTag:{Tags:["spawnvaultmedium"]}} 1
##---Vault-Medium Chest END! ##

##---End-Medium Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/end_medium"} replace
#--- End-Medium - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"End-Med-Chest"}'},EntityTag:{Tags:["spawnendmedium"]}} 1
##---End-Medium Chest END! ##

##---Vault-Medium-Light Chance Chest#
#--- Vault-Medium - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Light-Med-Chest"}'},EntityTag:{Tags:["spawnvaultlightmedium"]}} 1
##---Vault-Medium-Light Chance END! ##



##---Vault-Heavy Chest#
#/setblock ~ ~ ~-1 chest{LootTable:"voa:blocks/vault_heavy"} replace
#/setblock ~ ~ ~-1 trapped_chest{LootTable:"voa:blocks/vault_heavy"} replace
#--- Vault-Heavy - Armor Stand Item -- Spawn Marker
#/give @p armor_stand{display:{Name:'{"text":"Rich-Chest"}'},EntityTag:{Tags:["spawnvaultrich"]}} 1
##---Vault-Heavy Chest END! ## 


#----------------------------------------------------------------------------------- Event Markers - Montastery --------------------------------------------------------------------------------------------------------#
##--- Safe Breaker Marker - CATH9, sbr18 - fort2
#/give @p armor_stand{display:{Name:'{"text":"Cath-Vault"}'},EntityTag:{Invisible:1b,Tags:["cathvault"]}} 1

##--- Blessing Marker NorthSouth Facing Room- cath8
#/give @p armor_stand{display:{Name:'{"text":"Bless_Event_NS"}'},EntityTag:{Invisible:1b,Tags:["blessevent"]}} 1

##--- Witching Marker - sbr17 - sbr16 - fort1
#/give @p armor_stand{display:{Name:'{"text":"Witching_Event"}'},EntityTag:{Invisible:1b,Tags:["witchevent"]}} 1

##--- Poison Trap - hallway bottom floor
#/give @p armor_stand{display:{Name:'{"text":"Poison Trap"}'},EntityTag:{Invisible:0b,Tags:["poisontrap"]}} 1

#----------------------------------------------------------------------------------- Event Markers - Market --------------------------------------------------------------------------------------------------------#
##--- Mining Debuff 
#/give @p armor_stand{display:{Name:'{"text":"Market_Mining_debuff"}'},EntityTag:{Invisible:1b,Tags:["market_mine_debuff"]}} 1

##--- Market_Pet-Shop Event# 
#/give @p armor_stand{display:{Name:'{"text":"Market_Petshop"}'},EntityTag:{Invisible:1b,Tags:["market_petshop"]}} 1

##--- Market_Material Event# 
#/give @p armor_stand{display:{Name:'{"text":"Market_Material"}'},EntityTag:{Tags:["market_material"]}} 1

##--- Market_End_chest Event# 
#/give @p armor_stand{display:{Name:'{"text":"Market_End_Chest"}'},EntityTag:{Tags:["market_end_chest"]}} 1

##--- Sculk Trap - hallway bottom floor
#/give @p armor_stand{display:{Name:'{"text":"Sculk Trap"}'},EntityTag:{Invisible:0b,Tags:["sculktrap"]}} 1
##--- Sculk Trap - Gila_Egg
##/give @p item_frame{display:{Name:'{"text":"Gila Egg"}'},CustomModelData:100200,EntityTag:{Silent:1b,Tags:["gila_egg"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:100200}},Invulnerable:1b,Invisible:1b,Fixed:1b}} 1
