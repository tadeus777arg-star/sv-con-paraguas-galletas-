#SUMMON DROPS
#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:purple_concrete"}},distance=0..2,sort=nearest,limit=1]


#KILL ITEM FRAME
kill @s