#All of the code below is part of the Vaults of Abandon datapack created by Fried_Oats

#say HATCH!

setblock ~ ~ ~ minecraft:air replace 

playsound minecraft:entity.zombie.destroy_egg hostile @a ~ ~ ~

summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",PersistenceRequired:1b,Health:36f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["gila"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["gila_body"],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:400000}}]}],CustomName:'{"text":"Gila Monster"}',ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:399999}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:36},{Name:generic.follow_range,Base:24},{Name:generic.knockback_resistance,Base:0.45},{Name:generic.movement_speed,Base:0.35},{Name:generic.attack_damage,Base:12},{Name:zombie.spawn_reinforcements,Base:0}]}
summon endermite ~ ~3 ~
summon endermite ~ ~3 ~

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=gila,type=minecraft:zombie,tag=!stats] sound_cool 0

tag @e[tag=gila,type=minecraft:zombie,tag=!stats] add stats

#Kills Marker
tag @s add hatched