#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
recipe take @s voa:item1

advancement revoke @s only voa:item1_adv

give @s stick{display:{Name:'{"text":"boneshot"}'},CustomModelData:262626,boneshot:1b} 3


clear @s minecraft:knowledge_book