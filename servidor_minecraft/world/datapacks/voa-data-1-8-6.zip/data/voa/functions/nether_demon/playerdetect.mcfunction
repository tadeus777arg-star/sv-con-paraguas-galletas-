#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Detecting Player
execute at @e[type=minecraft:wither_skeleton,tag=nether_demon] run summon snowball ~ ~3 ~
data modify entity @e[type=minecraft:snowball,limit=1,sort=nearest] Owner set from entity @a[distance=..40,sort=nearest,limit=1] UUID

#say BALLED

#Runs once?
tag @s add playerdetect

