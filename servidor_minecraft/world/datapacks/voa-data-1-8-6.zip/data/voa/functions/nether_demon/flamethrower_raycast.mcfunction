#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#particle affects
particle minecraft:flame ~ ~ ~ .01 .01 .01 .1 40
particle minecraft:small_flame ~ ~ ~ .7 .7 .7 .2 140
#playsound minecraft:block.lava.extinguish hostile @a ~ ~ ~

execute as @s[tag=explosion] run particle minecraft:soul_fire_flame ~ ~ ~ .01 .01 .01 .1 40

#On Block
execute unless block ~ ~ ~ #voa:raycast_pass run kill @s 

execute as @s[tag=explosion] unless block ~ ~ ~ #voa:raycast_pass run summon tnt ~ ~ ~ {Fuse:0}


#If Near Player
execute if entity @e[type=player,distance=..2] at @s[tag=!explosion] run damage @a[distance=..2,limit=1] 14 minecraft:fireball
execute if entity @e[type=player,distance=..2] at @s[tag=!explosion] run damage @a[distance=..2,limit=1] 7 minecraft:explosion
execute if entity @e[type=player,distance=..2] at @s[tag=!explosion] run effect give @a[distance=..2,limit=1] minecraft:slowness 3 1
execute if entity @e[type=player,distance=..2] at @s[tag=!explosion] run effect give @a[distance=..2,limit=1] minecraft:blindness 3

execute if entity @e[type=player,distance=..2] at @s[tag=explosion] run summon tnt ~ ~ ~ {Fuse:0}
execute if entity @e[type=player,distance=..2] at @s[] run kill @s

#teleport forwards
execute at @s run tp ^ ^ ^.5

#BEAGS