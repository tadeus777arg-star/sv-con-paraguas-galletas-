#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 850
#scoreboard players set in1 math 75

function voa:natural_generation/random/range_lcg


#Spawns Nether Demon
execute if score out math matches 5 run execute at @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run playsound minecraft:demon.mob.summon hostile @a ~ ~ ~ 9
execute if score out math matches 5 run execute at @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run playsound minecraft:ambient.cave hostile @a ~ ~ ~ 9
execute if score out math matches 5 run execute at @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 9
execute if score out math matches 5 run execute as @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run effect give @a[distance=..144] minecraft:darkness 15
execute if score out math matches 5 run execute as @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run effect give @a[distance=..144] minecraft:slowness 15 1
execute if score out math matches 5 run execute as @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run effect give @a[distance=..144] minecraft:weakness 30 1


execute if score out math matches 5 run execute at @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run summon wither_skeleton ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/nether_demon",Health:300f,Tags:["nether_demon","boss"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["nether_demon_body"],ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670001}}]}],CustomName:'{"text":"Tzeench - Nether Demon"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670005}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:fire_resistance",amplifier:1b,duration:999999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:300},{Name:generic.follow_range,Base:40},{Name:generic.knockback_resistance,Base:0.6},{Name:generic.movement_speed,Base:0.33},{Name:generic.attack_damage,Base:10},{Name:generic.attack_knockback,Base:4}]}


execute if score out math matches 5 run execute as @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] run tp @s ~ ~-256 ~

### INITALIZES CUSTOM ATTACK VARIA5LE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute if score out math matches 5 run scoreboard players add @e[tag=nether_demon,type=minecraft:wither_skeleton,tag=!stats] atk_cool 0
execute if score out math matches 5 run scoreboard players add @e[tag=nether_demon,type=minecraft:wither_skeleton,tag=!stats] sound_cool 0
execute if score out math matches 5 run scoreboard players add @e[tag=nether_demon,type=minecraft:wither_skeleton,tag=!stats] atk_flamethrower 70

execute if score out math matches 5 run tag @e[tag=nether_demon,type=minecraft:wither_skeleton,tag=!stats] add stats

### Add tag not_messenger to ensure the Entity is not scanned again
tag @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..72] add not_nether_demon


