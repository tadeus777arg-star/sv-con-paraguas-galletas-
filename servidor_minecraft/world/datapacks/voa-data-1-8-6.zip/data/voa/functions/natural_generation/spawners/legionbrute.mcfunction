#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#Result Run
execute if score out math matches 1 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/legion_loot",Health:45f,CustomName:'{"text":"Legionnaire Brute"}',PersistenceRequired:1b,HandItems:[{id:"minecraft:netherite_axe",Count:1b},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",Count:1b},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:45},{Name:generic.follow_range,Base:16},{Name:generic.movement_speed,Base:0.28}]}
execute if score out math matches 2 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/legion_loot",PersistenceRequired:1b,Health:45f,CustomName:'{"text":"Legionnaire Brute"}',HandItems:[{id:"minecraft:netherite_axe",Count:1b,tag:{Enchantments:[{id:"minecraft:sharpness",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:'minecraft:netherite_chestplate',Count:1b},{id:'minecraft:beetroot',Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:45},{Name:generic.follow_range,Base:16},{Name:generic.movement_speed,Base:0.28}]}

tag @s add summoned