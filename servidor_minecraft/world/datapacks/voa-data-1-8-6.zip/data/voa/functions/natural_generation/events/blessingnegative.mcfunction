#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:ambient.cave hostile @a[] ~ ~ ~ 2
particle minecraft:angry_villager ~ ~1 ~2 1 1 1 .05 20
effect give @a[distance=..16] minecraft:weakness 90 2
effect give @a[distance=..16] minecraft:instant_damage 1 1
effect give @a[distance=..16] minecraft:mining_fatigue 90 2
summon minecraft:stray ~3 ~ ~ {DeathLootTable:"voa:entities/legion_loot",PersistenceRequired:1b,Health:45f,CustomName:'{"text":"Legionnaire Brute"}',HandItems:[{id:"minecraft:netherite_axe",Count:1b,tag:{Enchantments:[{id:"minecraft:sharpness",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:'minecraft:netherite_chestplate',Count:1b},{id:'minecraft:beetroot',Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:45},{Name:generic.follow_range,Base:16},{Name:generic.movement_speed,Base:0.28}]}
summon minecraft:stray ~-3 ~ ~ {DeathLootTable:"voa:entities/legion_loot",PersistenceRequired:1b,Health:45f,CustomName:'{"text":"Legionnaire Brute"}',HandItems:[{id:"minecraft:netherite_axe",Count:1b,tag:{Enchantments:[{id:"minecraft:sharpness",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:'minecraft:netherite_chestplate',Count:1b},{id:'minecraft:beetroot',Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:45},{Name:generic.follow_range,Base:16},{Name:generic.movement_speed,Base:0.28}]}
summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["spawntitan"]}

tag @s add summoned