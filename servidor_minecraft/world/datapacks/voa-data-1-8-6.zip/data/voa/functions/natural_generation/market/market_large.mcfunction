#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 10
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg1", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg2", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg3", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg4", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg5", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg6", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg7", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg8", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg9", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg10", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 10 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg11", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}
execute if score out math matches 11 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -5, mode: "LOAD", posY: 0, sizeX: 11, posZ: -5, integrity: 1.0f, showair: 0b, name: "voa:market_lrg12", id: "minecraft:structure_block", sizeY: 5, sizeZ: 11, showboundingbox: 1b}


#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block
setblock ~ ~1 ~ minecraft:air


tag @s add summoned