#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens
execute if score out math matches 0 run summon armor_stand ~ 63 ~ {Tags:["spawnmanor1"]}
execute if score out math matches 1 run summon armor_stand ~ 63 ~ {Tags:["spawnmanor2"]}
execute if score out math matches 2 run summon armor_stand ~ 63 ~ {Tags:["spawnmanor3"]}

tag @s add spawnvaultgen

#B-E-A-G-L-E-B-L-O-C-K-S

