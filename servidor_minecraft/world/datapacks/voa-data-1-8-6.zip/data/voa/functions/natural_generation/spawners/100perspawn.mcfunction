#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 10
function voa:natural_generation/random/range_lcg

#The following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:zombie"}}}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:zombie"}}}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:zombie"}}}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:zombie"}}}
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:zombie"}}}
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton"}}}
execute if score out math matches 10 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:skeleton",CustomNameVisible:0b,DeathLootTable:"voa:entities/guardian_loot",Health:35f,Tags:["s_knight"],CustomName:'{"text":"Vault Guardian"}',HandItems:[{id:'minecraft:iron_sword',Count:1b,tag:{display:{Name:'{"text":"Skeel Blade"}'},CustomModelData:555555}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{id:'minecraft:leather_boots',Count:1b,tag:{display:{color:2359296}}},{id:'minecraft:leather_leggings',Count:1b,tag:{display:{color:2359296}}},{id:'minecraft:leather_chestplate',Count:1b,tag:{display:{color:7208960}}},{id:'minecraft:leather_helmet',Count:1b,tag:{display:{color:2359296}}}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:35},{Name:generic.knockback_resistance,Base:0.45},{Name:generic.movement_speed,Base:0.21},{Name:generic.attack_damage,Base:2},{Name:generic.attack_knockback,Base:6}]},SpawnPotentials:[{Weight:1,Entity:{id:"minecraft:skeleton",CustomNameVisible:0b,DeathLootTable:"shrouded_knights:entities/knight_loot",Health:35f,Tags:["s_knight"],CustomName:'{"text":"Shadow Knight"}',HandItems:[{id:'minecraft:iron_sword',Count:1b,tag:{display:{Name:'{"text":"Skeel Blade"}'},CustomModelData:555555}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{id:'minecraft:leather_boots',Count:1b,tag:{display:{color:2359296}}},{id:'minecraft:leather_leggings',Count:1b,tag:{display:{color:2359296}}},{id:'minecraft:leather_chestplate',Count:1b,tag:{display:{color:7208960}}},{id:'minecraft:leather_helmet',Count:1b,tag:{display:{color:2359296}}}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:35},{Name:generic.knockback_resistance,Base:0.45},{Name:generic.movement_speed,Base:0.21},{Name:generic.attack_damage,Base:2},{Name:generic.attack_knockback,Base:6}]}}]}}

tag @s add summoned