#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 9
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:emerald_block
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:coal_block
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:gold_block
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:iron_block
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:diamond_block
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:ancient_debris

tag @s add summoned