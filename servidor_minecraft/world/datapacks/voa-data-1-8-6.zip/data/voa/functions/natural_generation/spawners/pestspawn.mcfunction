#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 10
function voa:natural_generation/random/range_lcg


#Result Run
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:silverfish"}}}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:silverfish"}}}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:silverfish"}}}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:silverfish"}}}
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:spider"}}}
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:spider"}}}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:cave_spider"}}}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:cave_spider"}}}
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:spawner{SpawnData:{entity:{id:"minecraft:cave_spider"}}}






tag @s add summoned