#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Spawn Southhall Cap Boss (Far)

###---- SPAWNS QC --------------------------------------------------#
#summon armor_stand ~ ~-7 ~109 {NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:0b,NoBasePlate:1b,Tags:["qcsouth"],CustomName:'{"text":"South QC Cap Boss"}'}


###---- SPAWNS ROOOOOOOMS ------------------------------------------#

#South
##Spawns South Hallway - Attached to Middle Cap
#setblock ~ ~ ~94 minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -16, mode: "LOAD", posY: -15, sizeX: 33, posZ: 2, integrity: 1.0f, showair: 0b, name: "voa:brickhallnorthsouth", id: "minecraft:structure_block", sizeY: 22, sizeZ: 47, showboundingbox: 1b}
##Always Spawns Redstone
#setblock ~ ~1 ~94 minecraft:redstone_block
#Spawns South Endcap - OUTER  
setblock ~ ~ ~142 minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -15, sizeX: 47, posZ: 1, integrity: 1.0f, showair: 0b, name: "voa:brickhallcapboss", id: "minecraft:structure_block", sizeY: 22, sizeZ: 47, showboundingbox: 1b}
#Always Spawns Redstone
setblock ~ ~1 ~142 minecraft:redstone_block

###---- SPAWNS AIR ------------------------------------------#

#South
##Air South Hallway - Attached to Middle Cap
#setblock ~ ~ ~94 minecraft:air
#setblock ~ ~1 ~94 minecraft:air
#Air South Endcap - OUTER  
setblock ~ ~ ~142 minecraft:air
setblock ~ ~1 ~142 minecraft:air

#Summon Tag - Only Spawns Once
tag @s add summoned
