#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

particle minecraft:portal ~ ~ ~2 1 6 1 .05 30
particle minecraft:portal ~ ~ ~2 0 6 0 .16 60
scoreboard players set @s atk_cool 10

#B-E-A-G-L-E-B-L-O-C-K-S
