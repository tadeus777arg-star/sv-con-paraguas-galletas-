#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens
execute if score out math matches 0 run function voa:natural_generation/events/witchingseason