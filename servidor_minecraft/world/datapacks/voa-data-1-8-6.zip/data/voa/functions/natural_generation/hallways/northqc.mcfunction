#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Spawn Northhall Cap Boss (Far) QCCCCCCCCCC

###---- SPAWNS ROOOOOOOMS ------------------------------------------#

#North-outer
##Spawns North Hallway - Attached to Middle Cap
#Spawns North Endcap - OUTER 
setblock ~ ~7 ~-82 minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -15, sizeX: 47, posZ: 1, integrity: 1.0f, showair: 0b, name: "voa:brickhallcapboss", id: "minecraft:structure_block", sizeY: 22, sizeZ: 47, showboundingbox: 1b}
#Always Spawns Redstone
setblock ~ ~8 ~-82 minecraft:redstone_block

###---- SPAWNS AIR ------------------------------------------#

#North
##Air North Hallway - Attached to Middle Cap
#Air North Endcap - OUTER 
setblock ~ ~7 ~-82 minecraft:air
setblock ~ ~8 ~-82 minecraft:air

#Summon Tag - Only Spawns Once
tag @s add summoned
scoreboard players add @e[tag=qcnorth,type=minecraft:armor_stand,sort=nearest,limit=1] buildingtime 30

