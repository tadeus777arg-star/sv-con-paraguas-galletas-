#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 5
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:tnt_hall_active", id: "minecraft:structure_block", sizeY: 5, sizeZ: 13, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:tnt_hall_notnt", id: "minecraft:structure_block", sizeY: 5, sizeZ: 13, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:tnt_hall_notnt", id: "minecraft:structure_block", sizeY: 5, sizeZ: 13, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:tnt_hall_notnt", id: "minecraft:structure_block", sizeY: 5, sizeZ: 13, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:tnt_hall_notnt", id: "minecraft:structure_block", sizeY: 5, sizeZ: 13, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -6, integrity: 1.0f, showair: 0b, name: "voa:tnt_hall_notnt", id: "minecraft:structure_block", sizeY: 5, sizeZ: 13, showboundingbox: 1b}



#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block
setblock ~ ~1 ~ minecraft:air



tag @s add summoned