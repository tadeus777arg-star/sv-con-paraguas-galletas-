#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 8
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath1", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath2", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath3", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath4", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath5", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath6", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath7", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath8", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -3, mode: "LOAD", posY: 0, sizeX: 7, posZ: -3, integrity: 1.0f, showair: 0b, name: "voa:cath9", id: "minecraft:structure_block", sizeY: 4, sizeZ: 7, showboundingbox: 1b}

#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned