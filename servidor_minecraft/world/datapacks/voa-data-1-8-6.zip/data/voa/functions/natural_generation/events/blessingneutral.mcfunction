#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 1
particle minecraft:smoke ~ ~1 ~2 2 2 2 .05 30

tag @s add summoned