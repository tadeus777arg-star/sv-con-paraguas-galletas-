#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 19
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run summon minecraft:allay
execute if score out math matches 1 run summon minecraft:cat
execute if score out math matches 2 run summon minecraft:creeper
execute if score out math matches 3 run summon minecraft:cave_spider
execute if score out math matches 4 run summon minecraft:chicken
execute if score out math matches 5 run summon minecraft:cow
execute if score out math matches 6 run summon minecraft:fox
execute if score out math matches 7 run summon minecraft:frog
execute if score out math matches 8 run summon minecraft:goat
execute if score out math matches 9 run summon minecraft:mooshroom
execute if score out math matches 10 run summon minecraft:ocelot
execute if score out math matches 11 run summon minecraft:panda
execute if score out math matches 12 run summon minecraft:pig
execute if score out math matches 13 run summon minecraft:parrot
execute if score out math matches 14 run summon minecraft:rabbit
execute if score out math matches 15 run summon minecraft:sheep
execute if score out math matches 16 run summon minecraft:snow_golem
execute if score out math matches 17 run summon minecraft:villager
execute if score out math matches 18 run summon minecraft:wandering_trader
execute if score out math matches 19 run summon minecraft:pillager


tag @s add summoned