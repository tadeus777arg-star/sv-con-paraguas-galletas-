#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 11
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas1", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas2", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas3", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas4", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 4 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas5", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 5 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas6", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 6 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas7", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 7 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas8", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 8 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas9", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas10", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 10 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas11", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}
execute if score out math matches 11 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -4, mode: "LOAD", posY: 0, sizeX: 9, posZ: -4, integrity: 1.0f, showair: 0b, name: "voa:cas12", id: "minecraft:structure_block", sizeY: 4, sizeZ: 9, showboundingbox: 1b}

#Always Spawns Redstone
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned