#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 5
function voa:natural_generation/random/range_lcg

#Result Run
#Potion- 
execute if score out math matches 2 run summon zombie ~ ~ ~ {CanBreakDoors:0b,Silent:1b,DeathLootTable:"voa:entities/brew/harm",PersistenceRequired:1b,Health:8f,Tags:["brew_harmful"],HandItems:[{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_harming"}},{}],HandDropChances:[-327.670F,0.085F],ActiveEffects:[{Id:14,Amplifier:1b,Duration:199999980,ShowParticles:0b},{Id:28,Amplifier:1b,Duration:199999980,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:8},{Name:generic.movement_speed,Base:0.2}]}
execute if score out math matches 3 run summon zombie ~ ~ ~ {CanBreakDoors:0b,Silent:1b,DeathLootTable:"voa:entities/brew/poison",PersistenceRequired:1b,Health:8f,Tags:["brew_poison"],HandItems:[{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_poison"}},{}],HandDropChances:[-327.670F,0.085F],ActiveEffects:[{Id:14,Amplifier:1b,Duration:199999980,ShowParticles:0b},{Id:28,Amplifier:1b,Duration:199999980,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:8},{Name:generic.movement_speed,Base:0.2}]}
execute if score out math matches 4 run summon zombie ~ ~ ~ {CanBreakDoors:0b,Silent:1b,DeathLootTable:"voa:entities/brew/weakness",PersistenceRequired:1b,Health:8f,Tags:["brew_weakness"],HandItems:[{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:long_weakness"}},{}],HandDropChances:[-327.670F,0.085F],ActiveEffects:[{Id:14,Amplifier:1b,Duration:199999980,ShowParticles:0b},{Id:28,Amplifier:1b,Duration:199999980,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:8},{Name:generic.movement_speed,Base:0.2}]}
execute if score out math matches 5 run summon zombie ~ ~ ~ {CanBreakDoors:0b,Silent:1b,DeathLootTable:"voa:entities/brew/levitation",PersistenceRequired:1b,Health:8f,Tags:["brew_levitation"],HandItems:[{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_leaping"}},{}],HandDropChances:[-327.670F,0.085F],ActiveEffects:[{Id:14,Amplifier:1b,Duration:199999980,ShowParticles:0b},{Id:28,Amplifier:1b,Duration:199999980,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:8},{Name:generic.movement_speed,Base:0.2}]}
tag @s add summoned