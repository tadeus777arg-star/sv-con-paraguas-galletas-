#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Spawner
playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 
effect give @a[distance=..7] minecraft:slowness 8 4

summon armor_stand ~ ~ ~2 {Tags:["spawnspectre"]}
summon armor_stand ~ ~ ~-2 {Tags:["spawnspectre"]}
summon armor_stand ~2 ~  {Tags:["spawnspectre"]}
summon armor_stand ~2 ~ ~ {Tags:["spawnspectre"]}



tag @s add summoned