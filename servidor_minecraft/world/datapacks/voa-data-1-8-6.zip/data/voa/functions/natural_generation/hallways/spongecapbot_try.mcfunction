#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Sponge Cap Bot Clearance Try Again!

fill ~ ~ ~ ~47 ~6 ~47 minecraft:air replace minecraft:sponge
fill ~ ~ ~ ~47 ~6 ~47 minecraft:air replace minecraft:wet_sponge

