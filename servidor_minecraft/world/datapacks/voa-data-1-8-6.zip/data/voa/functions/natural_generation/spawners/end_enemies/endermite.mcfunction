#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 3
scoreboard players set in1 math 6
function voa:natural_generation/random/range_lcg

#Ethereal Spawns

execute if score out math matches 5 run setblock ~ ~ ~ spawner{SpawnData: {entity: {id: "minecraft:endermite"}}} replace
execute if score out math matches 6 run setblock ~ ~ ~ spawner{SpawnData: {entity: {id: "minecraft:endermite"}}} replace


tag @s add summoned