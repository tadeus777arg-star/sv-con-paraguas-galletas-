#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 9
function voa:natural_generation/random/range_lcg

#Spawn Room
#If 1 is selected, the following happens
execute if score out math matches 0 run function voa:natural_generation/events/blessingpositive
execute if score out math matches 1 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 2 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 3 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 4 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 5 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 6 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 7 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 8 run function voa:natural_generation/events/blessingneutral
execute if score out math matches 9 run function voa:natural_generation/events/blessingnegative

tag @s add summoned