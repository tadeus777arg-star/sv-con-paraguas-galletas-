#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#say Sponge Hall Clearance Try Again!

fill ~ ~ ~ ~33 ~18 ~47 minecraft:air replace minecraft:sponge
fill ~ ~ ~ ~33 ~18 ~47 minecraft:air replace minecraft:wet_sponge

#B-E-A-G-L-E-B-L-O-C-K-S

