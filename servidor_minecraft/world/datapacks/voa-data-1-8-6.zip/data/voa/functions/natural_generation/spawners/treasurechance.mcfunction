#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#Result Run
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:emerald_block
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:iron_block
execute if score out math matches 3 run setblock ~ ~ ~ minecraft:gold_block

tag @s add summoned