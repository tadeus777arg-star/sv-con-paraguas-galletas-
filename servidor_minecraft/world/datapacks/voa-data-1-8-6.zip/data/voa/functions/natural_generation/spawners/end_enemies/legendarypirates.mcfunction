#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg

#Result Run
#Scallywag
execute if score out math matches 2 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/end/ethereal_guardian",PersistenceRequired:1b,Health:110f,Tags:["ethereal"],CustomName:'{"text":"Ethereal Garrison"}',HandItems:[{id:"minecraft:netherite_sword",Count:1b,tag:{display:{Name:'{"text":"Ultimate Skeel Blade","color":"dark_purple","bold":true}'},CustomModelData:555557}},{id:"minecraft:shield",Count:1b}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:leather_chestplate",Count:1b,tag:{display:{color:0},Enchantments:[{id:"minecraft:projectile_protection",lvl:6s}],Trim:{material:"minecraft:redstone",pattern:"minecraft:eye"}}},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:777777}}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:110},{Name:generic.knockback_resistance,Base:0.75},{Name:generic.movement_speed,Base:0.22},{Name:generic.attack_damage,Base:9},{Name:generic.attack_knockback,Base:7}]}
#Privateer
execute if score out math matches 3 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/end/ethereal_watcher",Tags:["ethereal"],PersistenceRequired:1b,Health:45f,CustomName:'{"text":"Ethereal Privateer"}',HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:9s},{id:"minecraft:punch",lvl:3s},{id:"minecraft:flame",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:leather_chestplate",Count:1b,tag:{display:{color:0},Trim:{material:"minecraft:redstone",pattern:"minecraft:eye"}}},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:777777}}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:45},{Name:generic.movement_speed,Base:0.33}]}
#Buccaneer
execute if score out math matches 4 run summon stray ~ ~ ~ {DeathLootTable:"voa:entities/end/ethereal_brute",PersistenceRequired:1b,Health:60f,Tags:["ethereal","potionhold"],CustomName:'{"text":"Ethereal Buccaneer"}',HandItems:[{id:"minecraft:diamond_sword",Count:1b},{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_harming"}}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:leather_chestplate",Count:1b,tag:{display:{color:0},Trim:{material:"minecraft:redstone",pattern:"minecraft:spire"}}},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:777777}}],ArmorDropChances:[-327.670F,-327.670F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:60f},{Name:generic.movement_speed,Base:0.3},{Name:generic.attack_damage,Base:9}]}

tag @s add summoned