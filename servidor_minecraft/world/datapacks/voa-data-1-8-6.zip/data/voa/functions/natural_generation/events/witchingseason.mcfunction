#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:entity.witch.ambient hostile @a[distance=..16] ~ ~ ~ 3
playsound minecraft:entity.witch.ambient hostile @a[distance=..16] ~ ~ ~ 3
playsound minecraft:entity.witch.ambient hostile @a[distance=..16] ~ ~ ~ 3
summon witch ~ ~ ~ {CustomNameVisible:1b,PersistenceRequired:1b,DeathLootTable:"voa:entities/grand_witch",Health:75f,CustomName:'{"text":"Elder Witch","color":"red","bold":true}',Attributes:[{Name:generic.max_health,Base:75},{Name:generic.movement_speed,Base:0.36}]}
effect give @a[distance=..16] minecraft:blindness 20 1
effect give @a[distance=..16] minecraft:slowness 20 1