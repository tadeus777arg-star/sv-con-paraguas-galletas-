## Looting Method
loot replace block 6942069 255 6942069 container.0 loot voa:rando
execute store result score out math run data get block 6942069 255 6942069 Items[0].tag.AttributeModifiers[0].Amount