#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

execute if score out math matches 1 run summon creeper ~ ~ ~ {PersistenceRequired:1b,powered:1b,Tags:["macro"],CustomName:'{"text":"Macro Creeper"}',Attributes:[{Name:generic.movement_speed,Base:0.28}]}

#Kills Marker
tag @s add summoned