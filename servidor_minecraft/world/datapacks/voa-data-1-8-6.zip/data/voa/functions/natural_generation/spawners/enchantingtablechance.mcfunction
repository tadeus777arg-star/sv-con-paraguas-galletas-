#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 9
function voa:natural_generation/random/range_lcg

#Result Run
execute if score out math matches 9 run setblock ~ ~ ~ minecraft:enchanting_table

tag @s add summoned