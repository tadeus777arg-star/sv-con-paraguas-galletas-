#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


particle minecraft:ambient_entity_effect ~ ~ ~ 4 4 4 0 1000
playsound minecraft:entity.splash_potion.break hostile @a ~ ~ ~

#Old Damage Functions
execute at @s run effect give @a[distance=..6] minecraft:levitation 15 2 true

tp @s ~ ~-256 ~

