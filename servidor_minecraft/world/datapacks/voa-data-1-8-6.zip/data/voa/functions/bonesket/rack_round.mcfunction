#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

##Removes Ammo from inventory
clear @s stick{display:{Name:'{"text":"boneshot"}'},CustomModelData:262626,boneshot:1b} 1

# Steady Weapons
playsound minecraft:block.stone_button.click_on ambient @p[distance=..10]
item replace entity @s weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Bonesket(Loaded)"}'},HideFlags:1,CustomModelData:977778,bonesketloaded:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s},{id:"minecraft:sharpness",lvl:3s}]} 1

effect clear @s[] slowness

scoreboard players set @p[scores={bonesktracking=0..}] bonesktracking 18
