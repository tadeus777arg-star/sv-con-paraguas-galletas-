#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

item replace entity @p weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Bonesket"}'},HideFlags:1,CustomModelData:977779,bonesket:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s},{id:"minecraft:sharpness",lvl:3s}]} 1

effect give @s[] slowness 1 3 true

scoreboard players set @a[scores={boneskt_cool=0..}] boneskt_cool 8
