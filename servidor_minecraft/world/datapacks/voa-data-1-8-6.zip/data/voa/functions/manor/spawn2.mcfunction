#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Structure
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -14, mode: "LOAD", posY: -7, sizeX: 30, posZ: -19, integrity: 1.0f, showair: 0b, name: "voa:manor2", id: "minecraft:structure_block", sizeY: 28, sizeZ: 39, showboundingbox: 1b}
setblock ~ ~1 ~ minecraft:redstone_block

tag @s add summoned