#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the bat spawn

#say BETA4 Totally!

##Bottom Floor
 #summon bat ~25.5 ~1 ~19.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 summon bat ~26.5 ~1 ~-17.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~-10.5 ~1 ~-18.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~-11.5 ~1 ~18.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
#
###Middle Floor
 #summon bat ~-2 ~9 ~-17 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 summon bat ~-2 ~9 ~18 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~17 ~9 ~-17 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~17 ~9 ~18 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}

##Top Floor
 #summon bat ~-8.5 ~15 ~-15.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~-8.5 ~15 ~16.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~23.5 ~15 ~16.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}
 #summon bat ~23.5 ~15 ~-15.5 {HasVisualFire:1b,Silent:1b,PersistenceRequired:1b,NoAI:1b,Health:1f,Tags:["spook"],ActiveEffects:[{Id:14b,Amplifier:1b,Duration:9999999999,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:1},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:0}]}

tag @s add beta4
tag @s remove beta3

execute at @s run function voa:boss/control/control4