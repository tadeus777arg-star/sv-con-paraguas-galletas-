#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control Sequence - Spawns a set number of enemies

##Runs Spawn Command set number of times 

function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice
function voa:boss/control/control_choice



