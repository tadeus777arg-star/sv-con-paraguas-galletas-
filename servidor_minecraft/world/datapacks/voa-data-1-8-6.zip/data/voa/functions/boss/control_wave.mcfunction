#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control Sequence - Spawns a set number of enemies

##Reinforces the current Enemies

function voa:boss/control_choice
function voa:boss/control_choice

