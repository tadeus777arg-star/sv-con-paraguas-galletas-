#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 11
function voa:natural_generation/random/range_lcg


#############

##Bottom Floor
execute if score out math matches 0 run tp @s @e[tag=atlas1,limit=1,sort=nearest]
execute if score out math matches 1 run tp @s @e[tag=atlas2,limit=1,sort=nearest]
execute if score out math matches 2 run tp @s @e[tag=atlas3,limit=1,sort=nearest]
execute if score out math matches 3 run tp @s @e[tag=atlas4,limit=1,sort=nearest]


##Middle Floor
execute if score out math matches 4 run tp @s @e[tag=atlas5,limit=1,sort=nearest]
execute if score out math matches 5 run tp @s @e[tag=atlas6,limit=1,sort=nearest]
execute if score out math matches 6 run tp @s @e[tag=atlas7,limit=1,sort=nearest]
execute if score out math matches 7 run tp @s @e[tag=atlas8,limit=1,sort=nearest]


##Top Floor
execute if score out math matches 8 run tp @s @e[tag=atlas9,limit=1,sort=nearest]
execute if score out math matches 9 run tp @s @e[tag=atlas10,limit=1,sort=nearest]
execute if score out math matches 10 run tp @s @e[tag=atlas11,limit=1,sort=nearest]
execute if score out math matches 11 run tp @s @e[tag=atlas12,limit=1,sort=nearest]

