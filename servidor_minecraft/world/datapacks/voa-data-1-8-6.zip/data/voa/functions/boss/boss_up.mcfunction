#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#say BOOOO!

### Summons Effects and Clears Torches 
execute at @s run playsound minecraft:ambient.cave ambient @a[distance=..100] ~ ~ ~ 5

#Phase One Up
execute if entity @e[tag=down,tag=boss,tag=phase1,type=minecraft:husk,sort=nearest,limit=1] run data merge entity @e[tag=down,tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:1b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730000}}],Attributes:[{Name:generic.attack_damage,Base:12}]}
execute if entity @e[tag=down,tag=boss,tag=phase1,type=minecraft:husk,sort=nearest,limit=1] run effect clear @s minecraft:resistance


#Phase Two Up 
execute if entity @e[tag=down,tag=boss,tag=phase2,type=minecraft:husk,sort=nearest,limit=1] run data merge entity @e[tag=down,tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:0b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730002}}],Attributes:[{Name:generic.follow_range,Base:50},{Name:generic.knockback_resistance,Base:.9},{Name:generic.movement_speed,Base:0.33},{Name:generic.attack_damage,Base:13}]}




tag @s remove down
tag @s add canattack



