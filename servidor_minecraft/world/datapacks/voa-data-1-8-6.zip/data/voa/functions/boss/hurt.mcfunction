#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:wraith.mob.hurt hostile @a[] 2
