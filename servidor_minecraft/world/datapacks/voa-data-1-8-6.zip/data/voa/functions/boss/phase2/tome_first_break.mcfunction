#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

#Fancy Particles and Sounds
playsound minecraft:ambient.cave hostile @a[] ~ ~ ~ 4 
particle minecraft:ambient_entity_effect ~7.5 ~ ~.5 12 12 12 .05 4000

##Tome Selection
#say IM a TOMEC
tag @s add tomec

#say IM a TOMEH
tag @s add tomeh
#execute as @s run data merge entity @e[tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:0b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730004}}]}

execute if entity @s[tag=boss,type=minecraft:husk,tag=phase2] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=boss,tag=phase2] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:730004}}],HandItems:[{id:"minecraft:air",Count:1b},{}],HandDropChances:[-327.670F,0.085F]}
