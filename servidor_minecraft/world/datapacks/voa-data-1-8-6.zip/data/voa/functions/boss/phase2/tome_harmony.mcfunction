#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

execute as @a[distance=..22] at @s run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["boss_potion4"]}
execute as @a[distance=..22] at @s run playsound minecraft:entity.illusioner.cast_spell ambient @a ~ ~ ~ 1

#Scoreboard
scoreboard players add @e[tag=boss_potion4,type=minecraft:armor_stand,sort=nearest] atk_cool 99