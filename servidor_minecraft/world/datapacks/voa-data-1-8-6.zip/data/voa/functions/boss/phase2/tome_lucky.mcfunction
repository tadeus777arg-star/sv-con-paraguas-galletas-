#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

playsound minecraft:entity.bat.death ambient @a ~ ~ ~ 4

#Summons Player Bats
summon bat ~ ~1 ~.5 {HasVisualFire:1b,Tags:["lucky_bat"]}
summon bat ~.5 ~1 ~-.5 {HasVisualFire:1b,Tags:["lucky_bat"]}
summon bat ~.5 ~1 ~.5 {HasVisualFire:1b,Tags:["lucky_bat"]}

#Sets Explosive Timer
scoreboard players add @e[tag=lucky_bat,type=minecraft:bat] atk_cool 16