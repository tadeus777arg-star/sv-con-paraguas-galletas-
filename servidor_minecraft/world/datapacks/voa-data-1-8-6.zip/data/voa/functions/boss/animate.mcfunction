#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Moving Animation 
execute if entity @s[scores={animate=1},tag=phase2] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=boss,tag=phase2] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:730003}}],HandItems:[{id:"minecraft:air",Count:1b},{}],HandDropChances:[-327.670F,0.085F]}

#Resets Moving Animation 
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=phase2] run scoreboard players set @s animate 0
execute if entity @s[scores={animate=0},tag=phase2] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=boss,tag=phase2] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:730002}}],HandItems:[{id:"minecraft:air",Count:1b},{}],HandDropChances:[-327.670F,0.085F]}

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:wraith.mob.hurt hostile @a[distance=0..10]

#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=phase2] run scoreboard players add @s animate 1 

#B-E-A-G-L-E-B-L-O-C-K-S
