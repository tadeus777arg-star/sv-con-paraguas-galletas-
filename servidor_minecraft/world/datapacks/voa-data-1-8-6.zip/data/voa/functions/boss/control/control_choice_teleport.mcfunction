#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

#randomizer function - 50/50 odds
#scoreboard players set in math 0
#scoreboard players set in1 math 11
#function voa:natural_generation/random/range_lcg

#Fancy Particles and Sounds
#playsound minecraft:ambient.cave hostile @a[] ~7.5 ~ ~.5 4 
#particle minecraft:ambient_entity_effect ~7.5 ~ ~.5 12 12 12 .05 4000

##Bottom Floor
summon armor_stand ~25 ~ ~19 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas1"]}
summon armor_stand ~26 ~ ~-18 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas2"]}
summon armor_stand ~-11 ~ ~-19 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas3"]}
summon armor_stand ~-12 ~ ~18 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas4"]}

##Middle Floor
summon armor_stand ~-2 ~8 ~-17 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas5"]}
summon armor_stand ~-2 ~8 ~18 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas6"]}
summon armor_stand ~17 ~8 ~-17 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas7"]}
summon armor_stand ~17 ~8 ~18 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas8"]}

##Top Floor
summon armor_stand ~-9 ~14 ~-16 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas9"]}
summon armor_stand ~-9 ~14 ~16 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas10"]}
summon armor_stand ~23 ~14 ~16 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas11"]}
summon armor_stand ~23 ~14 ~-16 {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["atlas12"]}


#B-E-A-G-L-E-B-L-O-C-K-S