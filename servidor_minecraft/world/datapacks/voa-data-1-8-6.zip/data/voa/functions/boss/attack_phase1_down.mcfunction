#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Giving the custom attack

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 9
function voa:natural_generation/random/range_lcg

execute as @a[distance=..4] at @s run playsound minecraft:entity.illusioner.cast_spell ambient @a ~ ~ ~ 1

execute if score out math matches 0 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 1 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 2 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 3 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 4 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 5 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 6 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 7 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 8 run effect give @a[distance=..4] minecraft:instant_damage 1 
execute if score out math matches 9 run execute as @a[distance=..4] at @s run function voa:boss/control/control_choice_teleport_player


#say SHORT ATTACKS!

