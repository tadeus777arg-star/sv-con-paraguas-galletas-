#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#Fancy Particles and Sounds
playsound minecraft:ambient.cave hostile @a[] ~ ~ ~ 4 
particle minecraft:ambient_entity_effect ~7.5 ~ ~.5 12 12 12 .05 4000

##Tome Selection
#execute if score out math matches 0 run say IM a TOMEC
execute if score out math matches 0 run data merge entity @e[tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:0b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730004}}],HandItems:[{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:234448}},{}],HandDropChances:[-327.670F,0.085F]}
execute if score out math matches 0 run tag @s add tomec

#execute if score out math matches 1 run say IM a TOMEL
execute if score out math matches 1 run data merge entity @e[tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:0b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730004}}],HandItems:[{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:234450}},{}],HandDropChances:[-327.670F,0.085F]}
execute if score out math matches 1 run tag @s add tomel

#execute if score out math matches 2 run say IM a TOMEH
execute if score out math matches 2 run data merge entity @e[tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:0b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730004}}],HandItems:[{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{CustomModelData:234449}},{}],HandDropChances:[-327.670F,0.085F]}
execute if score out math matches 2 run tag @s add tomeh
