#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control Sequence - Spawns a set number of enemies

playsound minecraft:fortress.music.ambient music @a[distance=0..60] ~ ~ ~ 3

#Summons Experience
summon experience_orb ~7 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~5 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~5 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~1.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~4 ~2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~6 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-1.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~7 ~8 ~-2.5 {Count:3,Value:20}
summon experience_orb ~8 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~4 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~4 ~0.5 {Count:3,Value:20}
summon experience_orb ~8 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~9 ~5 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~7 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~6 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}
summon experience_orb ~5 ~8 ~0.5 {Count:3,Value:20}




#Chests Spawn

setblock ~8 ~ ~-6 chest[facing=south]{LootTable:"voa:blocks/vault_heavy"} replace
setblock ~6 ~ ~-6 chest[facing=south]{LootTable:"voa:blocks/vault_heavy"} replace
particle minecraft:happy_villager ~8 ~ ~-6 1 1 1 1 20 normal
particle minecraft:happy_villager ~6 ~ ~-6 1 1 1 1 20 normal

setblock ~8 ~ ~6 chest{LootTable:"voa:blocks/vault_heavy"} replace
setblock ~6 ~ ~6 chest{LootTable:"voa:blocks/vault_heavy"} replace
particle minecraft:happy_villager ~8 ~ ~6 1 1 1 1 20 normal
particle minecraft:happy_villager ~6 ~ ~6 1 1 1 1 20 normal

setblock ~14 ~ ~1 chest[facing=west]{LootTable:"voa:blocks/vault_heavy"} replace
setblock ~14 ~ ~-1 chest[facing=west]{LootTable:"voa:blocks/vault_heavy"} replace
particle minecraft:happy_villager ~14 ~ ~1 1 1 1 1 20 normal
particle minecraft:happy_villager ~14 ~ ~-1 1 1 1 1 20 normal

#Kills Enemies
kill @e[type=husk,distance=..50]
kill @e[type=stray,distance=..50]
kill @e[tag=titan,distance=..50]

kill @e[tag=atlas1]
kill @e[tag=atlas2]
kill @e[tag=atlas3]
kill @e[tag=atlas4]
kill @e[tag=atlas5]
kill @e[tag=atlas6]
kill @e[tag=atlas7]
kill @e[tag=atlas8]
kill @e[tag=atlas9]
kill @e[tag=atlas20]
kill @e[tag=atlas11]
kill @e[tag=atlas12]

#Removes Tag
tag @s remove alpha6
tag @s remove beta6
