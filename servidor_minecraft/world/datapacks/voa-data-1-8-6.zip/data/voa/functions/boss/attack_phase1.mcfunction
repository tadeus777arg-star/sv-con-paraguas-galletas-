#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Giving the custom attack
#effect give @a[distance=0..50] minecraft:instant_damage 1 
#effect give @a[distance=0..50] minecraft:hunger 10 2

execute as @a[distance=..28] at @s run summon armor_stand ~ ~ ~ {Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["boss_potion"]}
execute as @a[distance=..28] at @s run playsound minecraft:entity.illusioner.cast_spell ambient @a ~ ~ ~ 1

#Scoreboard
scoreboard players add @e[tag=boss_potion,type=minecraft:armor_stand,sort=nearest] atk_cool 33

