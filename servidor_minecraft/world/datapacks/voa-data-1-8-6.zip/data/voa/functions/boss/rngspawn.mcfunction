#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Control_Choice Sequence - Picks the Enemy

##Picks Between Wraith or Spectre

#say RNG!

#randomizer function - 50/50 odds
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

##Bottom Floor
execute if score out math matches 0 run tag @s add alpha1
execute if score out math matches 0 run tag @s add alpha
#execute if score out math matches 0 run say tag @s add alpha1
execute if score out math matches 1 run tag @s add beta
execute if score out math matches 1 run tag @s add beta1
#execute if score out math matches 1 run say tag @s add beta1