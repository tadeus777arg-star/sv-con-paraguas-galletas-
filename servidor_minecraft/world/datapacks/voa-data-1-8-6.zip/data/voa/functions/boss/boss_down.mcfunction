#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#say BOOOO!

### Summons Effects
#particle minecraft:soul_fire_flame ~7.5 ~ ~.5 3 4 3 .02 700 normal
#execute at @s run playsound minecraft:ambient.cave ambient @a[distance=..100]

execute at @s run playsound minecraft:entity.lightning_bolt.thunder hostile @a[] ~ ~ ~ 5
execute at @s run playsound minecraft:block.anvil.land hostile @a[] ~ ~ ~ 5

execute if entity @e[tag=!down,tag=boss,type=minecraft:husk,sort=nearest,limit=1] run data merge entity @e[tag=!down,tag=boss,type=minecraft:husk,sort=nearest,limit=1] {Invulnerable:0b,ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:730001}}],Attributes:[{Name:generic.attack_damage,Base:0}]}

###Added Damage Bonus - Turned off for now
effect give @s minecraft:resistance 100 1

#Summons Guards
#execute at @s run summon stray ~ ~ ~2 {DeathLootTable:"voa:entities/legion_loot",Health:35f,Tags:["royal"],CustomName:'{"text":"Royal Legionnaire"}',HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:4s},{id:"minecraft:punch",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",Count:1b},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:35},{Name:generic.follow_range,Base:30},{Name:generic.movement_speed,Base:0.27}]}
#execute at @s run summon stray ~ ~ ~-2 {DeathLootTable:"voa:entities/legion_loot",Health:35f,Tags:["royal"],CustomName:'{"text":"Royal Legionnaire"}',HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:4s},{id:"minecraft:punch",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",Count:1b},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:35},{Name:generic.follow_range,Base:30},{Name:generic.movement_speed,Base:0.27}]}

execute as @e[tag=!down,tag=boss,tag=!beta6,tag=!alpha6,type=minecraft:husk,sort=nearest,limit=1] at @s run summon stray ~ ~ ~2 {DeathLootTable:"voa:entities/legion_loot",Health:35f,Tags:["royal"],CustomName:'{"text":"Royal Legionnaire"}',HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:4s},{id:"minecraft:punch",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",Count:1b},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:35},{Name:generic.follow_range,Base:30},{Name:generic.movement_speed,Base:0.27}]}
execute as @e[tag=!down,tag=boss,tag=!beta6,tag=!alpha6,type=minecraft:husk,sort=nearest,limit=1] at @s run summon stray ~ ~ ~-2 {DeathLootTable:"voa:entities/legion_loot",Health:35f,Tags:["royal"],CustomName:'{"text":"Royal Legionnaire"}',HandItems:[{id:"minecraft:bow",Count:1b,tag:{Enchantments:[{id:"minecraft:power",lvl:4s},{id:"minecraft:punch",lvl:2s}]}},{}],HandDropChances:[-327.670F,0.085F],ArmorItems:[{},{},{id:"minecraft:netherite_chestplate",Count:1b},{id:"minecraft:beetroot",Count:1b,tag:{CustomModelData:767676}}],ArmorDropChances:[0.085F,0.085F,-327.670F,-327.670F],Attributes:[{Name:generic.max_health,Base:35},{Name:generic.follow_range,Base:30},{Name:generic.movement_speed,Base:0.27}]}


tag @s add down
tag @s remove canattack

scoreboard players set @e[tag=boss,type=minecraft:husk,sort=nearest,limit=1] boss_cool 240





