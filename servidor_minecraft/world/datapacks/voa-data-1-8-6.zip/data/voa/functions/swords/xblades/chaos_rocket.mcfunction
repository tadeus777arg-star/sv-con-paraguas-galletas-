#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

tag @s add expo  
scoreboard players set @s[] xblade_c_cool 25
effect give @s minecraft:levitation 20 7
playsound minecraft:entity.firework_rocket.launch ambient @a ~ ~ ~ 2

