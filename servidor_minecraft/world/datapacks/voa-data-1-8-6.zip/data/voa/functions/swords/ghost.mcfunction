#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


effect give @e[tag=ghost,distance=..6] minecraft:slowness 1 0

execute as @e[tag=ghost,distance=..6] at @s run particle minecraft:dragon_breath ~ ~1 ~ .5 .5 .5 .0005 1

#BEAGLE