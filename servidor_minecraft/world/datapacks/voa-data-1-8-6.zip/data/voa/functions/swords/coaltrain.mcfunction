#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 15
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run execute as @e[nbt={HurtTime:10s},distance=..6] at @s run loot spawn ~ ~1 ~ loot voa:entities/coaltrain

#BEAGLE