#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

summon bat ~ ~ ~ {Tags:["luckybat"]}
playsound minecraft:entity.bat.death ambient @a[] ~ ~ ~ 1
particle minecraft:happy_villager ~ ~ ~ .2 1 .2 .2 20 normal
tp @s ~ ~-256 ~


