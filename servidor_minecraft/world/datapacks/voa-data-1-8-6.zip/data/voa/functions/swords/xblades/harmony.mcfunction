#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#RNG
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg

#Random Chance
execute if score out math matches 3 run effect give @e[distance=..6] instant_health 1 0
#execute if score out math matches 3 run effect give @e[type=voa:friendly,distance=..5] instant_health 1 0
execute if score out math matches 3 run particle minecraft:heart ~ ~ ~ 5 2 5 0.3 125 normal
execute if score out math matches 3 run playsound minecraft:willowbee.mob.hurt ambient @a[]


