#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Effects
damage @s 12 minecraft:freeze
effect give @s minecraft:slowness 3 0
tag @s remove snowdamage