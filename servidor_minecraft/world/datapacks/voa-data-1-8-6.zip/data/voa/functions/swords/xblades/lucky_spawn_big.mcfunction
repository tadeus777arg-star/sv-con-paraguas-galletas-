#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Titan Mechanic
#Execute if above 50% Health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 30 minecraft:player_attack at ~ ~ ~
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon bat ~ ~ ~ {Tags:["luckybat"]}
execute at @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:entity.bat.death ambient @a[] ~ ~ ~ 1
execute at @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:happy_villager ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Warped-Titan Mechanic
#Execute if above 50% Health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 30 minecraft:player_attack at ~ ~ ~
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon bat ~ ~ ~ {Tags:["luckybat"]}
execute at @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:entity.bat.death ambient @a[] ~ ~ ~ 1
execute at @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:happy_villager ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Dream_Eater Mechanic
#Execute if above 50% Health
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 30 minecraft:player_attack at ~ ~ ~
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon bat ~ ~ ~ {Tags:["luckybat"]}
execute at @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:entity.bat.death ambient @a[] ~ ~ ~ 1
execute at @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:happy_villager ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Ravager Mechanic
#Execute if above 50% Health
execute as @e[type=minecraft:ravager,scores={titanhealth=53..},distance=..5] at @s run damage @s 30 minecraft:player_attack at ~ ~ ~
execute as @e[type=minecraft:ravager,scores={titanhealth=53..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run summon bat ~ ~ ~ {Tags:["luckybat"]}
execute at @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run playsound minecraft:entity.bat.death ambient @a[] ~ ~ ~ 1
execute at @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run particle minecraft:happy_villager ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run tp @s ~ ~-256 ~

#Warden Mechanic
#Execute if above 50% Health
execute as @e[type=minecraft:warden,scores={titanhealth=53..},distance=..5] at @s run damage @s 30 minecraft:player_attack at ~ ~ ~
execute as @e[type=minecraft:warden,scores={titanhealth=53..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run summon bat ~ ~ ~ {Tags:["luckybat"]}
execute at @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run playsound minecraft:entity.bat.death ambient @a[] ~ ~ ~ 1
execute at @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run particle minecraft:happy_villager ~ ~ ~ .2 1 .2 .2 20 normal
execute as @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run tp @s ~ ~-256 ~

tag @s remove luck

