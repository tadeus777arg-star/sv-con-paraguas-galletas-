#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

data merge entity @s {Fire:240}
