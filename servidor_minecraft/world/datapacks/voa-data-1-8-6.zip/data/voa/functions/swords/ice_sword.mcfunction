#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#RNG
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#Random Chance
execute if score out math matches 3 run effect give @e[type=!#voa:not_mob,distance=..5,type=!player] minecraft:slowness 3 0
execute if score out math matches 3 run effect give @e[type=!#voa:not_mob,distance=..5,type=!player] minecraft:slowness 3 0
execute if score out math matches 3 run particle minecraft:snowflake ~ ~ ~ 3 2 3 .10 100
execute if score out math matches 3 run particle minecraft:snowflake ~ ~ ~ 1 2 1 .10 50
execute if score out math matches 3 run tag @e[type=!#voa:not_mob,distance=..5,type=!player] add snowdamage
execute if score out math matches 3 run playsound minecraft:block.amethyst_block.chime ambient @a ~ ~ ~ 5
