#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 19
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run execute as @e[nbt={HurtTime:10s},distance=..6] at @s run loot spawn ~ ~1 ~ loot voa:entities/psionic
execute if score out math matches 0 run effect give @s minecraft:speed 5 1
execute if score out math matches 0 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 0 run effect give @s minecraft:strength 5 1
execute if score out math matches 2 run effect give @s minecraft:speed 5 1
execute if score out math matches 2 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 2 run effect give @s minecraft:strength 5 1
execute if score out math matches 4 run effect give @s minecraft:speed 5 1
execute if score out math matches 4 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 4 run effect give @s minecraft:strength 5 1
execute if score out math matches 6 run effect give @s minecraft:speed 5 1
execute if score out math matches 6 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 6 run effect give @s minecraft:strength 5 1
execute if score out math matches 8 run effect give @s minecraft:speed 5 1
execute if score out math matches 8 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 8 run effect give @s minecraft:strength 5 1
execute if score out math matches 10 run effect give @s minecraft:speed 5 1
execute if score out math matches 10 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 10 run effect give @s minecraft:strength 5 1
execute if score out math matches 12 run effect give @s minecraft:speed 5 1
execute if score out math matches 12 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 12 run effect give @s minecraft:strength 5 1
execute if score out math matches 14 run effect give @s minecraft:speed 5 1
execute if score out math matches 14 run effect give @s minecraft:jump_boost 5 1
execute if score out math matches 14 run effect give @s minecraft:strength 5 1

#BEAGLE