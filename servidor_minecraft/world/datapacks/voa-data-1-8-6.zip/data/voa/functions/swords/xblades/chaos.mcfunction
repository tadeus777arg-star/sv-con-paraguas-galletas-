#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#RNG
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

#Random Chance
execute if score out math matches 3 run tag @e[nbt={HurtTime:10s},distance=..6,tag=!boss,type=!wither,type=!ender_dragon,type=!player] add rocket  


