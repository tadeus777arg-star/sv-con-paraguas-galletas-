#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 19
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run execute as @e[nbt={HurtTime:10s},distance=..6] at @s run loot spawn ~ ~1 ~ loot voa:entities/embezzler
execute if score out math matches 0 run execute as @e[nbt={HurtTime:10s},distance=..6] at @s run summon minecraft:experience_orb ~ ~ ~ {Value:1}
execute if score out math matches 0 run execute as @e[nbt={HurtTime:10s},distance=..6] at @s run particle minecraft:happy_villager ~ ~ ~ 1 1 1 1 100 normal  
execute if score out math matches 0 run execute as @e[nbt={HurtTime:10s},distance=..6] at @s run playsound minecraft:willowbee.mob.hurt ambient @a ~ ~ ~



#BEAGLE