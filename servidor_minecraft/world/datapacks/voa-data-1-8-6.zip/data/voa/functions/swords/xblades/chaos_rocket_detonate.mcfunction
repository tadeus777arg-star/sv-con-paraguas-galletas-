#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

effect clear @s minecraft:levitation 
playsound minecraft:entity.firework_rocket.large_blast ambient @a ~ ~ ~ 2
particle minecraft:flash ~ ~ ~ 1 1 1 1 1
#execute at @s run effect give @e[tag=rocket,type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,type=!#voa:undead,distance=0..1.5,limit=1,sort=nearest] minecraft:instant_damage 1 0 true
#execute at @s run effect give @e[tag=rocket,type=!area_effect_cloud,type=!experience_orb,type=!armor_stand,type=!item_frame,type=!player,type=!item,type=!arrow,type=!#voa:living,distance=0..1.5,limit=1,sort=nearest] minecraft:instant_health 1 0 true
execute at @s run damage @s[] 20 minecraft:player_attack at ~ ~ ~


tag @s remove rocket  
tag @s remove expo  


