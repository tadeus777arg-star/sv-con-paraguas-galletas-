#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#RNG
scoreboard players set in math 0
scoreboard players set in1 math 6
function voa:natural_generation/random/range_lcg


execute if score out math matches 6 run data merge entity @s {Fire:270}
execute if score out math matches 6 run playsound minecraft:block.fire.extinguish hostile @a[] ~ ~ ~ 1


