#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs Sound at Player
playsound minecraft:entity.firework_rocket.launch ambient @a[]

#Armor Stand is the stasis
summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["stasis"]}

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[type=minecraft:armor_stand,tag=stasis,sort=nearest,limit=1] tome_c_cool 300

#data merge item
clear @s[tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Stasis Field"}'},CustomModelData:234445,tome_c:1b} 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 
#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#Random Chance - Removal
execute as @s[tag=tome_retry] if score out math matches 1 run clear @s minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Stasis Field"}'},CustomModelData:234445,tome_c:1b} 1
execute as @s[tag=tome_retry] if score out math matches 2 run clear @s minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Stasis Field"}'},CustomModelData:234445,tome_c:1b} 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 