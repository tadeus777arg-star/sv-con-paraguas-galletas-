#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Stasis Field
effect give @e[type=!player,type=!minecraft:armor_stand,type=!minecraft:item_frame,distance=..6] minecraft:levitation 5 3

execute as @e[type=minecraft:area_effect_cloud,tag=pot_atk,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:area_effect_cloud,tag=pot_atk,distance=..6] at @s run particle minecraft:ash ~ ~ ~ 1 1 1 0.3 60 normal
execute as @e[type=minecraft:area_effect_cloud,tag=pot_atk,distance=..6] at @s run kill @s

execute as @e[type=minecraft:arrow,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:arrow,distance=..6] at @s run particle minecraft:ash ~ ~ ~ 1 1 1 0.3 60 normal
execute as @e[type=minecraft:arrow,distance=..6] at @s run kill @s

execute as @e[type=minecraft:small_fireball,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:small_fireball,distance=..6] at @s run particle minecraft:ash ~ ~ ~ 1 1 1 0.3 60 normal
execute as @e[type=minecraft:small_fireball,distance=..6] at @s run kill @s 

execute as @e[type=minecraft:llama_spit,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:llama_spit,distance=..6] at @s run particle minecraft:ash ~ ~ ~ 1 1 1 0.3 60 normal
execute as @e[type=minecraft:llama_spit,distance=..6] at @s run kill @s 

execute as @e[type=minecraft:potion,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:potion,distance=..6] at @s run particle minecraft:ash ~ ~ ~ 1 1 1 0.3 60 normal
execute as @e[type=minecraft:potion,distance=..6] at @s run kill @s

#Execute on Fireball
execute as @e[type=minecraft:fireball,distance=..6] at @s run particle minecraft:large_smoke ~ ~ ~ .7 1 .7 0.3 50 normal
execute as @e[type=minecraft:fireball,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:fireball,distance=..6] at @s run kill @s

#Execute on Wither Skull
execute as @e[type=minecraft:wither_skull,distance=..6] at @s run particle minecraft:large_smoke ~ ~ ~ .7 1 .7 0.3 50 normal
execute as @e[type=minecraft:wither_skull,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:wither_skull,distance=..6] at @s run kill @s

#Execute on Dragon Fireball
execute as @e[type=minecraft:dragon_fireball,distance=..6] at @s run particle minecraft:large_smoke ~ ~ ~ .7 1 .7 0.3 50 normal
execute as @e[type=minecraft:dragon_fireball,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[type=minecraft:dragon_fireball,distance=..6] at @s run kill @s

#Execute on Nether Demon Fireball
execute as @e[tag=flamethrower_ball,distance=..6] at @s run particle minecraft:large_smoke ~ ~ ~ .7 1 .7 0.3 50 normal
execute as @e[tag=flamethrower_ball,distance=..6] at @s run playsound minecraft:entity.generic.extinguish_fire ambient @a[]
execute as @e[tag=flamethrower_ball,distance=..6] at @s run kill @s

#Particle for Stasis
playsound minecraft:item.bone_meal.use ambient @a[]
particle minecraft:effect ~ ~ ~ 4 4 4 0.3 60 normal


