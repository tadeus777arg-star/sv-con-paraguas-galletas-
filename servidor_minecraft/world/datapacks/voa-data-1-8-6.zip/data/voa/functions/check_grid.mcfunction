#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This File Searches for un-generated chunks, if the chunk has not been generated it will run the command below.

#say I'm working, Checking grid!


#Checks immediate Area and neighboring chunks (16 Blocks)
execute positioned ~ ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks far out chunks (32 Blocks)
execute positioned ~ ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks far corner Chunks (32 Blocks)
execute positioned ~32 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way Far out chunks (48 Blocks)
execute positioned ~ ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far middle Chunks (48 Blocks)
execute positioned ~32 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far corner Chunks (48 Blocks)
execute positioned ~48 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks EXTREMELY far out (64 Blocks)
execute positioned ~ ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far corner Chunks (64 Blocks)
execute positioned ~64 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far middle Chunks (64 Blocks)
execute positioned ~32 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far middle Chunks (64 Blocks)
execute positioned ~64 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks WICKEDLY far out (80 Blocks)
execute positioned ~ ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~ unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~ ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks WICKEDLY corner Chunks (80 Blocks)
execute positioned ~80 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~-16 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~16 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-16 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks WICKEDLY middle Chunks (80 Blocks)
execute positioned ~32 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~32 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-32 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~-32 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far middle Chunks (80 Blocks)
execute positioned ~80 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~-48 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~48 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-48 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}

#Checks Way far middle Chunks (80 Blocks)
execute positioned ~64 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~64 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-64 ~ ~-80 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~80 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}
execute positioned ~-80 ~ ~-64 unless block ~ -63 ~ red_wool run summon area_effect_cloud ~ ~ ~ {Tags:["check_chunk"]}


#runs Chunk Align on summoned area_effect_cloud
execute as @e[tag=check_chunk] run function voa:chunk_align
kill @e[tag=check_chunk]
