#SUMMON DROPS
summon item ~ ~0.5 ~ {Item:{id:"minecraft:item_frame",Count:1b,tag:{display:{Name:'{"text":"Defender Trophy"}'},CustomModelData:767676,EntityTag:{Silent:1b,Tags:["defender"],Item:{id:'minecraft:item_frame',Count:1b,tag:{CustomModelData:767676}},Invulnerable:1b,Invisible:1b,Fixed:1b,Facing:1}}}}

#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:player_head"}},distance=0..2,sort=nearest,limit=1]

#KILL ITEM FRAME
kill @s

#B-E-A-G-L-E-B-L-O-C-K-S
