# AS AND AT POSITION of custom item frame 
setblock ~ ~ ~ minecraft:player_head
tag @s add placed 



