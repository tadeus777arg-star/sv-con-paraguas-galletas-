#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 7
function voa:natural_generation/random/range_lcg

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
###  If matches 0 
execute if score out math matches 7 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,PersistenceRequired:1b,DeathLootTable:"voa:entities/titan_loot",Health:100,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["titan"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["titan_body"],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:470000}}]}],CustomName:'{"text":"Grotesque Titan"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470001}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:100},{Name:generic.follow_range,Base:20},{Name:generic.knockback_resistance,Base:0.7},{Name:generic.movement_speed,Base:0.36},{Name:generic.attack_damage,Base:9},{Name:zombie.spawn_reinforcements,Base:0}]}


### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute if score out math matches 7 run scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] atk_cool 0
execute if score out math matches 7 run scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] sound_cool 0
execute if score out math matches 7 run scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] proxy 0
execute if score out math matches 7 run scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] titanhealth 0

execute if score out math matches 7 run tag @e[tag=titan,type=minecraft:zombie,tag=!stats] add stats

#Kills Marker
tag @s add summoned
