#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#How long it takes to cool down
scoreboard players set @s atk_cool 100

#Giving the custom attack
effect give @a[distance=0..4] blindness 6
effect give @a[distance=0..4] minecraft:instant_damage 1
effect give @a[distance=0..4] slowness 6 3

#particle affects
particle minecraft:squid_ink ~ ~0.5 ~ 1.5 .5 1.5 0.000000001 60
