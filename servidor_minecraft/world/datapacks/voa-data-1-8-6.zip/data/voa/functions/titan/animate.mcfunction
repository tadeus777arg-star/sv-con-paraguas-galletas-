#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Grotesque Titan!

#Head Movement - This code doesn't work?
execute if entity @s[scores={head_animate=0}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=titan] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:470004}}]}
execute if entity @s[scores={head_animate=12}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=titan] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:470001}}]}
execute if entity @s[scores={head_animate=21}] run scoreboard players set @s head_animate 1
##Resets Head Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s head_animate 0
execute if entity @s[scores={head_animate=0}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=titan] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:470004}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F]}
##Detects if mob is moving - Applies head animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s head_animate 1 


#Moving Animation - Body - Armor Stand Method
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=!bloat,distance=0..2.05,scores={animate=3}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470002}}]}
execute if entity @s[scores={animate=3}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.ravager.step hostile @a[distance=0..16]
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=!bloat,distance=0..2.05,scores={animate=6}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470000}}]}
#execute if entity @s[scores={animate=6}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.ravager.step hostile @a[distance=0..16]
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=!bloat,distance=0..2.05,scores={animate=9}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470003}}]}
execute if entity @s[scores={animate=9}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.ravager.step hostile @a[distance=0..16]
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=!bloat,distance=0..2.05,scores={animate=12}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470000}}]}
#execute if entity @s[scores={animate=12}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.ravager.step hostile @a[distance=0..16]
#Moving Animation - Body - BLOAT
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=bloat,distance=0..2.05,scores={animate=3}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470006}}]}
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=bloat,distance=0..2.05,scores={animate=6}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470005}}]}
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=bloat,distance=0..2.05,scores={animate=9}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470007}}]}
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=bloat,distance=0..2.05,scores={animate=12}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470005}}]}
#Resets Animation Variable
execute if entity @e[type=minecraft:zombie,tag=titan,scores={animate=12..}] run scoreboard players set @s animate 1
##Resets Body Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=!bloat,distance=0..2.05,scores={animate=0}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470000}}]}
##Resets Body Moving Animation - BLOAT
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s if entity @e[type=minecraft:zombie,tag=titan,tag=bloat,distance=0..2.05,scores={animate=0}] run data merge entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470005}}]}

##Detects if mob is moving - Applies body animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:titan.mob.hurt hostile @a[distance=0..16]

#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 
