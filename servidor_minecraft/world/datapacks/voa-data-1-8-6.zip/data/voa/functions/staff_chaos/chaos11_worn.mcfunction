#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Staff Charge - #data merge item
item replace entity @s weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Staff: Levitate (10 Charges)"}'},CustomModelData:313131,staffc10:1b} 1

#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_c_cool=45..}] staff_c_cool 0



