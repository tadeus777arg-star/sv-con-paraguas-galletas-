#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#SOUND FILE ABOMINATION
#How long it takes to cool down and distance between each sound
scoreboard players set @s sound_cool 240
playsound minecraft:item.trident.return hostile @a ~ ~ ~ 1.3
#SOUND END