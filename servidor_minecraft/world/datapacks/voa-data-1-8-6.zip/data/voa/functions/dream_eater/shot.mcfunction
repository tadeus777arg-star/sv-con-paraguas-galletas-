#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

playsound minecraft:item.trident.thunder hostile @a ~ ~ ~

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:dream_eater/path

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycasting
tag @s remove los
scoreboard players reset .distance tf_rc

