#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
###  If matches 0 
execute if score out math matches 1 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",PersistenceRequired:1b,Health:100f,Tags:["dream_eater"],CustomName:'{"text":"Dream Eater"}',ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:222000}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:0b,duration:1800000000,show_particles:0b,show_icon:0b}],Attributes:[{Name:generic.max_health,Base:100},{Name:generic.movement_speed,Base:0.2},{Name:generic.attack_damage,Base:8}]}

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute if score out math matches 1 run scoreboard players add @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] atk_cool 0
execute if score out math matches 1 run scoreboard players add @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] sound_cool 0
execute if score out math matches 1 run scoreboard players add @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] titanhealth 0
#execute if score out math matches 1 run scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] proxy 0
#execute if score out math matches 1 run scoreboard players add @e[tag=titan,type=minecraft:zombie,tag=!stats] titanhealth 0

execute if score out math matches 1 run tag @e[tag=dream_eater,type=minecraft:zombie,tag=!stats] add stats

#Kills Marker
tag @s add summoned
