#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

effect give @s minecraft:speed 1 1
