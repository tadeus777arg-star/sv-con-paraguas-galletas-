#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Test for broken code
#say hi

#Mob Sound/Sound Timer/Reset Sound so it happens again
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s mob_demo_time 1
execute if entity @s[scores={mob_demo_time=2}] run playsound minecraft:block.grass.step hostile @a[distance=0..14] ~ ~ ~ 0.2 1
execute if entity @s[scores={mob_demo_time=2}] run particle minecraft:ash ~ ~ ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=6}] run particle minecraft:ash ~ ~ ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=8}] run scoreboard players set @s mob_demo_time 0



#execute if entity @s[scores={mob_demo_time=2}] run playsound minecraft:wraith.mob.wail hostile @a[distance=0..14]
#execute if entity @s[scores={mob_demo_time=80}] run scoreboard players set @s mob_demo_time 0

#Moving Animation
execute if entity @s[scores={animate=1}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123457}}]}
execute if entity @s[scores={animate=11}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123458}}]}

#Resets Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute if entity @s[scores={animate=0}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123456}}]}

#Damage Animation
execute if entity @s[nbt={HurtTime:10s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:9s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:8s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:7s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:6s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:5s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:4s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:3s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:2s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123459}}]}
execute if entity @s[nbt={HurtTime:1s}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=wraith] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:123456}}]}

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:wraith.mob.hurt hostile @a[distance=0..10]

#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 
