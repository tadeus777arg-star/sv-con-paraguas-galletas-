#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
### Execute as Husk
### LCG Spawn

scoreboard players set in math 0
scoreboard players set in1 math 3
function voa:natural_generation/random/range_lcg


### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
execute if score out math matches 3 run summon husk ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/wraith_loot",Health:25f,CanBreakDoors:1b,DrownedConversionTime:99999,Tags:["wraith"],CustomName:'{"text":"Wraith"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:123456}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:jump_boost",amplifier:1b,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:25},{Name:generic.follow_range,Base:40},{Name:generic.movement_speed,Base:0.39},{Name:generic.attack_damage,Base:5},{Name:zombie.spawn_reinforcements,Base:0}]}
execute if score out math matches 3 run tp @s ~ ~-256 ~

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute if score out math matches 3 run scoreboard players add @e[tag=wraith,type=minecraft:husk] sound_cool 0

#Makes the Mob burn possible for every Banshee
execute if score out math matches 3 run scoreboard players add @e[tag=wraith,type=minecraft:husk] skychecker 0
execute if score out math matches 3 run scoreboard players add @e[tag=wraith,type=minecraft:husk] timeofday 0

#Execute for Spectral-Schimitar
tag @e[tag=wraith,type=minecraft:husk] add ghost

###Kills the summoning Armor Stand
tag @s add not_wraith_nether