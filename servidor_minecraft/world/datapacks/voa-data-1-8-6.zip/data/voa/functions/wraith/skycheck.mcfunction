#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#say BURN BURN BURN!
#checks blocks above mob (If there are twenty-five open air blocks above the mob it will burn.)
execute if block ~ ~1 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~2 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~3 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~4 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~5 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~6 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~7 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~8 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~9 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~10 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~11 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~12 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~13 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~14 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~15 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~16 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~17 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~18 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~19 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~20 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~21 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~22 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~23 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~24 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~25 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~26 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~27 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~28 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~29 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~30 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~31 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~32 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~33 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~33 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~34 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~35 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~36 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~37 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~38 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~39 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~40 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~41 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~42 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~43 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~44 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~45 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~46 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~47 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~48 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~49 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~50 ~ minecraft:air run scoreboard players add @s skychecker 1
execute if block ~ ~ ~ minecraft:water run scoreboard players remove @s skychecker 1

#Pass-Fail Burn checker if successful the mob will burn! If Mob takes cover the fire will stop due to fire only allowing for 1 tick.
#The scoreboard is reset to 0 every tick regardless of pass or fail, this is to allow the check to be re-completed.
execute if entity @s[scores={skychecker=1..49}] run scoreboard players set @s skychecker 0
#execute if entity @s[scores={skychecker=50..}] run say IM ON FIRE!
execute if entity @s[scores={skychecker=50..}] run data merge entity @s {Fire:20}
execute if entity @s[scores={skychecker=50..}] run scoreboard players set @s skychecker 0
