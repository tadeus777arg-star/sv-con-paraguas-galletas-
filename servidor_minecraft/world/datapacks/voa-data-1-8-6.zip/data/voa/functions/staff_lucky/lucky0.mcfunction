#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
say EMPTY!
#playsound minecraft:block.fire.extinguish ambient @p[distance=..10]


