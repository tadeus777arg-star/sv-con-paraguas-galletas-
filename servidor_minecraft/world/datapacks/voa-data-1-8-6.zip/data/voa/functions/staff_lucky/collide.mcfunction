## Called from tf_raycast:raycast upon any targets whose hitbox collides with the raycast

#### What you do to the target is up to you

# Detect Headshots/bodyshots/legshots
#execute positioned ~ ~0.35 ~ unless entity @s[dx=0] positioned ~ ~-0.3 ~ run say headshot
#
#execute positioned ~ ~0.35 ~ if entity @s[dx=0] positioned ~ ~-2.3 ~ if entity @s[dx=0] run say chest shot
#
#execute positioned ~ ~-1.95 ~ unless entity @s[dx=0] run say leg shot

#say I have been hit by a raycast. oof
particle cloud ~ ~ ~ 1 1 1 0 10
playsound minecraft:entity.chicken.hurt ambient @a[distance=..12]

execute at @s[type=!wither,type=!ender_dragon,tag=!boss,type=!player,tag=!dream_eater,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,type=!armor_stand] run tag @e[distance=..3,type=!#voa:not_mob] add chkn
execute as @e[type=!wither,type=!ender_dragon,tag=!boss,type=!player,tag=!dream_eater,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,tag=chkn] at @s run summon minecraft:chicken
execute as @e[type=!wither,type=!ender_dragon,tag=!boss,type=!player,tag=!dream_eater,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,tag=chkn] at @s run tp @s ~ ~-256 ~

#execute at @s run damage @s[] 20 minecraft:player_attack at ~ ~ ~


#Titan Mechanic
execute at @s run tag @e[tag=titan,distance=..2] add titanchkn 
execute at @e[tag=titan,tag=titanchkn] run damage @s 50 minecraft:player_attack at ~ ~ ~
execute at @s if entity @e[tag=titan,type=minecraft:zombie,scores={titanhealth=53..},tag=titanchkn] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 20 normal
#If below health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..53},tag=titanchkn] at @s run summon minecraft:chicken
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..53},tag=titanchkn] at @s run tp @s ~ ~-256 ~
execute at @s run tag @e[tag=titan,tag=titanchkn] remove titanchkn


#Warped-Titan Mechanic
execute at @s run tag @e[tag=warpedtitan,distance=..2] add titanchkn 
execute at @e[tag=warpedtitan,tag=titanchkn] run damage @s 50 minecraft:player_attack at ~ ~ ~
execute at @s if entity @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=53..},tag=titanchkn] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 20 normal
#If below health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..53},tag=titanchkn] at @s run summon minecraft:chicken
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..53},tag=titanchkn] at @s run tp @s ~ ~-256 ~
execute at @s run tag @e[tag=warpedtitan,tag=titanchkn] remove titanchkn


#Dream Eater Mechanic
execute at @s run tag @e[tag=dream_eater,distance=..2] add titanchkn 
execute at @e[tag=dream_eater,tag=titanchkn] run damage @s 50 minecraft:player_attack at ~ ~ ~
execute at @s if entity @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=53..},tag=dream_eater] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 20 normal
#If below health
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..53},tag=titanchkn] at @s run summon minecraft:chicken
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..53},tag=titanchkn] at @s run tp @s ~ ~-256 ~
execute at @s run tag @e[tag=dream_eater,tag=titanchkn] remove titanchkn


#Ravager Mechanic
execute at @s run tag @e[type=minecraft:ravager,distance=..2] add titanchkn 
execute at @e[type=minecraft:ravager,tag=titanchkn] run damage @s 50 minecraft:player_attack at ~ ~ ~
execute at @s if entity @e[type=minecraft:ravager,scores={titanhealth=53..},tag=titanchkn] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 20 normal
#If below health
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},tag=titanchkn] at @s run summon minecraft:chicken
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},tag=titanchkn] at @s run tp @s ~ ~-256 ~
execute at @s run tag @e[type=minecraft:ravager,tag=titanchkn] remove titanchkn


#Warden Mechanic
execute at @s run tag @e[type=minecraft:warden,distance=..2] add titanchkn 
execute at @e[type=minecraft:warden,tag=titanchkn] run damage @s 50 minecraft:player_attack at ~ ~ ~
execute at @s if entity @e[type=minecraft:warden,scores={titanhealth=53..},tag=titanchkn] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 20 normal
#If below health
execute as @e[type=minecraft:warden,scores={titanhealth=..53},tag=titanchkn] at @s run summon minecraft:chicken
execute as @e[type=minecraft:warden,scores={titanhealth=..53},tag=titanchkn] at @s run tp @s ~ ~-256 ~
execute at @s run tag @e[type=minecraft:warden,tag=titanchkn] remove titanchkn

#### Max out range to end the raycast
scoreboard players set .distance tf_rc 1000

