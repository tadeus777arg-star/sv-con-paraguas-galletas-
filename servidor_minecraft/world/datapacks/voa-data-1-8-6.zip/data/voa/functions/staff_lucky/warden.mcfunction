#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

scoreboard players add @e[type=minecraft:warden,tag=!healthy] titanhealth 0

tag @s add healthy




