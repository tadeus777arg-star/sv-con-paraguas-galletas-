#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:staff_lucky/path

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Particle And Sound
playsound minecraft:entity.chicken.egg ambient @a[distance=..12]

#Staff Charge - #data merge item
item replace entity @s weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Staff: Chicken Claw (8 Charges)"}'},CustomModelData:333333,staffl8:1b} 1

#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_l_cool=0..}] staff_l_cool 32


