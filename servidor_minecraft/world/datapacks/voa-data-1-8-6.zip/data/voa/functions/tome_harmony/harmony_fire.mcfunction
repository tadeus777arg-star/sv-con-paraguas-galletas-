#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Gives/Clears Effect
effect give @s minecraft:absorption 300 4

#Particle
particle minecraft:happy_villager ~ ~ ~ .7 1 .7 0.3 50 normal
playsound minecraft:willowbee.mob.hurt ambient @a[]

#data merge item
clear @s[tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Overshield"}'},CustomModelData:234446,tome_h:1b} 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 
#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg
#Random Chance - Removal
execute as @s[tag=tome_retry] if score out math matches 1 run clear @s minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Overshield"}'},CustomModelData:234446,tome_h:1b} 1 
execute as @s[tag=tome_retry] if score out math matches 2 run clear @s minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Overshield"}'},CustomModelData:234446,tome_h:1b} 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 
