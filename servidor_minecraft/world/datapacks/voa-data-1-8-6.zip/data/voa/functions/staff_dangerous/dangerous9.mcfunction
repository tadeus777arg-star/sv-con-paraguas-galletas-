#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Summon Fireball
execute at @s anchored eyes run summon minecraft:fireball ^ ^ ^2 {Silent:0b,Fire:20,HasVisualFire:1b,ExplosionPower:5b,power:[0.0,-0.001,0.0],Tags:["dangerball"]}

#Particle
particle minecraft:flame ^ ^ ^2 1 0 1 0.3 125 normal
playsound minecraft:item.firecharge.use ambient @a[distance=..10]

#data merge item
item replace entity @s weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Staff: Firebender (8 Charges)"}'},HideFlags:1,CustomModelData:343434,staffd8:1b} 1


#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_d_cool=0..}] staff_d_cool 40


