#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Summon Fireball
execute at @s anchored eyes run summon minecraft:fireball ^ ^ ^2 {Silent:0b,Fire:20,HasVisualFire:1b,ExplosionPower:5b,power:[0.0,-0.001,0.0],Tags:["dangerball"]}

#Particle
particle minecraft:flame ^ ^ ^2 1 0 1 0.3 125 normal
playsound minecraft:item.firecharge.use ambient @a[distance=..10]

#data merge item
item replace entity @s weapon.mainhand with stick{display:{Name:'{"text":"Unenchanted Staff"}'},CustomModelData:303030,staff:1b} 1
playsound minecraft:item.shield.break ambient @a[distance=..10]

#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_d_cool=0..}] staff_d_cool 40


