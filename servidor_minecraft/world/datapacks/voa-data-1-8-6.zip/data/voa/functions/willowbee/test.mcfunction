#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
execute as @e[type=bee,scores={atk_cool=16000..}] at @s run loot spawn ~ ~ ~ loot voa:entities/willowbee_egg
execute if entity @e[type=minecraft:bee,tag=willowbee,scores={atk_cool=12000..}] run scoreboard players set @s atk_cool 0
execute at @s run playsound minecraft:entity.chicken.egg ambient @a[distance=0..16]