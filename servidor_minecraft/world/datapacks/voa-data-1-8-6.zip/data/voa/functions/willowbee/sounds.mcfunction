#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#How long it takes to cool down and distance between each sound
scoreboard players set @s sound_cool 120
playsound minecraft:willowbee.mob.wail neutral @a[distance=0..16]