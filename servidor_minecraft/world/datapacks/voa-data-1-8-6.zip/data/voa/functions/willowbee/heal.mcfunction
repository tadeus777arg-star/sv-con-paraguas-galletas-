#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#How long it takes to cool down
scoreboard players set @s heal_cool 6000

#Giving the custom attack
effect give @a[distance=0..40] minecraft:absorption 60 2
effect give @a[distance=0..40] minecraft:regeneration 30 1

#particle affects
particle minecraft:heart ~ ~ ~ 0 0 0 .000000001 1 normal

#Chime Sound
playsound minecraft:willowbee.mob.heal neutral @a[distance=0..40]