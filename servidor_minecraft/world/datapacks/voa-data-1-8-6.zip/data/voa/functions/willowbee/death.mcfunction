#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
playsound minecraft:willowbee.mob.death hostile @a[]