#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 7
function voa:natural_generation/random/range_lcg

execute if score out math matches 0 run tag @s add eggie
execute if score out math matches 0 run execute as @e[tag=eggie] at @s run loot spawn ~ ~ ~ loot voa:entities/willowbee_egg
#execute if score out math matches 0 run execute as @e[tag=eggie] at @s run say EGG!
execute if score out math matches 0 run execute at @s run playsound minecraft:entity.chicken.egg ambient @a[]

execute if score out math matches 0 run tag @s remove eggie