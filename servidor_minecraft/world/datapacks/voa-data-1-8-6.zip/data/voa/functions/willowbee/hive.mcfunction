#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Summon Willowbee
summon bee ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/willowbee",PersistenceRequired:1b,Health:25f,Tags:["willowbee"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,PersistenceRequired:1b,Tags:["willowbee_body"],ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:555577}}]}],CustomName:'{"text":"willowbee"}',active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:25},{Name:generic.movement_speed,Base:0.42},{Name:generic.attack_damage,Base:5}]}

tag @s add hived


scoreboard players add @e[type=minecraft:bee,tag=willowbee,tag=!hived,sort=nearest,limit=1] animate 0
scoreboard players add @e[type=minecraft:bee,tag=willowbee,tag=!hived,sort=nearest,limit=1] sound_cool 0
scoreboard players add @e[type=minecraft:bee,tag=willowbee,tag=!hived,sort=nearest,limit=1] heal_cool 0


