#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#----------------------------------------------------------------------------------- Mobs - Horrors ---------------------------------------------------------------------------------------------#

#----------------------------------------------------------------------------------- Abomination ------------------------------------------------------------------------------------------------#
#ABOMINATION MOB START#
### Takes the current Y level and stores it, then passes along the current coordinates
execute as @e[type=minecraft:creeper,tag=!not_abomination] store result score @s yposition run data get entity @s Pos[1]
execute store result score @e[type=minecraft:creeper,tag=!abom_storm] timeofday run time query daytime
execute as @e[type=minecraft:creeper,tag=!not_abomination,scores={yposition=-63..0},sort=random] at @s run function voa:abomination/abomination_spawn

### Hunting Party - Event
#Tests Event if conditions are correct.
execute as @e[type=creeper,tag=!abom_storm,scores={yposition=-63..0},sort=random] at @s if entity @a[distance=..55] run function voa:abomination/abomination_storm

### Armor Stand Rotation for body 
execute as @e[type=minecraft:zombie,tag=abomination] at @s store result entity @e[type=minecraft:armor_stand,tag=abomination_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=abomination_body] at @s unless entity @e[type=minecraft:zombie,tag=abomination,distance=0..2.05] run kill @s

### Initializes Abomination Animation/Sound function
execute as @e[tag=abomination,type=minecraft:zombie] at @s if entity @a[distance=0..60] run function voa:abomination/animate

### Custom Attack Function
execute as @e[tag=abomination,type=minecraft:zombie,scores={atk_cool=0}] at @s if entity @a[distance=0..5] run function voa:abomination/attack
execute as @e[tag=abomination,type=minecraft:zombie,scores={atk_cool=50}] at @s if entity @a[distance=0..5] run function voa:abomination/attack2
### Activates Cooldown functionality
scoreboard players remove @e[tag=abomination,type=minecraft:zombie,scores={atk_cool=1..}] atk_cool 1

### Runs Sound File
execute as @e[tag=abomination,type=minecraft:zombie,scores={sound_cool=0}] at @s if entity @a[distance=0..13] run function voa:abomination/sounds
### Activates Cooldown functionality
execute as @e[tag=abomination,type=minecraft:husk] at @s if entity @a[distance=0..16] run scoreboard players remove @e[tag=abomination,type=minecraft:zombie,scores={sound_cool=1..}] sound_cool 1
#End Abomination Mob#


#----------------------------------------------------------------------------------- Gila Monster ------------------------------------------------------------------------------------------------#
#Gila Monster MOB START#
## ---Gila Monster Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawngila,tag=!summoned] at @s run function voa:gila/gila_spawn
execute as @e[type=minecraft:armor_stand,tag=spawngila,tag=summoned] at @s run kill @s

### Armor Stand Rotation for body 
execute as @e[type=minecraft:zombie,tag=gila] at @s store result entity @e[type=minecraft:armor_stand,tag=gila_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=gila_body] at @s unless entity @e[type=minecraft:zombie,tag=gila,distance=0..2.05] run kill @s

### Initializes Gila Animation/Sound function
execute as @e[tag=gila,type=minecraft:zombie] at @s if entity @a[distance=0..16] run function voa:gila/animate

### Custom Attack Function - REWRITE ATTACK FUNCTION
execute as @e[tag=gila] at @s if entity @a[distance=..1.5] run effect give @a[distance=..1.5] minecraft:blindness 5 0
execute as @e[tag=gila] at @s if entity @a[distance=..1.5] run effect give @a[distance=..1.5] minecraft:wither 5 2

#Gila Egg Model/Function
execute as @e[type=minecraft:item_frame,tag=gila_egg] at @s run function voa:gila/egg_place
execute as @e[type=minecraft:armor_stand,tag=gila_egg] at @s unless block ~ ~ ~ minecraft:purple_concrete run function voa:gila/egg_remove

### Runs Sound File
execute as @e[tag=gila,type=minecraft:zombie,scores={sound_cool=0}] at @s if entity @a[distance=0..13] run function voa:gila/sounds
### Activates Cooldown functionality
execute as @e[tag=gila,type=minecraft:zombie] at @s if entity @a[distance=0..24] run scoreboard players remove @e[tag=gila,type=minecraft:zombie,scores={sound_cool=1..}] sound_cool 1
#End Gila Monster Mob#


#--------------------------------------------------------------------------------- ABYSSAL HORROR ----------------------------------------------------------------------------------------------#
#ABYSSAL HORROR MOB START#
### Abyssal Horror Mob Scan/Allows Swaping naturally ###
execute as @e[type=minecraft:zombified_piglin,tag=!not_abyssal_horror,sort=random] at @s run function voa:abyssal_horror/abyssal_horror_spawn
execute as @e[type=minecraft:piglin,tag=!not_abyssal_horror,sort=random] at @s run function voa:abyssal_horror/abyssal_horror_spawn

### Armor Stand Rotation for body 
execute as @e[type=minecraft:zombie,tag=abyssal_horror] at @s store result entity @e[type=minecraft:armor_stand,tag=abyssal_horror_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=abyssal_horror_body] at @s unless entity @e[type=minecraft:zombie,tag=abyssal_horror,distance=0..2.05] run kill @s

### Initializes Abyssal Horror Animation/Sound function
execute as @e[type=minecraft:zombie,tag=abyssal_horror] at @s if entity @a[distance=0..60] run function voa:abyssal_horror/animate

### Custom Attack Function
execute as @e[tag=abyssal_horror,type=minecraft:zombie,scores={atk_cool=0}] at @s if entity @a[distance=0..6] run function voa:abyssal_horror/attack
execute as @e[tag=abyssal_horror,type=minecraft:zombie,scores={atk_cool=50}] at @s if entity @a[distance=0..6] run function voa:abyssal_horror/attack2

## Activates Cooldown functionality
scoreboard players remove @e[tag=abyssal_horror,type=minecraft:zombie,scores={atk_cool=1..}] atk_cool 1

## Runs Sound File
execute as @e[type=minecraft:zombie,tag=abyssal_horror,scores={sound_cool=0}] at @s if entity @a[distance=0..20] run function voa:abyssal_horror/sounds
## Activates Cooldown functionality
scoreboard players remove @e[tag=abyssal_horror,type=minecraft:zombie,scores={sound_cool=1..}] sound_cool 1
#End ABYSSAL HORROR Mob#


#--------------------------------------------------------------------------------- NETHER DEMON ----------------------------------------------------------------------------------------------#
#NETHER DEMON MOB START#
## Nether Demon Mob Scan/Allows Swaping naturally ###

#This is the Master Command that kicks off Boss Generation - NETHER ONLY!
execute as @a[nbt={Dimension:"minecraft:the_nether"}] at @s if entity @e[type=minecraft:zombified_piglin,tag=!not_nether_demon,limit=1,sort=nearest,distance=..40] run function voa:nether_demon/nether_demon_spawn
#

#### Armor Stand Rotation for body 
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon] at @s store result entity @e[type=minecraft:armor_stand,tag=nether_demon_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=nether_demon_body] at @s unless entity @e[type=minecraft:wither_skeleton,tag=nether_demon,distance=0..2.6] run kill @s
#
#### Initializes Nether Demon Animation/Sound function
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon] at @s if entity @a[distance=0..60] run function voa:nether_demon/animate

#Ready for Fireball - Health Dependent
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={demonhealth=..250},tag=!fireball250] at @s run function voa:nether_demon/fireball/tag250
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={demonhealth=..200},tag=!fireball200] at @s run function voa:nether_demon/fireball/tag200
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={demonhealth=..150},tag=!fireball150] at @s run function voa:nether_demon/fireball/tag150
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={demonhealth=..100},tag=!fireball100] at @s run function voa:nether_demon/fireball/tag100
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={demonhealth=..50},tag=!fireball50] at @s run function voa:nether_demon/fireball/tag50
#Flamethrower Attack or Fireball Attack - Health Dependent Raycast
#execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=90}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=60}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=30}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=20}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=10}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=10}] at @s run effect give @s minecraft:slowness 1 1
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=1}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
#FIRE!
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=..1}] at @s if entity @a[distance=..36] run function voa:nether_demon/flamethrower_attack

#Sees if a Player is nearby
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,tag=!playernearby] at @s if entity @a[distance=..36] run tag @s add playernearby
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,tag=playernearby] at @s unless entity @a[distance=..36] run tag @s remove playernearby

#Raycast For Flamethrower Attack
execute as @e[tag=flamethrower_ball,tag=!not_rotated] at @s run function voa:nether_demon/flamethrower_raycast

### Activates Cooldown functionality
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,tag=playernearby,scores={atk_flamethrower=1..}] at @s if entity @a[distance=..36] run scoreboard players remove @e[tag=nether_demon,tag=playernearby,type=minecraft:wither_skeleton,scores={atk_flamethrower=1..}] atk_flamethrower 1
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={atk_flamethrower=..111}] at @s unless entity @a[distance=..36] run scoreboard players add @e[tag=nether_demon,type=minecraft:wither_skeleton,scores={atk_flamethrower=..111}] atk_flamethrower 1

### Piglin Conversion - Turns Piglins into Abyssal Horrors
execute as @e[type=minecraft:piglin] at @s if entity @e[type=minecraft:wither_skeleton,tag=nether_demon,distance=..2.05] run function voa:nether_demon/summon_abyssal

### Runs Sound File
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,scores={sound_cool=0}] at @s if entity @a[distance=0..32] run function voa:nether_demon/sounds
### Activates Cooldown functionality
scoreboard players remove @e[tag=nether_demon,type=minecraft:wither_skeleton,scores={sound_cool=1..}] sound_cool 1

###Boss Utilities
#Boss Bar
execute store result bossbar bossbar:nether_demon value as @e[type=minecraft:wither_skeleton,tag=boss,tag=nether_demon,limit=1,sort=nearest] run data get entity @s Health
#Displaying Boss Bar
execute if entity @e[type=minecraft:wither_skeleton,tag=boss,tag=nether_demon] run bossbar set bossbar:nether_demon visible true
execute unless entity @e[type=minecraft:wither_skeleton,tag=boss,tag=nether_demon] run bossbar set bossbar:nether_demon visible false
execute unless entity @e[type=minecraft:wither_skeleton,tag=boss,tag=nether_demon] run bossbar set bossbar:nether_demon players
#Displaying Distance for Boss Bar
execute at @e[type=minecraft:wither_skeleton,tag=boss,tag=nether_demon] run bossbar set bossbar:nether_demon players @a[distance=..120]

#Player Detection - Seeks nearby player
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,tag=!playerdetect] at @s if entity @e[type=minecraft:player,distance=..40] run function voa:nether_demon/playerdetect
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon,tag=playerdetect] at @s unless entity @e[type=minecraft:player,distance=..40] run tag @s remove playerdetect

#Stores Health
execute as @e[type=minecraft:wither_skeleton,tag=nether_demon] run execute store result score @s demonhealth run data get entity @s Health

##End NETHER DEMON Mob#


#--------------------------------------------------------------------------------- ENDER DEMON ----------------------------------------------------------------------------------------------#
#ENDER DEMON MOB START#
## Nether Demon Mob Scan/Allows Swaping naturally ###

#Wake-Up Functionality - Spawn Boss
execute as @e[type=minecraft:armor_stand,tag=wakeup] at @s if entity @a[distance=0..6] run tag @e[type=minecraft:armor_stand,tag=spawnenderdemon,distance=..60] add wake_up
##This is the Master Command that kicks off Boss Generation - NETHER ONLY!
execute as @e[type=minecraft:armor_stand,tag=spawnenderdemon,tag=!summoned,tag=wake_up] at @s run function voa:ender_demon/ender_demon_spawn
#execute as @e[type=minecraft:armor_stand,tag=wakeup] at @s if entity @e[type=minecraft:armor_stand,tag=spawnenderdemon,tag=wake_up,distance=..60] run kill @s
execute as @e[type=minecraft:armor_stand,tag=spawnenderdemon,tag=summoned] at @s run kill @s

##### Armor Stand Rotation for body 
execute as @e[type=minecraft:wither_skeleton,tag=ender_demon] at @s store result entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s unless entity @e[type=minecraft:wither_skeleton,tag=ender_demon,distance=0..2.6] run kill @s
##
##### Initializes Nether Demon Animation/Sound function
execute as @e[type=minecraft:wither_skeleton,tag=ender_demon] at @s if entity @a[distance=0..60] run function voa:ender_demon/animate
#

#--Custom Attack Overview
### Custom Attack Function - Dash/Teleport
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_cool=80}] at @s if entity @a[distance=..50] run tag @e[type=minecraft:armor_stand,tag=wakeup,distance=..50] add gas_attack_chance
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_cool=25}] at @s unless entity @a[distance=..12] run function voa:ender_demon/teleport_attack
execute as @e[tag=ender_warp,type=minecraft:armor_stand] at @s run particle minecraft:crit ~ ~ ~ 1 1 1 .1 5
execute as @e[tag=ender_warp,type=minecraft:armor_stand] at @s run particle minecraft:flame ~ ~ ~ 0 1 0 .1 1
### Custom Attack Function - Gas_Traps
execute as @e[tag=gas_attack_chance,type=minecraft:armor_stand] at @s run function voa:ender_demon/gas_attack
execute as @e[tag=gas_attack_ready,type=minecraft:armor_stand] at @s run particle minecraft:squid_ink ~ ~ ~ 1 1 1 .1 10
#Main Dropdown
execute as @e[tag=wakeup_dropdown,tag=woken,type=minecraft:armor_stand] at @s run effect give @a[distance=..3] minecraft:wither 1 3 
execute as @e[tag=wakeup_dropdown,tag=woken,type=minecraft:armor_stand] at @s run particle minecraft:squid_ink ~ ~ ~ 1 1 1 .1 10
#Stops Active Gas Traps After Boss is defeated
execute as @e[type=minecraft:armor_stand,tag=wakeup,tag=woken] at @s unless entity @e[tag=ender_demon,type=minecraft:wither_skeleton,distance=..60] run kill @s
execute as @e[type=minecraft:armor_stand,tag=wakeup_dropdown,tag=woken] at @s unless entity @e[tag=ender_demon,type=minecraft:wither_skeleton,distance=..80] run kill @s
### Custom Attack Function - Snare Attack
#execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s run say SNARE!
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s unless entity @a[distance=..12] run tag @s remove snare_attack
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s run effect give @a[distance=..12] minecraft:wither 1 5
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s run effect give @a[distance=..12] minecraft:blindness 2 0
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s run effect give @a[distance=..12] minecraft:slowness 1 2
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s run playsound minecraft:item.bone_meal.use ambient @a
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=snare_attack] at @s run effect give @s[] minecraft:slowness 1 10



##----------All Attack Executions Happen In the Frenzy_attack File <-- This is the big execution File - MAIN ATTACK FILE
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_cool=0}] at @s run function voa:ender_demon/frenzy_attack
### Custom Attack Function - Dash_Remove
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_dash_cool=59}] at @s run playsound minecraft:demon.mob.rush hostile @a ~ ~ ~ 2
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_dash_cool=59}] at @s run effect clear @s minecraft:slowness
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_dash_cool=59}] at @s run effect clear @s minecraft:weakness
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_dash_cool=59}] at @s run effect give @a[distance=..6] minecraft:instant_damage 1 2
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_dash_cool=0}] at @s run function voa:ender_demon/frenzy_attack_stop
#Constant Darkness
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton] at @s run effect give @a[distance=..50] minecraft:darkness
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton] at @s run effect give @a[distance=..4] minecraft:wither 1 2
#--Custom Attack End

#### Runs Sound File
execute as @e[type=minecraft:wither_skeleton,tag=ender_demon,scores={sound_cool=0}] at @s if entity @a[distance=0..32] run function voa:ender_demon/sounds
#### Activates Cooldown functionality
scoreboard players remove @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={sound_cool=1..}] sound_cool 1
scoreboard players remove @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[tag=ender_demon,type=minecraft:wither_skeleton,scores={atk_dash_cool=1..}] atk_dash_cool 1
#
###Boss Utilities
#Boss Bar
execute store result bossbar bossbar:ender_demon value as @e[type=minecraft:wither_skeleton,tag=boss,tag=ender_demon,limit=1,sort=nearest] run data get entity @s Health
#Displaying Boss Bar
execute if entity @e[type=minecraft:wither_skeleton,tag=boss,tag=ender_demon] run bossbar set bossbar:ender_demon visible true
execute unless entity @e[type=minecraft:wither_skeleton,tag=boss,tag=ender_demon] run bossbar set bossbar:ender_demon visible false
execute unless entity @e[type=minecraft:wither_skeleton,tag=boss,tag=ender_demon] run bossbar set bossbar:ender_demon players
#Displaying Distance for Boss Bar
execute at @e[type=minecraft:wither_skeleton,tag=boss,tag=ender_demon] run bossbar set bossbar:ender_demon players @a[distance=..120]
#Stores Health
execute as @e[type=minecraft:wither_skeleton,tag=ender_demon] run execute store result score @s demonhealth run data get entity @s Health

##End ENDER DEMON Mob#



#--------------------------------------------------------------------------------- Grotesque Titan ----------------------------------------------------------------------------------------------#
## Grotesque Titan MOB START#
## ---Grotesque Titan Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawntitan,tag=!summoned] at @s run function voa:titan/titan_spawn
execute as @e[type=minecraft:armor_stand,tag=spawntitan,tag=summoned] at @s run kill @s

### Armor Stand Rotation for body 
execute as @e[type=minecraft:zombie,tag=titan] at @s store result entity @e[type=minecraft:armor_stand,tag=titan_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=titan_body] at @s unless entity @e[type=minecraft:zombie,tag=titan,distance=0..2.05] run kill @s

### Initializes Grotesque Titan Animation/Sound function
execute as @e[type=minecraft:zombie,tag=titan] at @s if entity @a[distance=0..50] run function voa:titan/animate

### Custom Attack Function
execute as @e[tag=titan,type=minecraft:zombie,scores={atk_cool=0}] at @s if entity @a[distance=0..6] run function voa:titan/attack

## Activates Cooldown functionality
scoreboard players remove @e[tag=titan,type=minecraft:zombie,scores={atk_cool=1..}] atk_cool 1

## Runs Sound File
execute as @e[type=minecraft:zombie,tag=titan,scores={sound_cool=0}] at @s if entity @a[distance=0..20] run function voa:titan/sounds
## Activates Cooldown functionality
scoreboard players remove @e[tag=titan,type=minecraft:zombie,scores={sound_cool=1..}] sound_cool 1

#Stores Health
execute as @e[tag=titan,type=minecraft:zombie] run execute store result score @s titanhealth run data get entity @s Health
#End Grotesque Titan Mob#


#--------------------------------------------------------------------------------- Warped Titan ----------------------------------------------------------------------------------------------#
## Warped Titan MOB START#
## ---Warped Titan Spawn#
execute as @e[type=minecraft:enderman,tag=!not_warped_titan] at @s run function voa:warped_titan/warped_titan_spawn

#### Armor Stand Rotation for body 
execute as @e[type=minecraft:zombie,tag=warpedtitan] at @s store result entity @e[type=minecraft:armor_stand,tag=warped_titan_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=warped_titan_body] at @s unless entity @e[type=minecraft:zombie,tag=warpedtitan,distance=0..2.05] run kill @s
#
#### Initializes Abyssal Horror Animation/Sound function
execute as @e[type=minecraft:zombie,tag=warpedtitan] at @s if entity @a[distance=..60] run function voa:warped_titan/animate
#
#### Custom Attack Function
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={atk_cool=0}] at @s if entity @a[distance=0..3] run function voa:warped_titan/attack
#
#### Teleport Attack
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=90}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=60}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=30}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=20}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=10}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=1}] at @s run playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 2
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!warpattack,scores={atk_teleport=..1}] at @s if entity @a[distance=..12] run function voa:warped_titan/teleport_attack

##Teleports Titan to player
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=warpattack,scores={atk_teleport=112}] at @s if entity @a[distance=..12,tag=teletitan] run function voa:warped_titan/teleport_attack_player
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=warpattack] at @s unless entity @a[distance=..12] run tag @s remove warpattack

#Sees if a Player is nearby
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=!playernearby] at @s if entity @a[distance=..12] run tag @s add playernearby
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=playernearby] at @s unless entity @a[distance=..12] run tag @s remove playernearby

#Raycast For Teleport Attack
execute as @e[tag=teleport_ball,tag=!not_rotated] at @s run function voa:warped_titan/teleport_raycast

### Activates Cooldown functionality
scoreboard players remove @e[tag=warpedtitan,type=minecraft:zombie,scores={atk_cool=1..}] atk_cool 1
#
### Runs Sound File
execute as @e[type=minecraft:zombie,tag=warpedtitan,scores={sound_cool=0}] at @s if entity @a[distance=0..20] run function voa:warped_titan/sounds

### Activates Cooldown functionality
scoreboard players remove @e[tag=warpedtitan,type=minecraft:zombie,scores={sound_cool=1..}] sound_cool 1
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=playernearby,tag=!warpattack,scores={atk_teleport=1..}] at @s if entity @a[distance=..12] run scoreboard players remove @e[tag=warpedtitan,tag=playernearby,type=minecraft:zombie,scores={atk_teleport=1..}] atk_teleport 1
execute as @e[type=minecraft:zombie,tag=warpedtitan,scores={atk_teleport=..111}] at @s unless entity @a[distance=..12] run scoreboard players add @e[tag=warpedtitan,type=minecraft:zombie,scores={atk_teleport=..111}] atk_teleport 1

##Stores Health
execute as @e[tag=warpedtitan,type=minecraft:zombie] run execute store result score @s titanhealth run data get entity @s Health
#End Warped Titan Mob#


#----------------------------------------------------------------------------------- Dream Eater------------------------------------------------------------------------------>
#---Dream Eater Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawndreameater,tag=!summoned] at @s if entity @a[distance=..20] run function voa:dream_eater/dream_eater_spawn
execute as @e[type=minecraft:armor_stand,tag=spawndreameater,tag=summoned] at @s run kill @s

#Initializes Spectre Animation/Sound function
execute as @e[tag=dream_eater,type=minecraft:zombie] at @s if entity @a[distance=0..40] run function voa:dream_eater/animate

#Runs Sounds
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={sound_cool=0}] at @s if entity @a[distance=0..16] run function voa:dream_eater/sounds

#Attack Sequence
#Checks for Line of Sight
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..6}] at @s if entity @a[distance=..12] run function voa:dream_eater/los_shot
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..5}] at @s if entity @a[distance=..12] run function voa:dream_eater/los_shot
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..4}] at @s if entity @a[distance=..12] run function voa:dream_eater/los_shot
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..3}] at @s if entity @a[distance=..12] run function voa:dream_eater/los_shot
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..2}] at @s if entity @a[distance=..12] run function voa:dream_eater/los_shot
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..1}] at @s if entity @a[distance=..12] run function voa:dream_eater/los_shot
#Actual Attack - takes the shot 
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=los] at @s if entity @a[distance=..12] run function voa:dream_eater/shot
execute as @e[type=minecraft:zombie,tag=dream_eater,tag=!los,scores={atk_cool=..1}] at @s if entity @a[distance=..12] run scoreboard players set @e[tag=dream_eater,type=minecraft:zombie,scores={atk_cool=..1}] atk_cool 50


## Activates Cooldown functionality
scoreboard players remove @e[tag=dream_eater,type=minecraft:zombie,scores={sound_cool=1..},tag=frenzied] sound_cool 1
scoreboard players remove @e[tag=dream_eater,type=minecraft:zombie,scores={atk_cool=1..}] atk_cool 1

#Stores Health
execute as @e[tag=dream_eater,type=minecraft:zombie] run execute store result score @s titanhealth run data get entity @s Health
#End Grotesque Titan Mob#
