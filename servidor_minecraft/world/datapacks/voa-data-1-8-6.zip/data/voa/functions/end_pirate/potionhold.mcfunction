#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Giving the custom attack
data merge entity @s[] {HandItems:[{id:"minecraft:diamond_sword",Count:1b},{id:"minecraft:air",Count:1b}],HandDropChances:[-327.670F,-327.670F]}
summon potion ~ ~ ~ {Item:{id:"minecraft:splash_potion",Count:1b,tag:{custom_potion_effects:[{id:"minecraft:instant_damage",amplifier:3b,duration:1},{id:"minecraft:poison",amplifier:2b,duration:200}]}}}
tag @s remove potionhold
