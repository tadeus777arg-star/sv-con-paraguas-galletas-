#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs Sound at Player
playsound minecraft:entity.egg.throw ambient @a[] 
particle minecraft:happy_villager ~ ~ ~ 2 2 2 .2 200 normal

execute as @e[type=!player,type=!#voa:not_mob,distance=..5,tag=!ring,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,tag=!dream_eater,type=!wither,type=!ender_dragon,tag=!boss] at @s run tag @s add ring
execute as @e[type=!player,type=!#voa:not_mob,distance=..5,tag=ring,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,tag=!dream_eater,type=!wither,type=!ender_dragon,tag=!boss] at @s run playsound minecraft:entity.rabbit.death player @a ~ ~ ~ 
execute as @e[type=!player,type=!#voa:not_mob,tag=ring,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,type=!wither,tag=!dream_eater,type=!ender_dragon,tag=!boss] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[type=!player,type=!#voa:not_mob,tag=ring,tag=!titan,tag=!warpedtitan,type=!ravager,type=!warden,type=!wither,tag=!dream_eater,type=!ender_dragon,tag=!boss] at @s run summon rabbit ~ ~ ~
execute as @e[tag=ring] at @s run tp @s ~ ~-256 ~

#Titan Mechanic
#Execute if above 50% Health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon rabbit ~ ~ ~
execute at @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:entity.rabbit.death player @a ~ ~ ~ 
execute at @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[tag=titan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Warped-Titan Mechanic
#Execute if above 50% Health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon rabbit ~ ~ ~
execute at @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:entity.rabbit.death player @a ~ ~ ~ 
execute at @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[tag=warpedtitan,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Dream_Eater Mechanic
#Execute if above 50% Health
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=50..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run summon rabbit ~ ~ ~
execute at @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run playsound minecraft:entity.rabbit.death player @a ~ ~ ~ 
execute at @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[tag=dream_eater,type=minecraft:zombie,scores={titanhealth=..50},distance=..5] at @s run tp @s ~ ~-256 ~

#Ravager Mechanic
#Execute if above 50% Health
execute as @e[type=minecraft:ravager,scores={titanhealth=53..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[type=minecraft:ravager,scores={titanhealth=53..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run summon rabbit ~ ~ ~
execute at @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run playsound minecraft:entity.rabbit.death player @a ~ ~ ~ 
execute at @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[type=minecraft:ravager,scores={titanhealth=..53},distance=..5] at @s run tp @s ~ ~-256 ~

#Warden Mechanic
#Execute if above 50% Health
execute as @e[type=minecraft:warden,scores={titanhealth=53..},distance=..5] at @s run damage @s 50 minecraft:player_attack at ~ ~ ~
execute as @e[type=minecraft:warden,scores={titanhealth=53..},distance=..5] at @s run particle minecraft:angry_villager ~ ~ ~ 1 1 1 1 10 normal
#Execute if below 50% Health
execute as @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run summon rabbit ~ ~ ~
execute at @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run playsound minecraft:entity.rabbit.death player @a ~ ~ ~ 
execute at @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run particle minecraft:large_smoke ~ ~ ~ 3 3 3 0.3 50 normal
execute as @e[type=minecraft:warden,scores={titanhealth=..53},distance=..5] at @s run tp @s ~ ~-256 ~

#data merge item- If they don't have Tome Armor on.
clear @s[tag=!tome_reuse_helm,tag=!tome_reuse_chest,tag=!tome_reuse_legs,tag=!tome_reuse_boots] minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Ring of Rabbit"}'},CustomModelData:234447,tome_l:1b} 1

#Tome Reuse Tags - If they do have Tome Armor on.
execute as @s[tag=tome_reuse_helm] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_chest] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_legs] at @s run tag @s add tome_retry 
execute as @s[tag=tome_reuse_boots] at @s run tag @s add tome_retry 
#RNG
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg
#Random Chance - Removal
execute as @s[tag=tome_retry] if score out math matches 1 run clear @s[] minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Ring of Rabbit"}'},CustomModelData:234447,tome_l:1b} 1
execute as @s[tag=tome_retry] if score out math matches 2 run clear @s[] minecraft:carrot_on_a_stick{display:{Name:'{"text":"Tome: Ring of Rabbit"}'},CustomModelData:234447,tome_l:1b} 1

#Tags - Tome Retry Removal
execute as @s at @s run tag @s remove tome_retry 