#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

playsound minecraft:fortress.music.ambient music @p[distance=0..60] ~ ~ ~ 3
