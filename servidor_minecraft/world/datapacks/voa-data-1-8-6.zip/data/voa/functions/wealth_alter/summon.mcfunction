#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Plays Sound adds Heart Effect
execute at @s run playsound minecraft:entity.player.levelup ambient @a[distance=..20]
execute as @e[type=minecraft:item_frame,tag=wealth,tag=placed,sort=nearest,limit=1] at @s run particle minecraft:heart ~ ~ ~ 0 0 0 0.50 40
#Adds Tag so that the function is only ran once.
execute as @e[type=minecraft:item_frame,tag=wealth,tag=placed,sort=nearest,limit=1] at @s run tag @s add used
#Spawns the loot
execute as @e[type=minecraft:item_frame,tag=wealth,tag=placed,limit=1,sort=nearest] at @s run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_heavy"} replace


#KILL ITEM FRAME
kill @e[type=minecraft:item_frame,tag=wealth,tag=placed,tag=used,limit=1,sort=nearest]