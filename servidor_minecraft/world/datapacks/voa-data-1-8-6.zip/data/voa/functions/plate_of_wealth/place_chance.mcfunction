#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# AS AND AT POSITION of custom item frame 
#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 10
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens 
execute if score out math matches 5 run summon item_frame ~ ~ ~ {CustomNameVisible:0b,Facing:1b,Invulnerable:1b,Invisible:1b,Fixed:1b,Tags:["wealth"],CustomName:'{"text":"Plate of Wealth"}',Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:222223}}}


tag @s add summoned
