#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#SUMMON DROPS
summon item ~ ~0.5 ~ {Item:{id:"minecraft:item_frame",Count:1b,tag:{display:{Name:'{"text":"Plate of Wealth"}'},CustomModelData:222223,EntityTag:{Silent:1b,Tags:["wealth"],Item:{id:'minecraft:item_frame',Count:1b,tag:{CustomModelData:222223}},Invulnerable:1b,Invisible:1b,Fixed:1b,Facing:1}}}}


#KILL BLOCK DROP - PREVENTS Silk Touch!
kill @e[type=item,nbt={Item:{id:"minecraft:quartz_slab"}},distance=0..2,sort=nearest,limit=1]


#KILL ITEM FRAME
kill @s