#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down and distance between each sound


#Find a nearby Warp Point to Warp to
execute as @r at @s if entity @e[type=minecraft:armor_stand,tag=wakeup,tag=!wakeup_middle,distance=..4] run tag @e[type=minecraft:armor_stand,tag=wakeup,tag=!wakeup_middle,limit=1,sort=nearest] add ender_warp
execute as @e[type=minecraft:armor_stand,tag=ender_warp] at @s run playsound minecraft:demon.mob.portal hostile @a ~ ~ ~ 2
#B-E-A-G-L-E-B-L-O-C-K-S