#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs once
tag @s add fireball250
tag @s add fireballready

