#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


summon wither_skeleton ~ ~ ~ {Silent:1b,CustomNameVisible:0b,PersistenceRequired:1b,DeathLootTable:"voa:entities/end/ender_demon",Health:800f,Tags:["ender_demon","boss"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["ender_demon_body"],ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670500}}]}],CustomName:'{"text":"Greedox - Ender Demon"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670501}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:fire_resistance",amplifier:1b,duration:999999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:800},{Name:generic.follow_range,Base:40},{Name:generic.knockback_resistance,Base:0.9},{Name:generic.movement_speed,Base:0.21},{Name:generic.attack_damage,Base:28},{Name:generic.attack_knockback,Base:12}]}


### INITALIZES CUSTOM ATTACK VARIA5LE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] atk_cool 140 
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] sound_cool 0
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] atk_dash_cool 0 
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] at @s run scoreboard players add @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] atk_snare_cool 0 
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] at @s run tag @e[tag=ender_demon,type=minecraft:wither_skeleton,tag=!stats] add stats
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton] at @s run tag @e[type=minecraft:armor_stand,tag=wakeup,distance=..80] add woken
execute as @e[tag=ender_demon,type=minecraft:wither_skeleton] at @s run tag @e[type=minecraft:armor_stand,tag=wakeup_dropdown,distance=..80] add woken

#Kills Marker
tag @s add summoned
