#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down and distance between each sound

#say GAS!

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 1
function voa:natural_generation/random/range_lcg

#Going to Gas attack - Distance is already set from Command Above
execute if score out math matches 1 run tag @s add gas_attack_ready
execute if score out math matches 1 run playsound minecraft:entity.generic.extinguish_fire hostile @a ~ ~ ~
#Removes Chance Tag so it can be set again.
execute as @s at @s run tag @s remove gas_attack_chance

#B-E-A-G-L-E-B-L-O-C-K-S