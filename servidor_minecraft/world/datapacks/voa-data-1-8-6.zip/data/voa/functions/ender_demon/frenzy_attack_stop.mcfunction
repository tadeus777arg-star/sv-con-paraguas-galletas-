#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down and distance between each sound
tag @s remove frenzy
effect clear @s minecraft:speed

#B-E-A-G-L-E-B-L-O-C-K-S