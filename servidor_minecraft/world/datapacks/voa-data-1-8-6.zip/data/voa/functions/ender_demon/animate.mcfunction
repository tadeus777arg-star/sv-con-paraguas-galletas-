#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Ender Demon!

#Moving Animation - Body - Armor Stand Method - Slow Walk
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=!frenzy,distance=0..3,scores={animate=10}] run data merge entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670503}}]}
execute if entity @s[scores={animate=10},tag=!frenzy] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.hoglin.step hostile @a[] ~ ~ ~ 3
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=!frenzy,distance=0..3,scores={animate=20}] run data merge entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670504}}]}
execute if entity @s[scores={animate=20},tag=!frenzy] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.hoglin.step hostile @a[] ~ ~ ~ 3
execute if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=!frenzy,distance=0..3,scores={animate=20..}] run scoreboard players set @s animate 1

#Moving Animation - Body - Armor Stand Method - Frenzy Attack
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=frenzy,distance=0..3,scores={animate=4}] run data merge entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670503}}]}
execute if entity @s[scores={animate=4},tag=frenzy] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.hoglin.step hostile @a[] ~ ~ ~ 3
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=frenzy,distance=0..3,scores={animate=8}] run data merge entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670504}}]}
execute if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=frenzy,distance=0..3,scores={animate=8..}] run scoreboard players set @s animate 1

##Resets Body Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=!snare_attack,tag=ender_demon,distance=0..3,scores={animate=0}] run data merge entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670500}}]}
##Detects if mob is moving - Applies body animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:horror.mob.hurt master @a[]

#Casting Animation 
execute as @e[type=minecraft:armor_stand,tag=ender_demon_body] at @s if entity @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=snare_attack,distance=0..3] run data merge entity @e[type=minecraft:armor_stand,tag=ender_demon_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:670505}}]}
execute as @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=snare_attack] at @s run particle minecraft:soul_fire_flame ~ ~3.75 ~ 0.2 0.2 0.2 0.1 3 
execute as @e[type=minecraft:wither_skeleton,tag=ender_demon,tag=snare_attack] at @s run particle minecraft:soul_fire_flame ~ ~3.75 ~ 0.5 0.5 0.5 0.1 2 

#Snare Attack tag removal
execute if entity @s[nbt={HurtTime:10s},tag=snare_attack] run tag @s remove snare_attack
execute if entity @s[nbt={HurtTime:9s},tag=snare_attack] run tag @s remove snare_attack
execute if entity @s[nbt={HurtTime:8s},tag=snare_attack] run tag @s remove snare_attack
execute if entity @s[nbt={HurtTime:7s},tag=snare_attack] run tag @s remove snare_attack
execute if entity @s[nbt={HurtTime:6s},tag=snare_attack] run tag @s remove snare_attack
execute if entity @s[nbt={HurtTime:5s},tag=snare_attack] run tag @s remove snare_attack
