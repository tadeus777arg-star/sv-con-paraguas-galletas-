#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down and distance between each sound
#say CHARGE!

#Snare Attack - Every 28 Seconds
scoreboard players add @s atk_snare_cool 1


#If Player is not nearby - Ender Demon will Teleport
execute as @e[tag=gas_attack_ready,type=minecraft:armor_stand] at @s run effect give @a[distance=..5.5] minecraft:wither 3 3 
execute as @e[tag=gas_attack_ready,type=minecraft:armor_stand] at @s run effect give @a[distance=..5.5] minecraft:instant_damage 1 2
execute as @e[tag=gas_attack_ready,type=minecraft:armor_stand] at @s run playsound minecraft:entity.illusioner.cast_spell hostile @a ~ ~ ~ 1
execute as @e[tag=gas_attack_ready,type=minecraft:armor_stand] at @s run particle minecraft:dragon_breath ~ ~ ~ 2 2 2 .20 2000
execute as @e[tag=gas_attack_ready,type=minecraft:armor_stand] at @s run tag @s remove gas_attack_ready

#If Player is not nearby - Ender Demon will Teleport
execute as @s run tp @e[tag=ender_warp,type=minecraft:armor_stand,distance=..60,limit=1,sort=nearest]
execute as @e[tag=ender_warp,type=minecraft:armor_stand,distance=..60] at @s run playsound minecraft:demon.mob.teleport hostile @a ~ ~ ~ 2
execute as @e[tag=ender_warp,type=minecraft:armor_stand,distance=..60] at @s run particle minecraft:white_smoke ~ ~ ~ 1 1 1 .20 500
execute as @e[tag=ender_warp,type=minecraft:armor_stand,distance=..60] at @s run tag @s remove ender_warp

#Sets Snare attack - TAG IS REMOVED IN ANIMATION FILE UPON TAKING DAMAGE - Can teleport AND SNARE!
execute as @s[scores={atk_snare_cool=4}] at @s if entity @a[distance=..12] run tag @s add snare_attack
#Heals Ender_Demon As long as he is snaring enemies.
execute as @s[tag=snare_attack] at @s run effect give @s minecraft:instant_damage 1 2
#execute as @s[scores={atk_snare_cool=4}] at @s run say Four-times!
execute as @s[scores={atk_snare_cool=4}] at @s run scoreboard players set @s atk_snare_cool 0


#If Player is nearby - Always Do Third - Dash Attack
scoreboard players set @s atk_dash_cool 60
tag @s add frenzy
effect give @s minecraft:speed infinite 2


#Resets Attack Scoreboard for Both Conditions
scoreboard players set @s atk_cool 140
#Keeps Track fo special attack


#B-E-A-G-L-E-B-L-O-C-K-S