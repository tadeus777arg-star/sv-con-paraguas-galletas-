#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down and distance between each sound
scoreboard players set @s sound_cool 120
playsound minecraft:demon.mob.wail hostile @a[] ~ ~ ~ 2

#B-E-A-G-L-E-B-L-O-C-K-S