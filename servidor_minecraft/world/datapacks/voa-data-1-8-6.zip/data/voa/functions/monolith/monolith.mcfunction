#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Spawn Structure
#setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -17, mode: "LOAD", posY: -7, sizeX: 34, posZ: -20, integrity: 1.0f, showair: 0b, name: "voa:manor1", id: "minecraft:structure_block", sizeY: 26, sizeZ: 40, showboundingbox: 1b}
setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -17, mode: "LOAD", posY: -8, sizeX: 35, posZ: -17, integrity: 1.0f, showair: 0b, name: "voa:mont_one", id: "minecraft:structure_block", sizeY: 34, sizeZ: 35, showboundingbox: 1b}
setblock ~ ~1 ~ minecraft:redstone_block

#Tower 2
setblock ~ ~25 ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -17, mode: "LOAD", posY: 1, sizeX: 35, posZ: -17, integrity: 1.0f, showair: 0b, name: "voa:mont_two", id: "minecraft:structure_block", sizeY: 34, sizeZ: 35, showboundingbox: 1b}
setblock ~ ~24 ~ minecraft:redstone_block

#Tower 3
setblock ~ ~48 ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -17, mode: "LOAD", posY: 2, sizeX: 35, posZ: -17, integrity: 1.0f, showair: 0b, name: "voa:mont_three", id: "minecraft:structure_block", sizeY: 34, sizeZ: 35, showboundingbox: 1b}
setblock ~ ~47 ~ minecraft:redstone_block


#Setting Air Tower 2
setblock ~ ~25 ~ minecraft:air
setblock ~ ~24 ~ minecraft:air

#Setting Air Tower 3
setblock ~ ~48 ~ minecraft:air
setblock ~ ~47 ~ minecraft:air

tag @s add summoned