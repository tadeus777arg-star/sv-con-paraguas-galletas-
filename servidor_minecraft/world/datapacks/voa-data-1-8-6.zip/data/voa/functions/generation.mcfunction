#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This is the lengthy spawn in process for the Monastery
#It includes a staggered spawn sequence, as well as some QC processes to ensure that rooms accurately spawn.
#Sponges are added as water somehow ALWAYS finds its way into the Monastery
#----------------------------------------------------------------------------------- Natural Generation - Monastery---------------------------------------------------------------------------------------------#
#Monastery Spawn Test - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=!summoned] at @s run function voa:oblisk/spawn
execute as @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=..0}] at @s run kill @s
execute as @e[type=minecraft:armor_stand,tag=vaultstart,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=160},distance=..400] run function voa:natural_generation/vault_start/vault_start_spawn
execute as @e[type=minecraft:armor_stand,tag=basement_sponge_monastery,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=160},distance=..400] run function voa:natural_generation/vault_start/stairs_sponge
execute as @e[type=minecraft:armor_stand,tag=vaultstart,tag=summoned] at @s run kill @s
execute as @e[type=minecraft:armor_stand,tag=basement_sponge_monastery,tag=summoned] at @s run kill @s

execute as @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=155},distance=..400] run function voa:natural_generation/hallways/bossroomgeneration

#Important! This code manages both North and South Dungeon "Sprawls" 
##--- Vault-North-Hallway Marker
#QC Marker Based off of Boss Spawn
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned,tag=bossnorth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=150},distance=..400] run summon armor_stand ~ ~-7 ~-109 {NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["qcnorth"],CustomName:'{"text":"North QC Cap Boss"}'}
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned,tag=!bossnorth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=150},distance=..400] run summon armor_stand ~ ~-7 ~-109 {NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["qcnorthnob"],CustomName:'{"text":"North QC Cap"}'}
#Normal Room Spawn16
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=150},distance=..400] run function voa:natural_generation/hallways/northhallway_spawn
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=130},distance=..400] run function voa:natural_generation/hallways/northhallway_spawn_cap
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned,tag=bossnorth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=120},distance=..400] run function voa:natural_generation/hallways/northhallway_spawn_outer
#execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned,tag=!bossnorth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=100},distance=..400] run function voa:natural_generation/hallways/northhallway_spawn_outer_cap
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=!summoned,tag=bossnorth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=100},distance=..400] run function voa:natural_generation/hallways/northhallway_spawn_outer_cap_boss
execute as @e[type=minecraft:armor_stand,tag=vaultnorthhallway,tag=summoned] at @s run kill @s

##--- Vault-South-Hallway Marker
#QC Marker Based off of Boss Spawn
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned,tag=bosssouth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=90},distance=..400] run summon armor_stand ~ ~-7 ~109 {NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["qcsouth"],CustomName:'{"text":"South QC Cap Boss"}'}
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned,tag=!bosssouth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=90},distance=..400] run summon armor_stand ~ ~-7 ~109 {NoGravity:1b,Silent:1b,Invulnerable:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["qcsouthnob"],CustomName:'{"text":"South QC Cap"}'}
#Normal Room Spawn
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=90},distance=..400] run function voa:natural_generation/hallways/southhallway_spawn
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=70},distance=..400] run function voa:natural_generation/hallways/southhallway_spawn_cap
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned,tag=bosssouth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=60},distance=..400] run function voa:natural_generation/hallways/southhallway_spawn_outer
#execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned,tag=!bosssouth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=40},distance=..400] run function voa:natural_generation/hallways/southhallway_spawn_outer_cap
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=!summoned,tag=bosssouth] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=40},distance=..400] run function voa:natural_generation/hallways/southhallway_spawn_outer_cap_boss
execute as @e[type=minecraft:armor_stand,tag=vaultsouthhallway,tag=summoned] at @s run kill @s

##--- Sponge Removal (Hall)
execute as @e[type=minecraft:armor_stand,tag=spongehall,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=28..30},distance=..400] run function voa:natural_generation/hallways/sponge
execute as @e[type=minecraft:armor_stand,tag=spongehall,tag=summoned,sort=nearest,limit=1] at @s if block ~ ~2 ~ #voa:sponges run function voa:natural_generation/hallways/sponge_try
execute as @e[type=minecraft:armor_stand,tag=spongehall,tag=summoned] at @s unless block ~ ~2 ~ #voa:sponges run kill @s

##Sponge-hall-endcap (bottom floor) Removal
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=18..20},distance=..400] run function voa:natural_generation/hallways/spongecapbot
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=summoned,sort=nearest,limit=1] at @s if block ~ ~2 ~ #voa:sponges run function voa:natural_generation/hallways/spongecapbot_try
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=summoned] at @s unless block ~ ~2 ~ #voa:sponges run kill @s

##Sponge-hall-endcap (middle/upper floor) Removal
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=spawnoblisk,tag=summoned,scores={buildingtime=8..10},distance=..400] run function voa:natural_generation/hallways/spongecapmidtop
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=summoned,sort=nearest,limit=1] at @s if block ~ ~2 ~ #voa:sponges run function voa:natural_generation/hallways/spongecapmidtop_try
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=summoned] at @s unless block ~ ~2 ~ #voa:sponges run kill @s

#-Vault Spawn Scoreboard (Staggers Spawn to reduce lag)
execute as @e[type=minecraft:armor_stand,tag=spawnoblisk,scores={buildingtime=1..}] at @s if entity @e[distance=0..85,type=player] run scoreboard players remove @e[type=minecraft:armor_stand,tag=spawnoblisk,scores={buildingtime=1..}] buildingtime 1


##QC PROCESS
##South - QC - Endcap - Boss
execute as @e[type=minecraft:armor_stand,tag=obliskqc] at @s run particle minecraft:heart ~ ~-24 ~112 0 0 0 0.25 10
execute as @e[type=minecraft:armor_stand,tag=qcsouth,tag=!summoned] at @s if block ~ ~-1 ~40 #voa:qc run kill @s
execute as @e[type=minecraft:armor_stand,tag=qcsouth,tag=!summoned] at @s if entity @a[distance=..16] at @s unless block ~ ~-1 ~40 #voa:qc run function voa:natural_generation/hallways/southqc
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcsouth,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapbot
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcsouth,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapmidtop
execute as @e[type=minecraft:armor_stand,tag=qcsouth,tag=summoned,scores={buildingtime=..1}] at @s run kill @s

##South - QC - Endcap - NOT BOSS
execute as @e[type=minecraft:armor_stand,tag=obliskqc] at @s run particle minecraft:heart ~ ~-24 ~112 0 0 0 0.25 10
execute as @e[type=minecraft:armor_stand,tag=qcsouthnob,tag=!summoned] at @s if block ~ ~-1 ~40 #voa:qc run kill @s
#execute as @e[type=minecraft:armor_stand,tag=qcsouthnob,tag=!summoned] at @s if entity @a[distance=..16] at @s unless block ~ ~-1 ~40 #voa:qc run function voa:natural_generation/hallways/southqcnob
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcsouthnob,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapbot
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcsouthnob,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapmidtop
execute as @e[type=minecraft:armor_stand,tag=qcsouthnob,tag=summoned,scores={buildingtime=..1}] at @s run kill @s

##North - QC - Endcap - Boss
execute as @e[type=minecraft:armor_stand,tag=obliskqc] at @s run particle minecraft:heart ~ ~-24 ~-112 0 0 0 0.25 10
execute as @e[type=minecraft:armor_stand,tag=qcnorth,tag=!summoned] at @s if block ~ ~-1 ~40 #voa:qc run kill @s
execute as @e[type=minecraft:armor_stand,tag=qcnorth,tag=!summoned] at @s if entity @a[distance=..16] at @s unless block ~ ~-1 ~40 #voa:qc run function voa:natural_generation/hallways/northqc
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcnorth,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapbot
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcnorth,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapmidtop
execute as @e[type=minecraft:armor_stand,tag=qcnorth,tag=summoned,scores={buildingtime=..1}] at @s run kill @s

##North - QC - Endcap - NOT BOSS
execute as @e[type=minecraft:armor_stand,tag=obliskqc] at @s run particle minecraft:heart ~ ~-24 ~-112 0 0 0 0.25 10
execute as @e[type=minecraft:armor_stand,tag=qcnorthnob,tag=!summoned] at @s if block ~ ~-1 ~40 #voa:qc run kill @s
#execute as @e[type=minecraft:armor_stand,tag=qcnorthnob,tag=!summoned] at @s if entity @a[distance=..16] at @s unless block ~ ~-1 ~40 #voa:qc run function voa:natural_generation/hallways/northqcnob
execute as @e[type=minecraft:armor_stand,tag=spongecapbottom,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcnorthnob,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapbot
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtop,tag=!summoned] at @s if entity @e[type=minecraft:armor_stand,tag=qcnorthnob,tag=summoned,scores={buildingtime=..5}] run function voa:natural_generation/hallways/spongecapmidtop
execute as @e[type=minecraft:armor_stand,tag=qcnorthnob,tag=summoned,scores={buildingtime=..1}] at @s run kill @s

##-Vault QC Scoreboard (Staggers Spawn to reduce lag) - QC - REDO THIS PORTION
execute as @e[type=minecraft:armor_stand,tag=qcsouth,tag=summoned,scores={buildingtime=1..}] at @s run scoreboard players remove @e[type=minecraft:armor_stand,tag=qcsouth,scores={buildingtime=1..}] buildingtime 1
execute as @e[type=minecraft:armor_stand,tag=qcnorth,tag=summoned,scores={buildingtime=1..}] at @s run scoreboard players remove @e[type=minecraft:armor_stand,tag=qcnorth,scores={buildingtime=1..}] buildingtime 1
execute as @e[type=minecraft:armor_stand,tag=qcsouthnob,tag=summoned,scores={buildingtime=1..}] at @s run scoreboard players remove @e[type=minecraft:armor_stand,tag=qcsouthnob,scores={buildingtime=1..}] buildingtime 1
execute as @e[type=minecraft:armor_stand,tag=qcnorthnob,tag=summoned,scores={buildingtime=1..}] at @s run scoreboard players remove @e[type=minecraft:armor_stand,tag=qcnorthnob,scores={buildingtime=1..}] buildingtime 1


##-Player orientated Sponge Removal! - Excuses based off of radius to player
execute as @e[type=minecraft:armor_stand,tag=spongecapbottomplayer,tag=!summoned,sort=nearest] at @s if entity @a[distance=..35] unless entity @e[tag=spawnoblisk,distance=..150] run function voa:natural_generation/hallways/spongecapbot
execute as @e[type=minecraft:armor_stand,tag=spongecapmidtopplayer,tag=!summoned,sort=nearest] at @s if entity @a[distance=..35] unless entity @e[tag=spawnoblisk,distance=..150] run function voa:natural_generation/hallways/spongecapmidtop
execute as @e[type=minecraft:armor_stand,tag=spongehallplayer,tag=!summoned,sort=nearest] at @s if entity @a[distance=..35] unless entity @e[tag=spawnoblisk,distance=..150] run function voa:natural_generation/hallways/sponge


#----------------------------------------------------------------------------------- Natural Generation - Manor---------------------------------------------------------------------------------------------#

#Manor1 Spawn Test - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=spawnmanor1,tag=!summoned] at @s run function voa:manor/spawn1
execute as @e[type=minecraft:armor_stand,tag=spawnmanor1,tag=summoned] at @s run kill @s

#Manor2 Spawn Test - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=spawnmanor2,tag=!summoned] at @s run function voa:manor/spawn2
execute as @e[type=minecraft:armor_stand,tag=spawnmanor2,tag=summoned] at @s run kill @s

#Manor3 Spawn Test - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=spawnmanor3,tag=!summoned] at @s run function voa:manor/spawn3
execute as @e[type=minecraft:armor_stand,tag=spawnmanor3,tag=summoned] at @s run kill @s

#Manor Basements - Main Spawn
execute as @e[type=minecraft:armor_stand,tag=basement,tag=!summoned] at @s run function voa:manor/basement
execute as @e[type=minecraft:armor_stand,tag=basement,tag=summoned] at @s run kill @s

#Manor Basements - Rooms
execute as @e[type=minecraft:armor_stand,tag=basement_room,tag=!summoned] at @s run function voa:natural_generation/base_room/bas_spawn
execute as @e[type=minecraft:armor_stand,tag=basement_room,tag=summoned] at @s run kill @s

#Manor Basements - sponge
execute as @e[type=minecraft:armor_stand,tag=basement_sponge,tag=!summoned] at @s run function voa:manor/basement_sponge
execute as @e[type=minecraft:armor_stand,tag=basement_sponge,tag=summoned] at @s run kill @s


#----------------------------------------------------------------------------------- Natural Generation - Monolith ---------------------------------------------------------------------------------------------#

#Monolith Spawn Test - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=monolith_start,tag=!summoned] at @s run function voa:monolith/monolith
execute as @e[type=minecraft:armor_stand,tag=monolith_start,tag=summoned] at @s run kill @s

#Monolith Spawn Section 2 - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=monolith_2,tag=!summoned] at @s run function voa:monolith/monolith_2
execute as @e[type=minecraft:armor_stand,tag=monolith_2,tag=summoned] at @s run kill @s

#Monolith Spawn Section 3 - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=monolith_3,tag=!summoned] at @s run function voa:monolith/monolith_3
execute as @e[type=minecraft:armor_stand,tag=monolith_3,tag=summoned] at @s run kill @s


#----------------------------------------------------------------------------------- Natural Generation - Market ---------------------------------------------------------------------------------------------#

#Market Spawn Test - Armor Stand - Summon's and Generates Structure
execute as @e[type=minecraft:armor_stand,tag=market_start,tag=!summoned] at @s run function voa:market/market_start
execute as @e[type=minecraft:armor_stand,tag=market_start,tag=summoned] at @s run kill @s

#Market Obisidan - Armor Stand - Summon's and Generates Obisidian Room
execute as @e[type=minecraft:armor_stand,tag=market_obi,tag=!summoned] at @s run function voa:market/market_obi
execute as @e[type=minecraft:armor_stand,tag=market_obi,tag=summoned] at @s run kill @s

#Market STALL - Armor Stand - Summon's and Generates Stalls
execute as @e[type=minecraft:armor_stand,tag=market_stall,tag=!summoned] at @s run function voa:natural_generation/market/market_stall
execute as @e[type=minecraft:armor_stand,tag=market_stall,tag=summoned] at @s run kill @s

#Market LONG - Armor Stand - Summon's and Generates Long Rooms
execute as @e[type=minecraft:armor_stand,tag=market_long,tag=!summoned] at @s run function voa:natural_generation/market/market_long
execute as @e[type=minecraft:armor_stand,tag=market_long,tag=summoned] at @s run kill @s

#Market LARGE - Armor Stand - Summon's and Generates Large Rooms
execute as @e[type=minecraft:armor_stand,tag=market_large,tag=!summoned] at @s run function voa:natural_generation/market/market_large
execute as @e[type=minecraft:armor_stand,tag=market_large,tag=summoned] at @s run kill @s

#Market Dark Room - Armor Stand - Summon's and Generates Large Rooms
execute as @e[type=minecraft:armor_stand,tag=market_dark,tag=!summoned] at @s run function voa:natural_generation/market/market_dark
execute as @e[type=minecraft:armor_stand,tag=market_dark,tag=summoned] at @s run kill @s

#----------------------------------------------------------------------------------- Terrian Generation - START! -----------------------------------------------------------------------------------------------# 

#This is the Master Command that kicks off Terrian Generation - OVERWORLD ONLY!
execute as @a[nbt={Dimension:"minecraft:overworld"}] at @s run function voa:check_grid

#This is the Master Command that kicks off Terrian Generation - END ONLY ONLY! - 58 - 64
execute as @a[nbt={Dimension:"minecraft:the_end"}] at @s run function voa:check_grid_end


#----------------------------------------------------------------------------------- Chest Generation - START! -----------------------------------------------------------------------------------------------# 
#---Vault-Light Chest#
execute as @e[type=minecraft:armor_stand,tag=spawnvaultlight,tag=!summoned] at @s run function voa:chests/spawnlight
execute as @e[type=minecraft:armor_stand,tag=spawnvaultlight,tag=summoned] at @s run kill @s

#---End-Light Chest#
execute as @e[type=minecraft:armor_stand,tag=spawnendlight,tag=!summoned] at @s run function voa:chests/spawnendlight
execute as @e[type=minecraft:armor_stand,tag=spawnendlight,tag=summoned] at @s run kill @s

#---Vault-Light Trap Chest#
execute as @e[type=minecraft:armor_stand,tag=trapchest,tag=!summoned] at @s run function voa:chests/spawnlighttrap
execute as @e[type=minecraft:armor_stand,tag=trapchest,tag=summoned] at @s run kill @s

#---Vault-Medium-Light Chance Chest#
execute as @e[type=minecraft:armor_stand,tag=spawnvaultlightmedium,tag=!summoned] at @s run function voa:chests/spawnmediumlight
execute as @e[type=minecraft:armor_stand,tag=spawnvaultlightmedium,tag=summoned] at @s run kill @s

#---End-Medium Chest#
execute as @e[type=minecraft:armor_stand,tag=spawnendmedium,tag=!summoned] at @s run function voa:chests/spawnendmedium
execute as @e[type=minecraft:armor_stand,tag=spawnendmedium,tag=summoned] at @s run kill @s

#---Vault-Medium Chest#
execute as @e[type=minecraft:armor_stand,tag=spawnvaultmedium,tag=!summoned] at @s run function voa:chests/spawnmedium
execute as @e[type=minecraft:armor_stand,tag=spawnvaultmedium,tag=summoned] at @s run kill @s

#---Vault-Heavy Chest#
execute as @e[type=minecraft:armor_stand,tag=spawnvaultrich,tag=!summoned] at @s run function voa:chests/spawnrich
execute as @e[type=minecraft:armor_stand,tag=spawnvaultrich,tag=summoned] at @s run kill @s





#----------------------------------------------------------------------------------- Mob Spawner Generation - START! -----------------------------------------------------------------------------------------------# 
#---Axolotl Spawn#
execute as @e[type=minecraft:armor_stand,tag=axochance,tag=!summoned] at @s run function voa:natural_generation/spawners/axolotl
execute as @e[type=minecraft:armor_stand,tag=axochance,tag=summoned] at @s run kill @s

#---Shopkeeper Spawn#
execute as @e[type=minecraft:armor_stand,tag=shopkeeper,tag=!summoned] at @s run function voa:natural_generation/spawners/shopkeeper
execute as @e[type=minecraft:armor_stand,tag=shopkeeper,tag=summoned] at @s run kill @s

#---50/50 Spawner Spawn#
execute as @e[type=minecraft:armor_stand,tag=50perspawner,tag=!summoned] at @s run function voa:natural_generation/spawners/5050spawn
execute as @e[type=minecraft:armor_stand,tag=50perspawner,tag=summoned] at @s run kill @s

#---75/25 Spawner Spawn#
execute as @e[type=minecraft:armor_stand,tag=75fullspawner,tag=!summoned] at @s run function voa:natural_generation/spawners/75perspawn
execute as @e[type=minecraft:armor_stand,tag=75fullspawner,tag=summoned] at @s run kill @s

#---Pest Spawner Spawn#
execute as @e[type=minecraft:armor_stand,tag=pestspawner,tag=!summoned] at @s run function voa:natural_generation/spawners/pestspawn
execute as @e[type=minecraft:armor_stand,tag=pestspawner,tag=summoned] at @s run kill @s

#---100 Percent Spawner Spawn#
execute as @e[type=minecraft:armor_stand,tag=100fullspawner,tag=!summoned] at @s run function voa:natural_generation/spawners/100perspawn
execute as @e[type=minecraft:armor_stand,tag=100fullspawner,tag=summoned] at @s run kill @s

#---Legionnaire Brute Spawn#
execute as @e[type=minecraft:armor_stand,tag=legionbrute,tag=!summoned] at @s if entity @a[distance=..30] run function voa:natural_generation/spawners/legionbrute
execute as @e[type=minecraft:armor_stand,tag=legionbrute,tag=summoned] at @s run kill @s

### Armor Stand Method - Basement - THIS NOW SUMMONS MARCO CREEPER
execute as @e[type=minecraft:armor_stand,tag=marco_creeper,tag=!summoned] at @s run function voa:natural_generation/spawners/macrocreeper
execute as @e[type=minecraft:armor_stand,tag=marco_creeper,tag=summoned] at @s run kill @s

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ END ENEMIES (Market/Monolith) ---#

##--- Ethereal Legend Single Spawn - (Armor Stand Spawn) ##
execute as @e[type=minecraft:armor_stand,tag=legendarypiratespawn,tag=!summoned] at @s if entity @a[distance=..30] run function voa:natural_generation/spawners/end_enemies/legendarypirates
execute as @e[type=minecraft:armor_stand,tag=legendarypiratespawn,tag=summoned] at @s run kill @s

##--- Ethereal Pirate Single Spawn - (Armor Stand Spawn) ##
execute as @e[type=minecraft:armor_stand,tag=legendaryspawn,tag=!summoned] at @s if entity @a[distance=..30] run function voa:natural_generation/spawners/end_enemies/legendaryspawn
execute as @e[type=minecraft:armor_stand,tag=legendaryspawn,tag=summoned] at @s run kill @s

##--- Common End Spawner - (Cube - Spawner)
execute as @e[type=minecraft:armor_stand,tag=commonendspawner,tag=!summoned] at @s run function voa:natural_generation/spawners/end_enemies/enderspawner
execute as @e[type=minecraft:armor_stand,tag=commonendspawner,tag=summoned] at @s run kill @s

##--- Endermite End Spawner - (Cube - Spawner)
execute as @e[type=minecraft:armor_stand,tag=endermitespawn,tag=!summoned] at @s run function voa:natural_generation/spawners/end_enemies/endermite
execute as @e[type=minecraft:armor_stand,tag=endermitespawn,tag=summoned] at @s run kill @s

##--- Enchanted Brew - (Armor Stand Spawn) ##
execute as @e[type=minecraft:armor_stand,tag=brewspawn,tag=!summoned] at @s run function voa:natural_generation/spawners/end_enemies/brewspawn
execute as @e[type=minecraft:armor_stand,tag=brewspawn,tag=summoned] at @s run kill @s

##--- Shulker - (Armor Stand Spawn) ##
execute as @e[type=minecraft:armor_stand,tag=shulkerspawn,tag=!summoned] at @s run function voa:natural_generation/spawners/end_enemies/shulkerspawner
execute as @e[type=minecraft:armor_stand,tag=shulkerspawn,tag=summoned] at @s run kill @s

#----------------------------------------------------------------------------------- Structure Generation - OBLISK - ROOMS ----------------------------------------------------------------------------------#
#---Wealth-Alter Spawn# 
execute as @e[type=minecraft:armor_stand,tag=wealthOblisk,tag=!summoned] at @s run function voa:wealth_alter/place
execute as @e[type=minecraft:armor_stand,tag=wealthOblisk,tag=summoned] at @s run kill @s

#---Wrath-Alter Spawn# 
execute as @e[type=minecraft:armor_stand,tag=wrathOblisk,tag=!summoned] at @s run function voa:wrath_alter/place
execute as @e[type=minecraft:armor_stand,tag=wrathOblisk,tag=summoned] at @s run kill @s

#---Wealth-Plate Spawn# 
execute as @e[type=minecraft:armor_stand,tag=wealthplateOblisk,tag=!summoned] at @s run function voa:plate_of_wealth/place_chance
execute as @e[type=minecraft:armor_stand,tag=wealthplateOblisk,tag=summoned] at @s run kill @s

#---Wrath-Plate Spawn# 
execute as @e[type=minecraft:armor_stand,tag=wrathplateOblisk,tag=!summoned] at @s run function voa:plate_of_wrath/place_chance
execute as @e[type=minecraft:armor_stand,tag=wrathplateOblisk,tag=summoned] at @s run kill @s

#---Oblisk Castle Rooms# 
execute as @e[type=minecraft:armor_stand,tag=9x9oblisk,tag=!summoned] at @s run function voa:natural_generation/castle/cas_spawn 
execute as @e[type=minecraft:armor_stand,tag=9x9oblisk,tag=summoned] at @s run kill @s

#---Oblisk Cathedral Rooms# 
execute as @e[type=minecraft:armor_stand,tag=toweroblisk,tag=!summoned] at @s run function voa:natural_generation/cath/cath_spawn               
execute as @e[type=minecraft:armor_stand,tag=toweroblisk,tag=summoned] at @s run kill @s

#---Oblisk Gardens# 
execute as @e[type=minecraft:armor_stand,tag=gardenoblisk,tag=!summoned] at @s run function voa:natural_generation/garden/gar_spawn
execute as @e[type=minecraft:armor_stand,tag=gardenoblisk,tag=summoned] at @s run kill @s


#----------------------------------------------------------------------------------- Structure Generation - VAULT - ROOMS STONE ----------------------------------------------------------------------------------#

#---Fort Room - VAULT#
execute as @e[type=minecraft:armor_stand,tag=fort,tag=!summoned] at @s run function voa:natural_generation/fort/fort_spawn
execute as @e[type=minecraft:armor_stand,tag=fort,tag=summoned] at @s run kill @s

#---7x7 Small Brick Room - VAULT#
execute as @e[type=minecraft:armor_stand,tag=7x7sbr,tag=!summoned] at @s run function voa:natural_generation/sbr/sbr_spawn
execute as @e[type=minecraft:armor_stand,tag=7x7sbr,tag=summoned] at @s run kill @s
#East West Entrance Facing (90 Degrees)
execute as @e[type=minecraft:armor_stand,tag=7x7sbrew,tag=!summoned] at @s run function voa:natural_generation/sbr/sbr_spawn_ew
execute as @e[type=minecraft:armor_stand,tag=7x7sbrew,tag=summoned] at @s run kill @s

#---10x10 Large Brick Room - VAULT#
execute as @e[type=minecraft:armor_stand,tag=10x10lbr,tag=!summoned] at @s run function voa:natural_generation/lbr/lbr_spawn
execute as @e[type=minecraft:armor_stand,tag=10x10lbr,tag=summoned] at @s run kill @s
#East West Entrance Facing (90 Degrees)
execute as @e[type=minecraft:armor_stand,tag=10x10lbrew,tag=!summoned] at @s run function voa:natural_generation/lbr/lbr_spawn_ew
execute as @e[type=minecraft:armor_stand,tag=10x10lbrew,tag=summoned] at @s run kill @s

#---Vault Piece Brick Layer - VAULT#
execute as @e[type=minecraft:armor_stand,tag=5x5vp,tag=!summoned] at @s run function voa:natural_generation/vp/vp_spawn
execute as @e[type=minecraft:armor_stand,tag=5x5vp,tag=summoned] at @s run kill @s
#East West Entrance Facing (90 Degrees)
execute as @e[type=minecraft:armor_stand,tag=5x5vpew,tag=!summoned] at @s run function voa:natural_generation/vp/vp_spawn_ew
execute as @e[type=minecraft:armor_stand,tag=5x5vpew,tag=summoned] at @s run kill @s

#--- Stairs Brick Layer Marker - VAULT#
execute as @e[type=minecraft:armor_stand,tag=sbl,tag=!summoned] at @s run function voa:natural_generation/sbl/sbl_spawn
execute as @e[type=minecraft:armor_stand,tag=sbl,tag=summoned] at @s run kill @s

#--- Enchancting Table Chance Marker#
execute as @e[type=minecraft:armor_stand,tag=enchantingtablechance,tag=!summoned] at @s run function voa:natural_generation/spawners/enchantingtablechance
execute as @e[type=minecraft:armor_stand,tag=enchantingtablechance,tag=summoned] at @s run kill @s
#--- Enchancting Table Chance Marker END! ##

#--- Treasure Chance Marker# 
execute as @e[type=minecraft:armor_stand,tag=treasurechance,tag=!summoned] at @s run function voa:natural_generation/spawners/treasurechance
execute as @e[type=minecraft:armor_stand,tag=treasurechance,tag=summoned] at @s run kill @s
#--- Treasure Chance Marker# - END! ##

#----------------------------------------------------------------------------------- Structure Generation - Manor - HALLWAYS ----------------------------------------------------------------------------------#
#--- Vault-South-Hallway Marker
execute as @e[type=minecraft:armor_stand,tag=tnthall,tag=!summoned] at @s run function voa:natural_generation/manor/hall_spawn
execute as @e[type=minecraft:armor_stand,tag=tnthall,tag=summoned] at @s run kill @s
execute as @e[type=minecraft:armor_stand,tag=tnthallew,tag=!summoned] at @s run function voa:natural_generation/manor/hall_spawn_ew
execute as @e[type=minecraft:armor_stand,tag=tnthallew,tag=summoned] at @s run kill @s



#----------------------------------------------------------------------------------- Event Markers - Monastery --------------------------------------------------------------------------------------------------------#
#---Cath9 Vault Event# 
execute as @e[type=minecraft:armor_stand,tag=cathvault,tag=!summoned] at @s if entity @e[distance=0..3,type=player] run function voa:natural_generation/events/cath9_vault
execute as @e[type=minecraft:armor_stand,tag=cathvault,tag=summoned] at @s run kill @s

#---Blessing Marker Event# - Only spawns NS
execute as @e[type=minecraft:armor_stand,tag=blessevent,tag=!blesscore] at @s run function voa:natural_generation/events/blessscore
execute as @e[type=minecraft:armor_stand,tag=blessevent,tag=blesscore,scores={atk_cool=0}] at @s if entity @e[distance=5..30,type=player] run function voa:natural_generation/events/blessparticle
scoreboard players remove @e[type=minecraft:armor_stand,tag=blessevent,tag=blesscore,scores={atk_cool=1..}] atk_cool 1
execute as @e[type=minecraft:armor_stand,tag=blessevent,tag=!summoned] at @s if entity @e[distance=0..3,type=player] run function voa:natural_generation/events/blessing
execute as @e[type=minecraft:armor_stand,tag=blessevent,tag=summoned] at @s run kill @s

#--- Witching Marker - Event#
execute as @e[type=minecraft:armor_stand,tag=witchevent,tag=!witchscore] at @s run function voa:natural_generation/events/witchscore
execute as @e[type=minecraft:armor_stand,tag=witchevent,tag=witchscore,scores={atk_cool=0}] at @s run function voa:natural_generation/events/witchingevent
execute as @e[type=minecraft:armor_stand,tag=witchevent,tag=witchscore,scores={atk_cool=0}] at @s run kill @s
execute as @e[type=minecraft:armor_stand,tag=witchevent,tag=witchscore,scores={atk_cool=1..}] at @s if entity @e[distance=0..4,type=player] run scoreboard players remove @e[type=minecraft:armor_stand,tag=witchevent,tag=witchscore,sort=nearest,limit=1] atk_cool 1

##--- Poison Trap Marker - Event - BrickHallNorthSouth Bottomfloor#
#--- Poison Trap Marker - Event - BrickHallNorthSouth Bottomfloor#
execute as @e[type=minecraft:armor_stand,tag=poisontrap,tag=!summoned] at @s run function voa:natural_generation/events/poison_chance
execute as @e[type=minecraft:armor_stand,tag=poisontrap,tag=summoned] at @s run kill @s

#--- Poison Trap Trigger - Event - Based off of plate
execute as @e[type=minecraft:armor_stand,tag=poison,tag=!summoned] at @s if entity @e[distance=0..0.68,type=player] run function voa:natural_generation/events/poisontrap
execute as @e[type=minecraft:armor_stand,tag=poison,tag=!summoned] at @s unless block ~ ~ ~ minecraft:stone_pressure_plate run kill @s
execute as @e[type=minecraft:armor_stand,tag=poison,tag=summoned] at @s run kill @s

#----------------------------------------------------------------------------------- Event Markers - Market --------------------------------------------------------------------------------------------------------#
#---Market_Mine_Debuff Event# 
execute as @e[type=minecraft:armor_stand,tag=market_mine_debuff,tag=!summoned] at @s if entity @e[distance=0..60,type=minecraft:end_crystal] run effect give @a[distance=..60] minecraft:mining_fatigue 15 2

#---Market_Pet-Shop Event# 
execute as @e[type=minecraft:armor_stand,tag=market_petshop,tag=!summoned] at @s run function voa:natural_generation/market/events/market_stall_pet

#---Market_Pet-Shop Event# 
execute as @e[type=minecraft:armor_stand,tag=market_material,tag=!summoned] at @s run function voa:natural_generation/market/events/market_material
execute as @e[type=minecraft:armor_stand,tag=market_material,tag=summoned] at @s run kill @s

#---Market_Ender_chest Event# 
execute as @e[type=minecraft:armor_stand,tag=market_end_chest,tag=!summoned] at @s run function voa:natural_generation/market/events/market_end_chest
execute as @e[type=minecraft:armor_stand,tag=market_end_chest,tag=summoned] at @s run kill @s

#--- Market_Sculk Trap Marker - Event - MARKER
execute as @e[type=minecraft:armor_stand,tag=sculktrap,tag=!summoned] at @s run function voa:natural_generation/market/events/sculk_chance
execute as @e[type=minecraft:armor_stand,tag=sculktrap,tag=summoned] at @s run kill @s

#12 Power Levels
#4-6 (1-2 Blocks) power1
#7-9 (2-4 Blocks) power2
#10-12 (5-6 Blocks) power3
#13-15 (7-8 Blocks) power4

execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=15] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=14] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=13] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=12] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=11] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=10] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=9] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=8] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=7] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=6] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=5] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=4] if entity @a[distance=..6] run tag @s add power
execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s if block ~ ~ ~ minecraft:sculk_sensor[sculk_sensor_phase=active,power=3] if entity @a[distance=..6] run tag @s add power

execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:armor_stand,tag=sculk,tag=power,distance=0..6] run function voa:gila/gila_spawn_hatch
execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:zombie,tag=dream_eater,tag=los,distance=0..3] run function voa:gila/gila_spawn_hatch
#execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:armor_stand,tag=sculk,tag=power4,distance=0..8] run function voa:gila/gila_spawn_hatch
#execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:armor_stand,tag=sculk,tag=power3,distance=0..6] run function voa:gila/gila_spawn_hatch
#execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:armor_stand,tag=sculk,tag=power2,distance=0..4] run function voa:gila/gila_spawn_hatch
#execute as @e[type=minecraft:armor_stand,tag=gila_egg,tag=!hatched] at @s if entity @e[type=minecraft:armor_stand,tag=sculk,tag=power1,distance=0..2] run function voa:gila/gila_spawn_hatch

execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!hatch_eggs] at @s unless block ~ ~ ~ minecraft:sculk_sensor run kill @s


#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=15] if entity @a[distance=..8] run say SCULK 15!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=14] if entity @a[distance=..8] run say SCULK 14!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=13] if entity @a[distance=..8] run say SCULK 13!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=12] if entity @a[distance=..8] run say SCULK 12!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=11] if entity @a[distance=..8] run say SCULK 11!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=10] if entity @a[distance=..8] run say SCULK 10!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=9] if entity @a[distance=..8] run say SCULK 9!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=8] if entity @a[distance=..8] run say SCULK 8!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=7] if entity @a[distance=..8] run say SCULK 7!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=6] if entity @a[distance=..8] run say SCULK 6!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=5] if entity @a[distance=..8] run say SCULK 5!
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if block ~ ~ ~ minecraft:sculk_sensor[power=4] if entity @a[distance=..8] run say SCULK 4!

#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s if entity @e[distance=0..0.68,type=player] run function voa:natural_generation/market/events/sculktrap
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=!summoned] at @s unless block ~ ~ ~ minecraft:stone_pressure_plate run kill @s
#execute as @e[type=minecraft:armor_stand,tag=sculk,tag=summoned] at @s run kill @s
