#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^ run function voa:bonelock/path

# Remove the raycasting tag after raycast completion to prepare fo the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Plays Sound
playsound minecraft:flintlock.fire ambient @a[distance=..20] ~ ~ ~ 3

#Removes Ammo from inventory
clear @s stick{display:{Name:'{"text":"boneshot"}'},CustomModelData:262626,boneshot:1b} 1

#Sets Cooldown between shots - or rate of fire.
scoreboard players set @s bonelk_cool 12
