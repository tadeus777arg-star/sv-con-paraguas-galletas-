#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Runs Heal
function voa:staff_harmony/harmony_effect

#data merge item
item replace entity @s weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Staff: First Aid (4 Charges)"}'},HideFlags:1,CustomModelData:323232,staffh4:1b} 1


#Sets Cooldown to reduce spam
scoreboard players set @s[scores={staff_h_cool=0..}] staff_h_cool 50


