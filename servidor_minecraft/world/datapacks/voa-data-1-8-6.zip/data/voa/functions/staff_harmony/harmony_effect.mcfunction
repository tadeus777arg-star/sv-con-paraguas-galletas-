#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Gives/Clears Effect
effect give @e[type=#voa:friendly,distance=..16] minecraft:instant_health 1 2
effect clear @e[type=#voa:friendly,distance=..16] minecraft:blindness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:darkness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:hunger
effect clear @e[type=#voa:friendly,distance=..16] minecraft:nausea
effect clear @e[type=#voa:friendly,distance=..16] minecraft:poison
effect clear @e[type=#voa:friendly,distance=..16] minecraft:slowness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:weakness
effect clear @e[type=#voa:friendly,distance=..16] minecraft:wither

#Particle
particle minecraft:heart ~ ~ ~ 10 2 10 0.3 125 normal
playsound minecraft:willowbee.mob.hurt ambient @a[] ~ ~ ~ 2
