#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 69
function voa:natural_generation/random/range_lcg

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
###  If matches 0 
execute if score out math matches 7 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/warped_titan_loot",Health:85,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["warpedtitan"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["warped_titan_body"],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:470020}}]}],CustomName:'{"text":"Warped Titan"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:470021}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:85},{Name:generic.follow_range,Base:30},{Name:generic.knockback_resistance,Base:0.6},{Name:generic.movement_speed,Base:0.36},{Name:generic.attack_damage,Base:9},{Name:zombie.spawn_reinforcements,Base:0}]}
execute if score out math matches 7 run tp @s ~ ~-256 ~


### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
execute if score out math matches 7 run scoreboard players add @e[tag=warpedtitan,type=minecraft:zombie,tag=!stats] atk_cool 0
execute if score out math matches 7 run scoreboard players add @e[tag=warpedtitan,type=minecraft:zombie,tag=!stats] sound_cool 0
execute if score out math matches 7 run scoreboard players add @e[tag=warpedtitan,type=minecraft:zombie,tag=!stats] proxy 0
execute if score out math matches 7 run scoreboard players add @e[tag=warpedtitan,type=minecraft:zombie,tag=!stats] titanhealth 0
execute if score out math matches 7 run scoreboard players add @e[tag=warpedtitan,type=minecraft:zombie,tag=!stats] atk_teleport 100

execute if score out math matches 7 run tag @e[tag=warpedtitan,type=minecraft:zombie,tag=!stats] add stats

#Marks Enderman
tag @s add not_warped_titan
