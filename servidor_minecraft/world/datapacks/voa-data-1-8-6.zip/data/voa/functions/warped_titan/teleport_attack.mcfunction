#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#How long it takes to cool down
#scoreboard players set @s atk_teleport 100


playsound minecraft:warped.titan.mob.atk hostile @a[] ~ ~ ~ 1.5

# Summon Cloud
execute as @e[tag=warpedtitan,tag=!warpattack,scores={atk_teleport=1}] run summon minecraft:area_effect_cloud ~ ~1 ~ {Tags:["teleport_ball","not_rotated"],Duration:200} 

# Face Player
execute as @s[tag=warpedtitan,tag=!warpattack,scores={atk_teleport=1}] as @e[tag=teleport_ball,tag=not_rotated,distance=0..1.5] facing entity @p feet run tp @s ~ ~ ~ ~ ~
execute as @s[tag=warpedtitan,tag=!warpattack,scores={atk_teleport=1}] as @e[tag=teleport_ball,tag=not_rotated,distance=0..1.5] run tag @s remove not_rotated

#Runs once?
tag @s add warpattack

#Resets Scoreboard
execute as @e[type=minecraft:zombie,tag=warpedtitan,scores={atk_teleport=..1}] at @s run scoreboard players set @e[tag=warpedtitan,type=minecraft:zombie,scores={atk_teleport=..1}] atk_teleport 112

#particle affects
particle minecraft:squid_ink ~ ~0.5 ~ 1.5 .5 1.5 0.000000001 60
