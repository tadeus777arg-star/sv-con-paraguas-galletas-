#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Giving the custom attack
execute as @e[type=minecraft:zombie,tag=warpedtitan,tag=warpattack,scores={atk_teleport=112}] at @s if entity @a[distance=..20,tag=teletitan] run tp @e[type=minecraft:zombie,tag=warpedtitan,tag=warpattack,scores={atk_teleport=112}] @p[tag=teletitan]
effect give @a[distance=0..3] blindness 6
effect give @a[distance=0..3] minecraft:instant_damage 1
effect give @a[distance=0..3] slowness 6 3
playsound minecraft:entity.enderman.teleport ambient @a ~ ~ ~

#Runs once?
tag @a[distance=..12] remove teletitan

#particle affects
particle minecraft:squid_ink ~ ~0.5 ~ 1.5 .5 1.5 0.000000001 60
