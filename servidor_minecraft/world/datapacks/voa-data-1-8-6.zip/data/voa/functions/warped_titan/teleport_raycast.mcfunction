#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#particle affects
particle minecraft:portal ~ ~ ~ .01 .01 .01 .1 40
particle minecraft:portal ~ ~ ~ .7 .7 .7 .2 140
playsound minecraft:entity.ender_eye.death ambient @a ~ ~ ~

#On Block
execute unless block ~ ~ ~ #voa:raycast_pass run kill @s 

#If Near Player
execute if entity @e[type=player,distance=..1.5] at @s run tag @p[distance=..1.5] add teletitan
execute if entity @e[type=player,distance=..1.5] at @s run kill @s

#teleport forwards
execute at @s run tp ^ ^ ^.5


#BEAGS