#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

tellraw @a {"text":"--- Vaults of Abandon Datapack Item-Showcase Loaded ---","color":"green"}

#----------------------------------------------------------------------------------- Alters/Plates ----------------------------------------------------------------------------------------------------#
##Plates------------------------- ##
##--- Plate of Weath#
give @p item_frame{display:{Name:'{"text":"Plate of Wealth"}'},CustomModelData:222223,EntityTag:{Silent:1b,Tags:["wealth"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:222223}},Invulnerable:1b,Invisible:1b,Fixed:1b,Facing:1}} 1

##--- Plate of Wrath ##
give @p item_frame{display:{Name:'{"text":"Plate of Wrath"}'},CustomModelData:222222,EntityTag:{Silent:1b,Tags:["wrath"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:222222}},Invulnerable:1b,Invisible:1b,Fixed:1b,Facing:1}} 1


#----------------------------------------------------------------------------------- ESSENCE ----------------------------------------------------------------------------------------------------------#

##---Chaos Essence ##
give @p red_dye{display:{Name:'{"text":"Chaos Essence"}'},CustomModelData:131313,chaos:1b} 64

##---Harmony Essence ##
give @p blue_dye{display:{Name:'{"text":"Harmony Essence"}'},CustomModelData:141414,harmony:1b} 64

##---Lucky Essence ##
give @p yellow_dye{display:{Name:'{"text":"Lucky Essence"}'},CustomModelData:151515,lucky:1b} 64



#----------------------------------------------------------------------------------- ORBS/Runes --------------------------------------------------------------------------------------------------------#

##Chaos Orb ##
give @p red_dye{display:{Name:'{"text":"Chaos Orb"}'},CustomModelData:231313,chaos_orb:1b} 64

##Harmony Orb ##
give @p blue_dye{display:{Name:'{"text":"Harmony Orb"}'},CustomModelData:241414,harmony_orb:1b} 64

##Lucky Orb ##
give @p yellow_dye{display:{Name:'{"text":"Lucky Orb"}'},CustomModelData:251515,lucky_orb:1b} 64

##Dangerous Orb ##
give @p orange_dye{display:{Name:'{"text":"Dangerous Orb"}'},CustomModelData:251515,dangerous_orb:1b} 64



#----------------------------------------------------------------------------------- Magic Staffs -------------------------------------------------------------------------------------------------------#

##Basic Staff ##
give @p stick{display:{Name:'{"text":"Unenchanted Staff"}'},CustomModelData:303030,staff:1b} 64

##Chaos Staff ## STILL NEED TO BE CHANGED UP
give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: Levitate (12 Charges)"}'},CustomModelData:313131,staffc12:1b} 1

##Harmoneous Staff ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: First Aid (12 Charges)"}'},CustomModelData:323232,staffh12:1b} 1

##Lucky Staff ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: Chicken Claw (12 Charges)"}'},CustomModelData:333333,staffl12:1b} 1

##Dangerous Staff ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Staff: Firebender (12 Charges)"}'},CustomModelData:343434,staffd12:1b} 1



#----------------------------------------------------------------------------------- X-Finity Blade -------------------------------------------------------------------------------------------------------#

##--- X-Finity Blade (Coreless) ##
give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Coreless)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666444,xblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s}]} 1


##--- X-Finity Blade (Chaos) ##
give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Chaos)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666445,xbladec:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:sweeping",lvl:2s}]} 1

#####--- X-Finity Blade (Harmony) ## ##
give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Harmony)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666447,xbladeh:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:smite",lvl:2s}]} 1

#####--- X-Finity Blade (Lucky) ## 
give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Lucky)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666446,xbladel:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:looting",lvl:2s}]} 1

#####--- X-Finity Blade (Dangerous) ## ##
give @p netherite_sword{display:{Name:'{"text":"X-Finity Blade (Dangerous)","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666448,xbladed:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:knockback",lvl:1s},{id:"minecraft:unbreaking",lvl:5s},{id:"minecraft:fire_aspect",lvl:2s}]} 1


#----------------------------------------------------------------------------------- Magic Tome -------------------------------------------------------------------------------------------------------#

##Magic Tome ##
give @p book{display:{Name:'{"text":"Magic Tome"}'},HideFlags:1,CustomModelData:234444,tome:1b} 64

##Chaos Tome ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Tome: Stasis Field"}'},HideFlags:1,CustomModelData:234445,tome_c:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]} 1

##Harmoneous Tome ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Tome: Overshield"}'},HideFlags:1,CustomModelData:234446,tome_h:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]} 1

##Lucky Tome ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Tome: Ring of Rabbit"}'},HideFlags:1,CustomModelData:234447,tome_l:1b,Enchantments:[{id:"minecraft:unbreaking",lvl:1s}]} 1

#----------------------------------------------------------------------------------- Items -----------------------------------------------------------------------------------------------------------#

##--- Bonelock ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Bonelock Pistol"}'},CustomModelData:977777,bonelock:1b} 1

##--- Bonesket ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Bonesket"}'},HideFlags:1,CustomModelData:977778,bonesket:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s},{id:"minecraft:sharpness",lvl:3s}]} 1

##--- Bonesplitter ##
give @p carrot_on_a_stick{display:{Name:'{"text":"Bonesplitter"}'},HideFlags:1,CustomModelData:888888,bonesplitter:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s}]} 1

##--- Boneshot (Ammo for Bone Weapons) ##
give @p stick{display:{Name:'{"text":"boneshot"}'},CustomModelData:262626,boneshot:1b} 64

##--- Bone Dust Bomb ##
give @p snowball{display:{Name:'{"text":"Bone Dust Bomb"}'},CustomModelData:100421,bdb:1b} 16



##--- Skeel Blade ##
give @p iron_sword{display:{Name:'{"text":"Skeel Blade","bold":true,"italic":true}'},HideFlags:1,Unbreakable:0b,Damage:1.0,CustomModelData:555555,skeelblade:1b,Enchantments:[{id:"minecraft:knockback",lvl:3s},{id:"minecraft:sweeping",lvl:4s}]} 1
give @p diamond_sword{display:{Name:'{"text":"Elite Skeel Blade","bold":true,"italic":true}'},HideFlags:1,Unbreakable:0b,Damage:1.0,CustomModelData:555556,eliteskeelblade:1b,Enchantments:[{id:"minecraft:knockback",lvl:4s},{id:"minecraft:sweeping",lvl:5s}]} 1

##--- Pestkeeper ##
give @p iron_sword{display:{Name:'{"text":"Pest Keeper","bold":true,"italic":true}'},HideFlags:1,CustomModelData:555557,pestkeeper:1b,Enchantments:[{id:"minecraft:sharpness",lvl:1s},{id:"minecraft:bane_of_arthropods",lvl:5s},{id:"minecraft:sweeping",lvl:4s},{id:"minecraft:unbreaking",lvl:2s}]} 1

##--- Coal-Train ##
give @p iron_sword{display:{Name:'{"text":"Coal Train","bold":true,"italic":true}'},HideFlags:1,CustomModelData:555559,coaltrain:1b,Enchantments:[{id:"minecraft:sharpness",lvl:2s},{id:"minecraft:fire_aspect",lvl:3s},{id:"minecraft:knockback",lvl:2s},{id:"minecraft:unbreaking",lvl:2s}]} 1

##--- Spectral-Schimitar ##
give @p netherite_sword{display:{Name:'{"text":"Spectral-Scimitar","bold":true,"italic":true}'},HideFlags:1,CustomModelData:666333,schimitar:1b,Enchantments:[{id:"minecraft:smite",lvl:5s},{id:"minecraft:sweeping",lvl:4s},{id:"minecraft:unbreaking",lvl:5s}]} 1

##--- Cakeblade ##
give @p diamond_sword{display:{Name:'{"text":"Cake Blade","bold":true,"italic":true}'},HideFlags:1,CustomModelData:355557,cakeblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:looting",lvl:3s},{id:"minecraft:mending",lvl:1s}]} 1

##--- Embezzler ##
give @p diamond_sword{display:{Name:'{"text":"Emerald Embezzler","bold":true,"italic":true}'},HideFlags:1,CustomModelData:555559,emeraldblade:1b,Enchantments:[{id:"minecraft:sharpness",lvl:3s},{id:"minecraft:sweeping",lvl:3s},{id:"minecraft:looting",lvl:3s},{id:"minecraft:mending",lvl:1s}]} 1

##--- Magic Bench Block#
give @p item_frame{display:{Name:'{"text":"Magic Bench"}'},CustomModelData:727272,EntityTag:{Silent:1b,Tags:["magic_bench"],Item:{id:"minecraft:item_frame",Count:1b,tag:{CustomModelData:727272}},Invulnerable:1b,Invisible:1b,Fixed:1b}} 1

