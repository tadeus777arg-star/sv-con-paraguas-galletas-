#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected

item replace entity @p weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Double-Bone-87"}'},HideFlags:1,CustomModelData:888901,dbone:1b} 1

effect give @s[] slowness 1 3 true

scoreboard players set @a[scores={d_bone_cool=0..}] d_bone_cool 8
