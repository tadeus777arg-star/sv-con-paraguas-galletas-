#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:double_bone/path

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Muzzle Flash - And Sound
execute anchored eyes positioned ^ ^ ^ run particle minecraft:flame ^-.05 ^ ^1.1 
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.1 ^1.1 
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.3 ^1.1
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.5 ^1.1
#playsound minecraft:musket.fire ambient @a[distance=..20] ~ ~ ~ 3
playsound minecraft:entity.generic.explode ambient @a[distance=..20] ~ ~ ~ 3


#Fired Rifle - Empty Chamber
item replace entity @p weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Double-Bone-87"}'},HideFlags:1,CustomModelData:888900,dbone:1b} 1


#Stops Lift Animation
scoreboard players set @p[scores={bonedready=0..}] bonedready 8
#tag @s add liftanimation

