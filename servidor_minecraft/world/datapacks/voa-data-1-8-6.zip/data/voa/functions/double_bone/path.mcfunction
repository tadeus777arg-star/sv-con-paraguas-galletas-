#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This function gives the bullet its Trajectery
# Using dx for precise hitbox detection
# Parameters:
#     Edit not_mob.json in tags/entities to change which entities will not be targetted
#     Change the "positioned" offsets to change projectile size
#       - If > 1 block, just use one dx detection
#execute as @e[tag=!raycasting,type=!#voa:not_mob,dx=0] positioned ~-1 ~-1 ~-1 if entity @s[dx=1,dy=1,dz=1] positioned ~1 ~1 ~1 run function voa:bonesplitter/collide
execute as @e[tag=!raycasting,type=!#voa:not_mob,dx=-1,dy=-1,dz=-1] positioned ~-2 ~-2 ~-2 if entity @s[dx=3,dy=3,dz=3] positioned ~2 ~2 ~2 run function voa:double_bone/collide
####################################First Full Block ~ Positions function bawards by 1 whole block | Run the first Scan again 
scoreboard players add .distance tf_rc 1

# Make raycast visible
particle minecraft:ash ~ ~ ~ .2 .2 .2 0 5

# Repeat the raycast if certain conditions are met
# Parameters:
#    (score after "matches") * (accuracy increment) = range
#    The "positioned" value specifies the precision
#    Edit raycast_pass.json in tags/blocks to change which blocks the raycast ignores
#    "rotated" controls arc/curve of raycast path
execute if score .distance tf_rc matches ..200 positioned ^ ^ ^0.1 rotated ~ ~ if block ~ ~ ~ #voa:raycast_pass run function voa:double_bone/path



#Shots go 20 Blocks
#Shot Straight - Slightly tilted up




