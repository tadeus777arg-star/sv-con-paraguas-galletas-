#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Steady Weapons
item replace entity @p weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Double-Bone-87"}'},HideFlags:1,CustomModelData:888900,dbone:1b} 1

effect clear @s[] slowness