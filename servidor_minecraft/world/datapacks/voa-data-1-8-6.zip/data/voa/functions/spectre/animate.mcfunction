#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#Mob Sound/Sound Timer/Reset Sound so it happens again - UNFRENZY
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s mob_demo_time 1
execute if entity @s[scores={mob_demo_time=2},tag=!frenzied] run playsound minecraft:block.grass.step hostile @a[distance=0..14] ~ ~ ~ 0.2 1
execute if entity @s[scores={mob_demo_time=20,},tag=!frenzied] run scoreboard players set @s mob_demo_time 0
execute if entity @s[scores={mob_demo_time=20,},tag=frenzied] run scoreboard players set @s mob_demo_time 0


#Mob Sound/Sound Timer/Reset Sound so it happens again - FRENZY!
execute if entity @s[scores={mob_demo_time=2},tag=frenzied] run playsound minecraft:block.grass.step hostile @a[distance=0..14] ~ ~ ~ 0.2 1
execute if entity @s[scores={mob_demo_time=2},tag=frenzied] run particle minecraft:ash ~ ~1 ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=8},tag=frenzied] run particle minecraft:ash ~ ~1 ~ 0 0 0 1 6 normal
execute if entity @s[scores={mob_demo_time=8,},tag=frenzied] run scoreboard players set @s mob_demo_time 0


#Moving Animation - FRENZY!
execute if entity @s[scores={animate=1},tag=frenzied] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=spectre,tag=frenzied] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931002}}]}


#Resets Moving Animation - FRENZY!
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=frenzied] run scoreboard players set @s animate 0
execute if entity @s[scores={animate=0},tag=frenzied] run data merge entity @e[limit=1,distance=0..2,type=minecraft:husk,sort=nearest,tag=spectre,tag=frenzied] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931003}}]}


#Damage Animation - - UNFRENZY
execute if entity @s[nbt={HurtTime:10s},tag=!frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:9s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:8s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:7s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:6s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:5s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:4s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:3s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:2s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931001}}]}
execute if entity @s[nbt={HurtTime:1s},tag=!frenzied] run data merge entity @e[tag=!frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931000}}]}


#Damage Animation - FRENZY
execute if entity @s[nbt={HurtTime:10s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:9s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:8s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:7s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:6s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:5s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:4s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:3s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:2s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931004}}]}
execute if entity @s[nbt={HurtTime:1s},tag=frenzied] run data merge entity @e[tag=frenzied,tag=spectre,type=minecraft:husk,sort=nearest,limit=1] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:931003}}]}

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:wraith.mob.hurt hostile @a[distance=0..10]


#Detects if mob is moving
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]},tag=frenzied] run scoreboard players add @s animate 1 
