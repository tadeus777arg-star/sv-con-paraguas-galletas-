#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


### Execute as at Husk
### Always Spawns - Armor Stand Based Spawner

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
summon husk ~ ~ ~ {Silent:1b,CustomNameVisible:0b,PersistenceRequired:1b,DeathLootTable:"voa:entities/spectre_loot",Health:20f,CanBreakDoors:1b,DrownedConversionTime:99999,Tags:["spectre"],CustomName:'{"text":"Specter"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:931000}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:jump_boost",amplifier:1b,duration:99999,show_particles:0b},{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:20},{Name:generic.follow_range,Base:40},{Name:generic.movement_speed,Base:0.15},{Name:generic.attack_damage,Base:6},{Name:zombie.spawn_reinforcements,Base:0}]}

#### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=spectre,type=minecraft:husk,sort=nearest,limit=1] sound_cool 0

#Execute for Spectral-Schimitar
tag @e[tag=spectre,type=minecraft:husk] add ghost

#Kills Marker
tag @s add summoned