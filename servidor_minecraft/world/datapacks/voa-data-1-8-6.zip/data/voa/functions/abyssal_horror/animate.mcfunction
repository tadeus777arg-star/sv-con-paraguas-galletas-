#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#ABYSSAL!

#Head Movement
execute if entity @s[scores={head_animate=4}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=abyssal_horror] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:666667}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F]}
execute if entity @s[scores={head_animate=8}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=abyssal_horror] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:666668}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F]}
execute if entity @s[scores={head_animate=8}] run scoreboard players set @s head_animate 1
##Resets Head Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s head_animate 0
execute if entity @s[scores={head_animate=0}] run data merge entity @e[limit=1,distance=0..2.05,type=minecraft:zombie,sort=nearest,tag=abyssal_horror] {ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:666669}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F]}
##Detects if mob is moving - Applies head animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s head_animate 1 

#Moving Animation - Body - Armor Stand Method
execute as @e[type=minecraft:armor_stand,tag=abyssal_horror_body] at @s if entity @e[type=minecraft:zombie,tag=abyssal_horror,distance=0..2.05,scores={animate=4}] run data merge entity @e[type=minecraft:armor_stand,tag=abyssal_horror_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:666664}}]}
execute if entity @s[scores={animate=4}] unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run playsound minecraft:entity.hoglin.step hostile @a[distance=0..10]
execute as @e[type=minecraft:armor_stand,tag=abyssal_horror_body] at @s if entity @e[type=minecraft:zombie,tag=abyssal_horror,distance=0..2.05,scores={animate=8}] run data merge entity @e[type=minecraft:armor_stand,tag=abyssal_horror_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:666663}}]}
execute if entity @e[type=minecraft:zombie,tag=abyssal_horror,distance=0..2.05,scores={animate=8}] run scoreboard players set @s animate 1
##Resets Body Moving Animation
execute if entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players set @s animate 0
execute as @e[type=minecraft:armor_stand,tag=abyssal_horror_body] at @s if entity @e[type=minecraft:zombie,tag=abyssal_horror,distance=0..2.05,scores={animate=0}] run data merge entity @e[type=minecraft:armor_stand,tag=abyssal_horror_body,limit=1,sort=nearest,distance=..100] {ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:666666}}]}
##Detects if mob is moving - Applies body animation
execute unless entity @s[nbt={Motion:[0.0d,0.0d,0.0d]}] run scoreboard players add @s animate 1 

#Damage Sound
execute if entity @s[nbt={HurtTime:10s}] run playsound minecraft:horror.mob.hurt master @a[distance=0..10]
#

