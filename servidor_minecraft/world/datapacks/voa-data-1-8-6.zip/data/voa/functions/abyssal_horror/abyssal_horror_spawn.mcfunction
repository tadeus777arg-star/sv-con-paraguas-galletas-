#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
###  If matches 0 
execute if score abyssalhorror_count cm_abyssalhorror matches 0 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abyssal_loot",Health:50f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:199999999980,Tags:["abyssal_horror"],Passengers:[{id:"minecraft:armor_stand",Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abyssal_horror_body"],ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:666666}}]}],CustomName:'{"text":"Abyssal Horror"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:666669}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:50},{Name:generic.follow_range,Base:24},{Name:generic.knockback_resistance,Base:0.5},{Name:generic.movement_speed,Base:0.35},{Name:generic.attack_damage,Base:8},{Name:generic.attack_knockback,Base:3}]}
execute if score abyssalhorror_count cm_abyssalhorror matches 0 run tp @s ~ ~-256 ~

### Add tag not_messenger to ensure the Zombie is not scanned again
tag @s add not_abyssal_horror
### Increment count
scoreboard players add abyssalhorror_count cm_abyssalhorror 1
### Reset Count
execute if score abyssalhorror_count cm_abyssalhorror matches 16 run scoreboard players set abyssalhorror_count cm_abyssalhorror 0

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=abyssal_horror,type=minecraft:zombie] atk_cool 0
scoreboard players add @e[tag=abyssal_horror,type=minecraft:zombie] sound_cool 0