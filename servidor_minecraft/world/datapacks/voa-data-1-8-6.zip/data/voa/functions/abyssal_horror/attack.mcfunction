#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down
scoreboard players set @s atk_cool 50

#Attack effect
effect give @a[distance=0..7] blindness 6

#particle affects
particle minecraft:squid_ink ~ ~0.5 ~ 7 0.5 7 0.000000001 80