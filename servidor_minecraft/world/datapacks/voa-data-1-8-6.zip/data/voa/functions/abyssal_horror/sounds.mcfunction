#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down and distance between each sound
scoreboard players set @s sound_cool 120
playsound minecraft:horror.mob.wail hostile @a[distance=0..16]


#B-E-A-G-L-E-B-L-O-C-K-S