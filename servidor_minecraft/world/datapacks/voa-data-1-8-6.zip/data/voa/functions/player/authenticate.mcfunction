#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


#Scoreboard Load
scoreboard players add @s staff_c_cool 0
scoreboard players add @a staff_h_cool 0
scoreboard players add @a staff_l_cool 0
scoreboard players add @a staff_d_cool 0
scoreboard players add @a irony 0
scoreboard players add @a bonelk_cool 0
scoreboard players add @a boneskt_cool 0
scoreboard players add @a bonesktready 0
scoreboard players add @a bonesktracking 0
scoreboard players add @a bonespt_cool 0
scoreboard players add @a bonesptready 0
scoreboard players add @a bonesptracking 0
scoreboard players add @a d_bone_cool 0
scoreboard players add @a bonedready 0
scoreboard players add @a bonedracking 0
scoreboard players add @a d_bone_2nd_shot_cool 0

#Makes Run once
tag @s add authenticated