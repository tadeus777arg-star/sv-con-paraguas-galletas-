#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#----------------------------------------------------------------------------------- Player Authentication ---------------------------------------------------------------------------------------------#
execute as @a[tag=!authenticated] at @s run function voa:player/authenticate


#----------------------------------------------------------------------------------- Alters/Plates/Benches ---------------------------------------------------------------------------------------------#
#--- Wealth Alter/Plate Start------------------------------------------------------------------------------>
#Plate of Wealth
execute as @e[type=minecraft:item_frame,tag=wealth,tag=!placed] at @s run function voa:plate_of_wealth/place
execute as @e[type=minecraft:item_frame,tag=wealth,tag=placed,tag=!used] at @s unless block ~ ~ ~ minecraft:quartz_slab run function voa:plate_of_wealth/remove
#Plate of Wealth END##


#Plate of Wrath
execute as @e[type=minecraft:item_frame,tag=wrath,tag=!placed] at @s run function voa:plate_of_wrath/place
execute as @e[type=minecraft:item_frame,tag=wrath,tag=placed,tag=!used] at @s unless block ~ ~ ~ minecraft:quartz_slab run function voa:plate_of_wrath/remove
#Plate of Wrath END##


#Wealth Alter
execute as @e[type=minecraft:item_frame,tag=wealth_alter] at @s run function voa:wealth_alter/place
execute as @e[type=minecraft:armor_stand,tag=wealth_alter] at @s unless block ~ ~ ~ minecraft:bedrock run function voa:wealth_alter/remove
#Detects Plate of Abundance and runs the Loot Summon function!
execute as @e[type=minecraft:armor_stand,tag=wealth_alter] at @s if block ~ ~ ~ minecraft:bedrock if entity @e[distance=0..1.5,tag=wealth,tag=!used] run function voa:wealth_alter/summon
execute as @e[type=minecraft:armor_stand,tag=wealth_alter] at @s if block ~ ~ ~ minecraft:bedrock run kill @e[type=minecraft:item,tag=used,nbt={Item:{id:"minecraft:item_frame"}},distance=..2]
#Music for Vault 
#execute as @e[type=minecraft:armor_stand,tag=wealth_alter,tag=!nomusic] at @s if entity @e[distance=0..40,type=player] run function voa:wealth_alter/music
#Wealth Alter  END##



#Wrath Alter
execute as @e[type=minecraft:item_frame,tag=wrath_alter] at @s run function voa:wrath_alter/place
execute as @e[type=minecraft:armor_stand,tag=wrath_alter] at @s unless block ~ ~ ~ minecraft:bedrock run function voa:wrath_alter/remove
#Detects Dread Plate and runs the Boss Summon function! - Also makes it so that only one boss can be summoned at a time!
execute as @e[type=minecraft:armor_stand,tag=wrath_alter] at @s if entity @e[distance=..100,tag=boss,type=husk] run tag @s add boss_active
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active] at @s unless entity @e[distance=..600,tag=boss,type=husk] run function voa:boss/reward
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active] at @s unless entity @e[distance=..600,tag=boss,type=husk] run tag @s remove boss_active

#Spawns Boss
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=!boss_active] at @s if block ~ ~ ~ minecraft:bedrock if entity @e[distance=0..1.5,tag=wrath,tag=!used] run function voa:boss/bossspawn

#TP - Holds Boss in Middle of room
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,limit=1,sort=nearest] at @s run tp @e[type=husk,tag=boss,limit=1,sort=nearest,tag=phase1,distance=..200] ~7.5 ~ ~.5

#Phase One - Spook Spawn

##Alpha 1 function is called via bossspawn function
#ALPHA
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha6,tag=alpha] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..2},distance=..120] run function voa:boss/phase2/bossetup_phase2
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha5,tag=alpha] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha6
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha4,tag=alpha] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha5
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha3,tag=alpha] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha4
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha2,tag=alpha] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha3
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=alpha1,tag=alpha] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/alpha/alpha2
#BETA
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta6,tag=beta] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..2},distance=..120] run function voa:boss/phase2/bossetup_phase2
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta5,tag=beta] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta6
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta4,tag=beta] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta5
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta3,tag=beta] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta4
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta2,tag=beta] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta3
execute as @e[type=minecraft:armor_stand,tag=wrath_alter,tag=boss_active,tag=beta1,tag=beta] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=..1},distance=..120] run function voa:boss/beta/beta2

#Kills Plate
execute as @e[type=minecraft:armor_stand,tag=wrath_alter] at @s if block ~ ~ ~ minecraft:bedrock run kill @e[type=minecraft:item,tag=used,nbt={Item:{id:"minecraft:item_frame",tag:{wrath:1b}}},distance=..2]

#--- Magic Bench----------------------------------------------------------------------------------------->
#Magic Bench
execute as @e[type=minecraft:item_frame,tag=magic_bench] at @s run function voa:magic_bench/place
execute as @e[type=minecraft:armor_stand,tag=magic_bench] at @s unless block ~ ~ ~ minecraft:dropper run function voa:magic_bench/remove
execute as @e[tag=magic_bench] at @s run function voa:magic_bench/crafting

#---Magic-Bench Armor-stand Spawn# 
execute as @e[type=minecraft:armor_stand,tag=magicbenchmarker,tag=!summoned] at @s run function voa:magic_bench/placechance
execute as @e[type=minecraft:armor_stand,tag=magicbenchmarker,tag=summoned] at @s run kill @s
#Magic Bench  END##

#----------------------------------------------------------------------------------- Items ---------------------------------------------------------------------------------------------#

#--- Bone Dust Bomb-------------------------------------------------------------------------------------->
### Runs throw function
#Detects if Player has a BDB in main hand.
execute as @a[nbt={SelectedItem:{id:"minecraft:snowball",tag:{bdb:1b}}}] at @s run tag @s add bomb
execute as @e[type=minecraft:snowball,nbt={Item:{tag:{bdb:1b}}}] as @a[tag=bomb] at @s anchored eyes run function voa:bone_dust_bomb/bomb
execute as @e[type=minecraft:armor_stand,tag=player,tag=!motion] at @s rotated as @a[tag=bomb] run function voa:bone_dust_bomb/motion
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={bdb_cool=1..35}] at @s run particle minecraft:large_smoke
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={bdb_cool=0}] at @s run function voa:bone_dust_bomb/timer
#Removes tag if thrown, or if they don't have the BDB selected.
execute as @a[nbt=!{SelectedItem:{id:"minecraft:snowball",tag:{bdb:1b}}}] at @s run tag @s remove bomb
scoreboard players remove @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={bdb_cool=1..}] bdb_cool 1

#End Bone Dust Bomb#

#--- Dyna-Bomb-------------------------------------------------------------------------------------->
### Runs throw function
#Detects if Player has a BDB in main hand.
execute as @a[nbt={SelectedItem:{id:"minecraft:snowball",tag:{bynab:1b}}}] at @s run tag @s add dynabomb
execute as @e[type=minecraft:snowball,nbt={Item:{tag:{bynab:1b}}}] as @a[tag=dynabomb] at @s anchored eyes run function voa:dyna_bomb/bomb
execute as @e[type=minecraft:armor_stand,tag=player,tag=!motion] at @s rotated as @a[tag=dynabomb] run function voa:dyna_bomb/motion
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={byb_cool=1..35}] at @s run particle minecraft:large_smoke
execute as @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={byb_cool=0}] at @s run function voa:dyna_bomb/timer
#Removes tag if thrown, or if they don't have the BDB selected.
execute as @a[nbt=!{SelectedItem:{id:"minecraft:snowball",tag:{bynab:1b}}}] at @s run tag @s remove dynabomb

#Removes for both BDB and DYB
scoreboard players remove @e[type=minecraft:armor_stand,tag=player,tag=motion,scores={byb_cool=1..}] byb_cool 1
#End Dyna-Bomb#


#--- Bonelock Weapon------------------------------------------------------------------------------------->
#Ready to Fire!
execute as @a[scores={bonelk=1..,bonelk_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonelock:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonelock/shot
#Keeps setting the score to 1 when player fires the Bonelock (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonelk=1..}] bonelk 0
#Sets Cooldown between shots and resets it
scoreboard players remove @a[scores={bonelk_cool=1..}] bonelk_cool 1
#Bonelock END#


#--- Bonesket Weapon------------------------------------------------------------------------------------->
#Reload Weapon
execute as @a[scores={bonesktrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesket:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonesket/reload
execute as @a[scores={boneskt_cool=..1},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesket:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonesket/steady_weapon
#Racked Round
execute as @a[scores={boneskt=18..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesket:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonesket/rack_round
#Ready to Fire!
execute as @a[scores={bonesktracking=0,bonesktrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesketloaded:1b}}}] at @s run function voa:bonesket/shot

#Reload Scoreboards for Animation, plus steadies weapon when not reloading.
#Keeps setting the score to 1 when player fires the Bonesketrld (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonesktrld=1..}] bonesktrld 0
scoreboard players remove @a[scores={boneskt_cool=1..}] boneskt_cool 1
scoreboard players remove @a[scores={bonesktready=1..}] bonesktready 1
#How long until the round is racked, once it hits ten the round is racked and the countdown resets.
scoreboard players set @a[scores={boneskt=18..}] boneskt 0
#Sets rackround cooldown, so round doesn't immediately fire.
scoreboard players remove @a[scores={bonesktracking=1..}] bonesktracking 1
#Bonesket END#


#--- Bonesplitter Weapon------------------------------------------------------------------------------------->
#Reload Weapon
execute as @a[scores={bonesptrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesplitter:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonesplitter/reload
execute as @a[scores={bonespt_cool=..1},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesplitter:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonesplitter/steady_weapon
#Racked Round
execute as @a[scores={bonespt=13..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesplitter:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:bonesplitter/rack_round
#Ready to Fire!
execute as @a[scores={bonesptracking=0,bonesptrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{bonesplitterloaded:1b}}}] at @s run function voa:bonesplitter/shot

#Multi-Enemy Dmg
execute as @e[tag=shot] at @s run function voa:bonesplitter/dmg

#Reload Scoreboards for Animation, plus steadies weapon when not reloading.
##Keeps setting the score to 1 when player fires the Bonesketrld (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonesptrld=1..}] bonesptrld 0
scoreboard players remove @a[scores={bonespt_cool=1..}] bonespt_cool 1
scoreboard players remove @a[scores={bonesptready=1..}] bonesptready 1

##How long until the round is racked, once it hits ten the round is racked and the countdown resets.
scoreboard players set @a[scores={bonespt=13..}] bonespt 0
##Sets rackround cooldown, so round doesn't immediately fire.
scoreboard players remove @a[scores={bonesptracking=1..}] bonesptracking 1
#Bonesket END#


#--- Double-Bone Weapon------------------------------------------------------------------------------------->
#Reload Weapon
execute as @a[scores={bonedrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{dbone:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:double_bone/reload
execute as @a[scores={d_bone_cool=..1},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{dbone:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:double_bone/steady_weapon
#Racked Round
execute as @a[scores={bonedoub=13..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{dbone:1b}}},nbt={Inventory:[{id:"minecraft:stick",tag:{boneshot:1b}}]}] at @s run function voa:double_bone/rack_round
#Ready to Fire! - Half Loaded
execute as @a[scores={bonedracking=0,bonedrld=1..,d_bone_2nd_shot_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{dboneloaded:1b}}}] at @s run function voa:double_bone/shot
#Ready to Fire! - Full Loaded
execute as @a[scores={bonedracking=0,bonedrld=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{dboneloaded_2:1b}}}] at @s run function voa:double_bone/shot_full


#Multi-Enemy Dmg
execute as @e[tag=shot_double] at @s run function voa:double_bone/dmg

#Reload Scoreboards for Animation, plus steadies weapon when not reloading.
##Keeps setting the score to 1 when player fires the Bonesketrld (THIS CODE NEEDS TO BE BELOW COMMANDS AT THE BOTTOM!)
scoreboard players set @a[scores={bonedrld=1..}] bonedrld 0
scoreboard players remove @a[scores={d_bone_cool=1..}] d_bone_cool 1
scoreboard players remove @a[scores={d_bone_2nd_shot_cool=1..}] d_bone_2nd_shot_cool 1
scoreboard players remove @a[scores={bonedready=1..}] bonedready 1

##How long until the round is racked, once it hits ten the round is racked and the countdown resets.
scoreboard players set @a[scores={bonedoub=13..}] bonedoub 0
##Sets rackround cooldown, so round doesn't immediately fire.
scoreboard players remove @a[scores={bonedracking=1..}] bonedracking 1
#Double-Bone END#



#--- Swords ----------------------------------------------------------------------------------------------->
#PestKeeper
execute as @e[type=#voa:pest] at @s if entity @a[scores={irony=1..},distance=..10,nbt={SelectedItem:{id:"minecraft:iron_sword",Count:1b,tag:{pestkeeper:1b}}}] run function voa:swords/pest
#PestKeeper END##


#Spectral-Schimitar
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{schimitar:1b}}}] at @s if entity @e[tag=ghost,distance=..6] run function voa:swords/ghost
#Spectral-Schimitar END##


#Cake-Blade
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",Count:1b,tag:{cakeblade:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/cake
#Cake-Blade END##


#Cookie-Monster
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{cookieblade:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/cookie
#Cookie-Monster END##


#Coal-Train
execute as @a[nbt={SelectedItem:{id:"minecraft:iron_sword",Count:1b,tag:{coaltrain:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/coaltrain
execute as @a[nbt={SelectedItem:{id:"minecraft:iron_sword",Count:1b,tag:{coaltrain:1b}}}] at @s if entity @a[scores={coaltrain=1..}] run execute anchored eyes positioned ^ ^ ^ run particle minecraft:large_smoke ^-.05 ^ ^1.5   
#Coal-Train END##


#Emerald-Embezzler
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",Count:1b,tag:{emeraldblade:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/embezzler 
#Emerald-Embezzler END##


#Psionic Sabre
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{psi_sabre:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/psionic
#Emerald-Embezzler END##


#Ice Sword
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{ice_sword:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/ice_sword
execute as @e[tag=snowdamage] run function voa:swords/ice_sword_damage
#Ice Sword END##


#X-blade(Chaos)
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{xbladec:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6,type=!player] run function voa:swords/xblades/chaos
execute as @e[tag=rocket,tag=!expo] at @s run function voa:swords/xblades/chaos_rocket
execute as @e[tag=rocket,scores={xblade_c_cool=..1}] at @s run function voa:swords/xblades/chaos_rocket_detonate
execute as @e[tag=rocket] at @s run particle minecraft:firework ~ ~ ~ .2 .2 .2 .2 1
#X-blade(Chaos) END##


#X-blade(Harmony)
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{xbladeh:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/xblades/harmony
#X-blade(Harmony) END##


#X-blade(Lucky)
execute as @a[nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{xbladel:1b}}}] at @s if entity @e[nbt={HurtTime:10s},distance=..6] run function voa:swords/xblades/lucky
execute as @e[tag=luck,type=!ravager,tag=!titan,type=!warden] at @s run function voa:swords/xblades/lucky_spawn
execute as @e[tag=luck,type=ravager] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luck,tag=titan] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luck,type=warden] at @s run function voa:swords/xblades/lucky_spawn_big
execute as @e[tag=luckybat] at @s unless entity @a[distance=..20] run tp @s ~ ~-256 ~
#X-blade(Lucky) END##


#X-blade(Dangerous)
execute as @e[type=!item,type=!painting,type=!item_frame,type=!armor_stand] at @s if entity @a[scores={xblade_d=1..},distance=..8,nbt={SelectedItem:{id:"minecraft:netherite_sword",Count:1b,tag:{xbladed:1b}}}] run function voa:swords/xblades/dangerous
#X-blade(Dangerous) END##


##SWORD SCOREBOARDS - ALL
scoreboard players set @e[scores={embezzler=1..}] embezzler 0
scoreboard players set @a[scores={coaltrain=1..}] coaltrain 0
scoreboard players set @a[scores={irony=1..}] irony 0
scoreboard players set @a[scores={xblade_d=1..}] xblade_d 0
scoreboard players remove @e[scores={xblade_c_cool=1..}] xblade_c_cool 1
#--- Swords END------------------------------------------------------------------------------------------->

#--- Armor Sets ----------------------------------------------------------------------------------------------->
#Tome Armor - Setting Tome Reuse Tag
execute as @a[tag=!tome_reuse_helm,nbt={Inventory:[{id:"minecraft:netherite_helmet",Slot:103b,tag:{tometic:1b}}]}] at @s run tag @s add tome_reuse_helm
execute as @a[tag=!tome_reuse_chest,nbt={Inventory:[{id:"minecraft:netherite_chestplate",Slot:102b,tag:{tometic:1b}}]}] at @s run tag @s add tome_reuse_chest
execute as @a[tag=!tome_reuse_legs,nbt={Inventory:[{id:"minecraft:netherite_leggings",Slot:101b,tag:{tometic:1b}}]}] at @s run tag @s add tome_reuse_legs
execute as @a[tag=!tome_reuse_boots,nbt={Inventory:[{id:"minecraft:netherite_boots",Slot:100b,tag:{tometic:1b}}]}] at @s run tag @s add tome_reuse_boots

#Tome Armor - Setting Tome Reuse Tag
execute as @a[tag=tome_reuse_helm] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:netherite_helmet",Slot:103b,tag:{tometic:1b}}]}] at @s run tag @s remove tome_reuse_helm
execute as @a[tag=tome_reuse_chest] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:netherite_chestplate",Slot:102b,tag:{tometic:1b}}]}] at @s run tag @s remove tome_reuse_chest
execute as @a[tag=tome_reuse_legs] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:netherite_leggings",Slot:101b,tag:{tometic:1b}}]}] at @s run tag @s remove tome_reuse_legs
execute as @a[tag=tome_reuse_boots] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:netherite_boots",Slot:100b,tag:{tometic:1b}}]}] at @s run tag @s remove tome_reuse_boots



#--- Armor Sets END ----------------------------------------------------------------------------------------------->

#Defender Trophy - HEAD PLAYER ITEM!
execute as @e[type=minecraft:item_frame,tag=defender,tag=!placed] at @s run function voa:defender_trophy/place
execute as @e[type=minecraft:item_frame,tag=defender,tag=placed] at @s unless block ~ ~ ~ minecraft:player_head run function voa:defender_trophy/remove

#Defender Trophy END- HEAD PLAYER ITEM!
execute as @e[type=minecraft:item_frame,tag=defender_end,tag=!placed] at @s run function voa:defender_trophy/place_end
execute as @e[type=minecraft:item_frame,tag=defender_end,tag=placed] at @s unless block ~ ~ ~ minecraft:player_head run function voa:defender_trophy/remove_end

#----------------------------------------------------------------------------------- Magic Staffs ---------------------------------------------------------------------------------------------#

#Harmony Staff
##Staff Fires AOE Heal
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh12:1b}}}] at @s run function voa:staff_harmony/harmony12
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh11:1b}}}] at @s run function voa:staff_harmony/harmony11
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh10:1b}}}] at @s run function voa:staff_harmony/harmony10
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh9:1b}}}] at @s run function voa:staff_harmony/harmony9
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh8:1b}}}] at @s run function voa:staff_harmony/harmony8
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh7:1b}}}] at @s run function voa:staff_harmony/harmony7
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh6:1b}}}] at @s run function voa:staff_harmony/harmony6
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh5:1b}}}] at @s run function voa:staff_harmony/harmony5
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh4:1b}}}] at @s run function voa:staff_harmony/harmony4
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh3:1b}}}] at @s run function voa:staff_harmony/harmony3
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh2:1b}}}] at @s run function voa:staff_harmony/harmony2
execute as @a[scores={staff_h=1..,staff_h_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffh1:1b}}}] at @s run function voa:staff_harmony/harmony1
##Scoreboards
scoreboard players set @a[scores={staff_h=1..}] staff_h 0
scoreboard players remove @a[scores={staff_h_cool=1..}] staff_h_cool 1 
#Harmony Staff END#


#Lucky Staff
##Staff Fires Chicken Claw
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl12:1b}}}] at @s run function voa:staff_lucky/lucky12
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl11:1b}}}] at @s run function voa:staff_lucky/lucky11
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl10:1b}}}] at @s run function voa:staff_lucky/lucky10
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl9:1b}}}] at @s run function voa:staff_lucky/lucky9
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl8:1b}}}] at @s run function voa:staff_lucky/lucky8
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl7:1b}}}] at @s run function voa:staff_lucky/lucky7
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl6:1b}}}] at @s run function voa:staff_lucky/lucky6
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl5:1b}}}] at @s run function voa:staff_lucky/lucky5
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl4:1b}}}] at @s run function voa:staff_lucky/lucky4
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl3:1b}}}] at @s run function voa:staff_lucky/lucky3
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl2:1b}}}] at @s run function voa:staff_lucky/lucky2
execute as @a[scores={staff_l=1..,staff_l_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffl1:1b}}}] at @s run function voa:staff_lucky/lucky1
###Scoreboards
scoreboard players set @a[scores={staff_l=1..}] staff_l 0
scoreboard players remove @a[scores={staff_l_cool=1..}] staff_l_cool 1 

#Ravager Health - Lucky Tome/Staff
execute as @e[type=minecraft:ravager,tag=!healthy] at @s run function voa:staff_lucky/ravager
execute as @e[type=minecraft:ravager,tag=healthy] run execute store result score @s titanhealth run data get entity @s Health

#Warden Health - Lucky Tome/Staff
execute as @e[type=minecraft:warden,tag=!healthy] at @s run function voa:staff_lucky/warden
execute as @e[type=minecraft:warden,tag=healthy] run execute store result score @s titanhealth run data get entity @s Health
#Lucky Staff END#


#Dangerous Staff
##Staff Summons Fireball
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd12:1b}}}] at @s run function voa:staff_dangerous/dangerous12
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd11:1b}}}] at @s run function voa:staff_dangerous/dangerous11
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd10:1b}}}] at @s run function voa:staff_dangerous/dangerous10
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd9:1b}}}] at @s run function voa:staff_dangerous/dangerous9
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd8:1b}}}] at @s run function voa:staff_dangerous/dangerous8
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd7:1b}}}] at @s run function voa:staff_dangerous/dangerous7
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd6:1b}}}] at @s run function voa:staff_dangerous/dangerous6
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd5:1b}}}] at @s run function voa:staff_dangerous/dangerous5
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd4:1b}}}] at @s run function voa:staff_dangerous/dangerous4
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd3:1b}}}] at @s run function voa:staff_dangerous/dangerous3
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd2:1b}}}] at @s run function voa:staff_dangerous/dangerous2
execute as @a[scores={staff_d=1..,staff_d_cool=0},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffd1:1b}}}] at @s run function voa:staff_dangerous/dangerous1
###Scoreboards
scoreboard players set @a[scores={staff_d=1..}] staff_d 0
scoreboard players remove @a[scores={staff_d_cool=1..}] staff_d_cool 1 
#Dangerous Staff END#


#Chaos Staff
##Staff Fires
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc12:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc11:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc10:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc9:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc8:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc7:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc6:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc5:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc4:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc3:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc2:1b}}}] at @s run function voa:staff_chaos/chaos_effect
execute as @a[scores={staff_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc1:1b}}}] at @s run function voa:staff_chaos/chaos_effect

##Staff Wears Down
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc12:1b}}}] at @s run function voa:staff_chaos/chaos12_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc11:1b}}}] at @s run function voa:staff_chaos/chaos11_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc10:1b}}}] at @s run function voa:staff_chaos/chaos10_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc9:1b}}}] at @s run function voa:staff_chaos/chaos9_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc8:1b}}}] at @s run function voa:staff_chaos/chaos8_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc7:1b}}}] at @s run function voa:staff_chaos/chaos7_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc6:1b}}}] at @s run function voa:staff_chaos/chaos6_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc5:1b}}}] at @s run function voa:staff_chaos/chaos5_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc4:1b}}}] at @s run function voa:staff_chaos/chaos4_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc3:1b}}}] at @s run function voa:staff_chaos/chaos3_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc2:1b}}}] at @s run function voa:staff_chaos/chaos2_worn
execute as @a[scores={staff_c_cool=45..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{staffc1:1b}}}] at @s run function voa:staff_chaos/chaos1_worn

##Scoreboards
scoreboard players set @a[scores={staff_c=1..}] staff_c 0
#Chaos Staff END#



#----------------------------------------------------------------------------------- Tomes ---------------------------------------------------------------------------------------------#

#Harmony Tome
execute as @a[scores={tome_h=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{tome_h:1b}}}] at @s run function voa:tome_harmony/harmony_fire

#Lucky Tome
execute as @a[scores={tome_l=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{tome_l:1b}}}] at @s run function voa:tome_lucky/lucky_fire

#Chaos Tome
execute as @a[scores={tome_c=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",Count:1b,tag:{tome_c:1b}}}] at @s run function voa:tome_chaos/chaos_fire
#Stasis Field
execute as @e[type=minecraft:armor_stand,tag=stasis,scores={tome_c_cool=1..}] at @s run function voa:tome_chaos/stasis
execute as @e[type=minecraft:armor_stand,tag=stasis,scores={tome_c_cool=..0}] at @s run kill @s


##Scoreboards - Tomes
scoreboard players set @a[scores={tome_h=1..}] tome_h 0
scoreboard players set @a[scores={tome_l=1..}] tome_l 0
scoreboard players set @a[scores={tome_c=1..}] tome_c 0
scoreboard players remove @e[tag=stasis,type=minecraft:armor_stand,scores={tome_c_cool=1..}] tome_c_cool 1


#----------------------------------------------------------------------------------- Lockets ---------------------------------------------------------------------------------------------#

######## Locket - Executable Item - TEMPLATE!!!
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{harmony_locket:1b}}]}] locket_h_delay 2
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{lucky_locket:1b}}]}] locket_c_delay 2
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{chaos_locket:1b}}]}] locket_l_delay 2

#Trigger Command
execute as @a[scores={locket_h_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Locket (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:313131,locket:1b} 1
execute as @a[scores={locket_c_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Locket (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:313131,locket:1b} 1
execute as @a[scores={locket_l_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Locket (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:313131,locket:1b} 1

##### Constantly remove 1 from the delay 
execute as @a[scores={locket_h_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{harmony_locket:1b}}]}] run scoreboard players remove @s locket_h_delay 1
execute as @a[scores={locket_c_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{chaos_locket:1b}}]}] run scoreboard players remove @s locket_c_delay 1
execute as @a[scores={locket_l_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{lucky_locket:1b}}]}] run scoreboard players remove @s locket_l_delay 1

#----------------------------------------------------------------------------------- Brooches ---------------------------------------------------------------------------------------------#
######## Brooch - Executable Item - TEMPLATE!!!
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{harmony_brooch:1b}}]}] brooch_h_delay 2
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{chaos_brooch:1b}}]}] brooch_c_delay 2
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{lucky_brooch:1b}}]}] brooch_l_delay 2
scoreboard players set @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{dangerous_brooch:1b}}]}] brooch_d_delay 2

######## Brooch - Executable Item - While Held
execute as @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{harmony_brooch:1b}}]}] at @s run effect give @s minecraft:regeneration 1 0
execute as @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{lucky_brooch:1b}}]}] at @s run effect give @s minecraft:luck 1 0
execute as @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{chaos_brooch:1b}}]}] at @s run effect give @s minecraft:slow_falling 1 1
execute as @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{chaos_brooch:1b}}]}] at @s run effect give @s minecraft:jump_boost 1 2
execute as @a[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{dangerous_brooch:1b}}]}] at @s run effect give @e[distance=..12] minecraft:strength 1 0

#Trigger Command - When Used In Death
execute as @a[scores={brooch_h_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Brooch (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:310000,brooch:1b} 1
execute as @a[scores={brooch_h_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5
execute as @a[scores={brooch_h_delay=1..,locketuse=1}] at @s run effect give @s minecraft:absorption 180 14
execute as @a[scores={brooch_c_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Brooch (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:310000,brooch:1b} 1
execute as @a[scores={brooch_c_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5 
execute as @a[scores={brooch_c_delay=1..,locketuse=1}] at @s run function voa:jewelry/chaos_brooch
execute as @a[scores={brooch_l_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Brooch (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:310000,brooch:1b} 1
execute as @a[scores={brooch_l_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5
execute as @a[scores={brooch_l_delay=1..,locketuse=1}] at @s run function voa:jewelry/lucky_brooch
execute as @a[scores={brooch_d_delay=1..,locketuse=1}] at @s run item replace entity @s weapon.offhand with stick{display:{Name:'{"text":"Void Brooch (Uncharged)","color":"dark_purple","italic":true}'},CustomModelData:310000,brooch:1b} 1
execute as @a[scores={brooch_d_delay=1..,locketuse=1}] at @s run effect give @s minecraft:instant_health 1 5
execute as @a[scores={brooch_d_delay=1..,locketuse=1}] at @s run function voa:jewelry/dangerous_brooch


#Tells if totem was used - For Both Brooch and Locket
scoreboard players remove @a[scores={locketuse=1..}] locketuse 1
##### Constantly remove 1 from the delay 
execute as @a[scores={brooch_h_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{harmony_brooch:1b}}]}] run scoreboard players remove @s brooch_h_delay 1
execute as @a[scores={brooch_c_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{chaos_brooch:1b}}]}] run scoreboard players remove @s brooch_c_delay 1
execute as @a[scores={brooch_l_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{lucky_brooch:1b}}]}] run scoreboard players remove @s brooch_l_delay 1
execute as @a[scores={brooch_d_delay=1..}] unless entity @s[nbt={Inventory:[{id:"minecraft:totem_of_undying",Slot:-106b,tag:{dangerous_brooch:1b}}]}] run scoreboard players remove @s brooch_d_delay 1

#----------------------------------------------------------------------------------- Mobs ---------------------------------------------------------------------------------------------#
# <!---------------------------------------------------------------------------- Willowbee MOB------------------------------------------------------------------------------>
#---Willowbee MOB START#

## Armor Stand Rotation for body 
execute as @e[type=minecraft:bee,tag=willowbee] at @s store result entity @e[type=minecraft:armor_stand,tag=willowbee_body,limit=1,sort=nearest] Rotation[0] float 1 run data get entity @s Rotation[0]
execute as @e[type=minecraft:armor_stand,tag=willowbee_body] at @s unless entity @e[type=minecraft:bee,tag=willowbee,distance=0..2] run function voa:willowbee/death
execute as @e[type=minecraft:armor_stand,tag=willowbee_body] at @s unless entity @e[type=minecraft:bee,tag=willowbee,distance=0..2] run kill @s

## Initializes Willowbee Animation/Sound function
execute as @e[type=minecraft:bee,tag=willowbee] at @s if entity @a[distance=0..100] run function voa:willowbee/animate
## Mob is always flying and wings are always moving.
scoreboard players add @e[type=minecraft:bee,tag=willowbee,scores={animate=0..}] animate 1

## Laying "Eggs"
execute as @e[type=minecraft:bee,tag=willowbee,nbt={TicksSincePollination:1}] at @s run function voa:willowbee/eggs

## Health AOE Function
execute as @e[type=minecraft:bee,tag=willowbee,scores={heal_cool=0}] at @s if entity @a[distance=0..60] run function voa:willowbee/heal
## Activates Cooldown functionality
scoreboard players remove @e[type=minecraft:bee,tag=willowbee,scores={heal_cool=1..}] heal_cool 1

## Runs Sound File
execute as @e[type=minecraft:bee,tag=willowbee,scores={sound_cool=0}] at @s if entity @a[distance=0..20] run function voa:willowbee/sounds
## Activates Cooldown functionality
scoreboard players remove @e[tag=willowbee,type=minecraft:bee,scores={sound_cool=1..}] sound_cool 1

#SPAWN EGG FUNCTION - LEGACY/OLD
execute as @e[tag=willowbeeegg] at @s run function voa:willowbee/spawnegg
execute as @e[tag=willowbeeegg] at @s run tp @s ~ ~-260 ~

#SPAWN EGG FUNCTION - NEW!
execute as @e[type=minecraft:armor_stand,tag=willowbeeegg,tag=!summoned] at @s run function voa:willowbee/spawnegg
execute as @e[type=minecraft:armor_stand,tag=willowbeeegg,tag=summoned] at @s run kill @s

#Hive Commands
execute as @e[type=minecraft:bee,tag=willowbee,tag=!hived] at @s unless entity @e[type=minecraft:armor_stand,tag=willowbee_body,distance=..1] run function voa:willowbee/hive
execute as @e[type=minecraft:bee,tag=willowbee,tag=hived] at @s run tp @s ~ ~-260 ~

#---End willowbee Mob#

# <!---------------------------------------------------------------------------- Enchanted Brew MOB------------------------------------------------------------------------------>

execute as @e[type=minecraft:zombie,tag=brew_harmful] at @s if entity @a[distance=..3] run function voa:brew/harm
execute as @e[type=minecraft:zombie,tag=brew_poison] at @s if entity @a[distance=..3] run function voa:brew/poison
execute as @e[type=minecraft:zombie,tag=brew_weakness] at @s if entity @a[distance=..3] run function voa:brew/weakness
execute as @e[type=minecraft:zombie,tag=brew_levitation] at @s if entity @a[distance=..3] run function voa:brew/levitation


# <!---------------------------------------------------------------------------- Ethereal Citizen MOB------------------------------------------------------------------------------>

#Ethereal Touch
#execute as @e[tag=ethereal] at @s if entity @a[distance=..1.5] run effect give @a[distance=..1.5] minecraft:weakness 5 0

#Buccaneer Potion Drop
execute as @e[tag=potionhold,nbt={HurtTime:10s}] at @s run function voa:end_pirate/potionhold

#Ethereal-Citizen Aura - Casts to nearby Ethereal Fighters
execute as @e[tag=ethereal_citizen] at @s run effect give @s minecraft:conduit_power
execute as @e[tag=ethereal_citizen] at @s if entity @a[distance=..3] run effect give @a[distance=..3] minecraft:weakness 5 0
execute as @e[tag=ethereal_citizen] at @s if entity @e[distance=..3,tag=ethereal] run effect give @e[tag=ethereal,distance=..5] minecraft:regeneration 5 1