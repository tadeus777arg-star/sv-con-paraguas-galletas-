#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected
tag @s add raycasting

# Anchor to the eyes and position with vector coordinates (Remove if not running from eyes of entity)
execute anchored eyes positioned ^ ^ ^.8 run function voa:bonesplitter/path

# Remove the raycasting tag after raycast completion to prepare for the next player
tag @s remove raycasting
scoreboard players reset .distance tf_rc

#Muzzle Flash - And Sound
execute anchored eyes positioned ^ ^ ^ run particle minecraft:flame ^-.05 ^ ^1.1 
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.1 ^1.1 
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.3 ^1.1
execute anchored eyes positioned ^ ^ ^ run particle smoke ^ ^.5 ^1.1
playsound minecraft:musket.fire ambient @a[distance=..20] ~ ~ ~ 3

#Fired Rifle - Empty Chamber
item replace entity @p weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Bonesplitter"}'},HideFlags:1,CustomModelData:888888,bonesplitter:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s}]} 1


#Stops Lift Animation
scoreboard players set @p[scores={bonesptready=0..}] bonesptready 8
#tag @s add liftanimation

