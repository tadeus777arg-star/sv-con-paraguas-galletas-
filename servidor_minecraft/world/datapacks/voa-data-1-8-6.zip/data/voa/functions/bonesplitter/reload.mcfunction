#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

# Tag prevents current caster from being detected

item replace entity @p weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Bonesplitter"}'},HideFlags:1,CustomModelData:888889,bonesplitter:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s}]} 1

effect give @s[] slowness 1 3 true

scoreboard players set @a[scores={bonespt_cool=0..}] bonespt_cool 8
