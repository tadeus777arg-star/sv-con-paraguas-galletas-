#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

##Removes Ammo from inventory
clear @s stick{display:{Name:'{"text":"boneshot"}'},CustomModelData:262626,boneshot:1b} 1

# Steady Weapons
playsound minecraft:block.stone_button.click_on ambient @p[distance=..10]
item replace entity @s weapon.mainhand with carrot_on_a_stick{display:{Name:'{"text":"Bonesplitter(Loaded)"}'},HideFlags:1,CustomModelData:888888,bonesplitterloaded:1b,Enchantments:[{id:"minecraft:knockback",lvl:1s}]} 1


scoreboard players set @p[scores={bonesptracking=0..}] bonesptracking 18


effect clear @s[] slowness