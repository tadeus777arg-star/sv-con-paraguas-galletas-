#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function -
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#Spawn Structure
execute if score out math matches 0 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -20, sizeX: 47, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:marauders_market_1", id: "minecraft:structure_block", sizeY: 47, sizeZ: 47, showboundingbox: 1b}
execute if score out math matches 1 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -20, sizeX: 47, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:marauders_market_2", id: "minecraft:structure_block", sizeY: 47, sizeZ: 47, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -23, mode: "LOAD", posY: -20, sizeX: 47, posZ: -23, integrity: 1.0f, showair: 0b, name: "voa:marauders_market_3", id: "minecraft:structure_block", sizeY: 47, sizeZ: 47, showboundingbox: 1b}

setblock ~ ~1 ~ minecraft:redstone_block

#Setting Air Tower 2
#setblock ~ ~25 ~ minecraft:air
#setblock ~ ~24 ~ minecraft:air

tag @s add summoned