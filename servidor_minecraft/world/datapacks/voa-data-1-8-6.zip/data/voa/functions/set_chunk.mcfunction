#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This marks the chunk as generated, and manipulates what happens with each chunk

#Checks to see if chunk has been loaded previously or not.
fill ~ -63 ~ ~15 -63 ~15 red_wool
fill ~ -62 ~ ~15 -62 ~15 bedrock

#Can cleanup the RNG datapack to just use the lcg
#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 1200
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens
execute if score out math matches 1100 run function voa:surface
execute if score out math matches 800 run function voa:surface_manor
execute if score out math matches 700 run function voa:surface_manor
