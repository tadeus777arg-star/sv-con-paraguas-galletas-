#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks


### THIS IS THE SPAWN COMMAND if I need to change the mob attributes this is where I will do it!!!
summon zombie ~ ~1 ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",Health:36f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["abomination"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abomination_body"],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:333331}}]}],CustomName:'{"text":"Abomination"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:333321}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:36},{Name:generic.follow_range,Base:30},{Name:generic.knockback_resistance,Base:0.35},{Name:generic.movement_speed,Base:0.32},{Name:generic.attack_damage,Base:7},{Name:zombie.spawn_reinforcements,Base:0}]}

#Particle & Sound
particle minecraft:squid_ink ~ ~0.5 ~ 1 1 1 0.00000000001 100
playsound minecraft:entity.generic.explode hostile @a[] ~ ~ ~ 5

#Gets rid of creeper
tp @s ~ ~-256 ~

