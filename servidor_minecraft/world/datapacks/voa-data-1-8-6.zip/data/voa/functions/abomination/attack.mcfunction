#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#How long it takes to cool down
scoreboard players set @s atk_cool 100

#Giving the custom attack
effect give @a[distance=0..5] blindness 6

#particle affects
particle minecraft:squid_ink ~ ~0.5 ~ 5 0.5 5 0.000000001 60

#B-E-A-G-L-E-B-L-O-C-K-S