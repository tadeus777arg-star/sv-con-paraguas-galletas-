#All of the code below is part of the Vaults of Abandon datapack created by Fried_Oats

###  If matches 0 
execute if score abomination_count cm_abomination matches 0 run summon zombie ~ ~ ~ {Silent:1b,CustomNameVisible:0b,DeathLootTable:"voa:entities/abom_loot",Health:36f,IsBaby:0b,CanBreakDoors:1b,DrownedConversionTime:999999,Tags:["abomination"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abomination_body"],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:333331}}]}],CustomName:'{"text":"Abomination"}',ArmorItems:[{},{},{},{id:'minecraft:flint',Count:1b,tag:{CustomModelData:333321}}],ArmorDropChances:[0.085F,0.085F,0.085F,-327.670F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:36},{Name:generic.follow_range,Base:30},{Name:generic.knockback_resistance,Base:0.35},{Name:generic.movement_speed,Base:0.32},{Name:generic.attack_damage,Base:7},{Name:zombie.spawn_reinforcements,Base:0}]}
#/summon zombie ~ ~ ~ {Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:333331}}]}],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:333321}}],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}]}
#/summon zombie ~ ~ ~ {Tags:["abomination"],Passengers:[{id:"minecraft:armor_stand",Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,Tags:["abomination_body"],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:333331}}]}],ArmorItems:[{},{},{},{id:"minecraft:flint",Count:1b,tag:{CustomModelData:333321}}],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:999999,show_particles:0b}]}
execute if score abomination_count cm_abomination matches 0 run tp @s ~ ~-256 ~

### Add tag not_messenger to ensure the Zombie is not scanned again
tag @s add not_abomination
### Increment count
scoreboard players add abomination_count cm_abomination 1
### Reset Count
execute if score abomination_count cm_abomination matches 5 run scoreboard players set abomination_count cm_abomination 0

### INITALIZES CUSTOM ATTACK VARIABLE AND CUSTOM SOUND VARIABLES - OTHERWISE CUSTOM ATTACK COUNTER/COOLDOWN WON'T WORK!
scoreboard players add @e[tag=abomination,type=minecraft:zombie] atk_cool 0
scoreboard players add @e[tag=abomination,type=minecraft:zombie] sound_cool 0