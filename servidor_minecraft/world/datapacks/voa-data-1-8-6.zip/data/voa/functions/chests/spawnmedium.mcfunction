#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 2
function voa:natural_generation/random/range_lcg

#B-E-A-G-L-E-B-L-O-C-K-S

#Spawn Chest Vault-Medium
execute if score out math matches 1 run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_medium"}

tag @s add summoned