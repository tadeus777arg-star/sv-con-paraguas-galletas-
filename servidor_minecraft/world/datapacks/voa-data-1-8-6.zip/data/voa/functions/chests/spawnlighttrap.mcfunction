#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 4
function voa:natural_generation/random/range_lcg

#If 1 is selected, the following happens
execute if score out math matches 0 run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_light"}
execute if score out math matches 1 run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_light"}
execute if score out math matches 2 run setblock ~ ~ ~ minecraft:structure_block{metadata: "", mirror: "NONE", ignoreEntities: 0b, powered: 0b, seed: 0L, author: "FriedOats", rotation: "NONE", posX: -1, mode: "LOAD", posY: -2, sizeX: 3, posZ: -1, integrity: 1.0f, showair: 0b, name: "voa:tnt_trap", id: "minecraft:structure_block", sizeY: 3, sizeZ: 3, showboundingbox: 1b}
execute if score out math matches 2 run setblock ~ ~1 ~ minecraft:redstone_block
execute if score out math matches 2 run setblock ~ ~1 ~ minecraft:air
execute if score out math matches 3 run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_light"}
execute if score out math matches 4 run setblock ~ ~ ~ chest{LootTable:"voa:blocks/vault_light"}

tag @s add summoned