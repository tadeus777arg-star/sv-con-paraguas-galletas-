#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#----------------------------------------------------------------------------------- Mobs - Spooks ---------------------------------------------------------------------------------------------#

#----------------------------------------------------------------------------------- Wraith------------------------------------------------------------------------------>
#Wraith MOB START#
#Wraith Mob Scan/Allows Swaping naturally ###
execute as @e[type=minecraft:skeleton,tag=!not_wraith,sort=random] at @s run function voa:wraith/wraith_spawn
execute as @e[type=minecraft:skeleton,tag=!not_wraith_nether] at @s if entity @a[distance=..50,nbt={Dimension:"minecraft:the_nether"}] run function voa:wraith/wraith_spawn_nether

#Initializes Wraith Animation/Sound function
execute as @e[tag=wraith,type=minecraft:husk] at @s if entity @a[distance=0..40] run function voa:wraith/animate

#Runs Sound File
execute as @e[tag=wraith,type=minecraft:husk,scores={sound_cool=0}] at @s if entity @a[distance=0..16] run function voa:wraith/sounds
## Activates Cooldown functionality
execute as @e[tag=wraith,type=minecraft:husk] at @s if entity @a[distance=0..16] run scoreboard players remove @e[tag=wraith,type=minecraft:husk,scores={sound_cool=1..}] sound_cool 1

#Mob BURN function - Burns the Mob in daylight
#Check Time of day
execute store result score @e[tag=wraith,type=minecraft:husk] timeofday run time query daytime
#Burns Mob if conditions are correct.
execute as @e[tag=wraith,type=minecraft:husk,scores={timeofday=0..12500}] at @s if entity @a[distance=..40,nbt={Dimension:"minecraft:overworld"}] run function voa:wraith/skycheck
#Nether Function - Makes movement on Soul Sand/Soil Fast
execute as @e[tag=wraith,type=minecraft:husk] at @s if block ~ ~-1 ~ #voa:wraith_buff run effect give @s minecraft:speed 1 1
execute as @e[tag=wraith,type=minecraft:husk] at @s if block ~ ~-1 ~ #voa:wraith_buff run effect give @s minecraft:strength 1 0

#Armor-Stand Spawner
execute as @e[type=minecraft:armor_stand,tag=spawnwraith100,tag=!summoned] at @s run function voa:wraith/wraith_spawn_100
execute as @e[type=minecraft:armor_stand,tag=spawnwraith100,tag=summoned] at @s run kill @s
#End Wraith Mob#

#----------------------------------------------------------------------------------- Spectre------------------------------------------------------------------------------>
#Spectre MOB START#
#Wraith Mob Scan/Allows Swaping naturally ###
#---Vault-Spectre Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawnspectre,tag=!summoned,tag=!invisible] run function voa:spectre/invisible
execute as @e[type=minecraft:armor_stand,tag=spawnspectre,tag=!summoned,tag=invisible] at @s if entity @a[distance=..20] run function voa:spectre/spawnspectre
execute as @e[type=minecraft:armor_stand,tag=spawnspectre,tag=summoned] at @s run kill @s

#Initializes Spectre Animation/Sound function
execute as @e[tag=spectre,type=minecraft:husk] at @s if entity @a[distance=0..40] run function voa:spectre/animate

#Runs Sounds
execute as @e[tag=spectre,type=minecraft:husk,scores={sound_cool=75},tag=frenzied] at @s if entity @a[distance=0..16] run playsound minecraft:spectre.mob.wail hostile @a[distance=0..16]
execute as @e[tag=spectre,type=minecraft:husk,scores={sound_cool=0},tag=frenzied] at @s if entity @a[distance=0..16] run scoreboard players set @s sound_cool 150
## Activates Cooldown functionality
scoreboard players remove @e[tag=spectre,type=minecraft:husk,scores={sound_cool=1..},tag=frenzied] sound_cool 1

#Runs Attack Function
execute as @e[tag=spectre,type=minecraft:husk,tag=!frenzied] at @s if entity @a[distance=..3] run function voa:spectre/attack
execute as @e[tag=spectre,type=minecraft:husk,tag=frenzied,sort=nearest,limit=1] at @s unless entity @a[distance=..12] run function voa:spectre/unfrenzy

#Armor-Stand Spawner
execute as @e[type=minecraft:armor_stand,tag=spawnspectre100,tag=!summoned] at @s run function voa:spectre/spectre_spawn_100
execute as @e[type=minecraft:armor_stand,tag=spawnspectre100,tag=summoned] at @s run kill @s
#End Spectre Mob#



#----------------------------------------------------------------------------------- Reaper------------------------------------------------------------------------------>
#Reaper MOB START#
#---Vault-Reaper Spawn#
execute as @e[type=minecraft:armor_stand,tag=spawnreaper,tag=!summoned] at @s if entity @a[distance=..20] run function voa:reaper/spawnreaper
execute as @e[type=minecraft:armor_stand,tag=spawnreaper,tag=summoned] at @s run kill @s

#Initializes Spectre Animation/Sound function
execute as @e[tag=reaper,type=minecraft:husk] at @s if entity @a[distance=0..50] run function voa:reaper/animate
#
##Runs Sounds
execute as @e[tag=reaper,type=minecraft:husk,scores={sound_cool=75},tag=frenzied] at @s if entity @a[distance=0..16] run playsound minecraft:reaper.mob.wail hostile @a[distance=0..16]
execute as @e[tag=reaper,type=minecraft:husk,scores={sound_cool=0},tag=frenzied] at @s if entity @a[distance=0..16] run scoreboard players set @s sound_cool 150
### Activates Cooldown functionality
scoreboard players remove @e[tag=reaper,type=minecraft:husk,scores={sound_cool=1..},tag=frenzied] sound_cool 1
#
##Runs Attack Function
execute as @e[tag=reaper,type=minecraft:husk,tag=!frenzied] at @s if entity @a[distance=..4] run function voa:reaper/attack
execute as @e[tag=reaper,type=minecraft:husk,tag=frenzied,sort=nearest,limit=1] at @s unless entity @a[distance=..12] run function voa:reaper/unfrenzy
#End Reaper Mob#



#----------------------------------------------------------------------------------- Flower/Boss Fight------------------------------------------------------------------------------>
#Boss MOB START#

##Phase 1 - Undamaged - Boss
execute at @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack] run particle minecraft:soul ~ ~ ~ 1 2 1 .2 5 normal
execute at @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack] run particle minecraft:effect ~ ~ ~ 2 3 2 .05 30 normal
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack] at @s if entity @a[distance=..4] run effect give @a[distance=..4] minecraft:wither 1 3

##Phase 2 - Shield - Boss
execute at @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=!casting] run particle minecraft:soul ~ ~ ~ .5 1 .5 .2 1 normal
execute at @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=!casting] run particle minecraft:effect ~ ~ ~ 1 2 1 .05 5 normal
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=!casting] at @s if entity @a[distance=..4] run effect give @a[distance=..3] minecraft:wither 1 4

##Phase 2 - Movement Animation - Boss
execute as @e[tag=boss,tag=phase2,tag=!casting,type=minecraft:husk] at @s if entity @a[distance=0..50] run function voa:boss/animate


#Phase One - AOE Potion Attack Timeline
execute at @e[tag=spook] if entity @e[type=husk,tag=boss,tag=phase1,scores={atk_cool=240}] run playsound minecraft:willowbee.mob.hurt ambient @a[distance=..36] ~ ~ ~ 2
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack,scores={atk_cool=120}] at @s if entity @a[distance=0..50] run function voa:boss/attack_phase1
execute at @e[tag=spook] if entity @e[type=husk,tag=boss,tag=phase1,scores={atk_cool=120}] run playsound minecraft:willowbee.mob.hurt ambient @a[distance=..36] ~ ~ ~ 2
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack,tag=potion2,scores={atk_cool=105}] at @s if entity @a[distance=0..50] run function voa:boss/attack_phase1_2
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack,tag=potion3,scores={atk_cool=90}] at @s if entity @a[distance=0..50] run function voa:boss/attack_phase1_3
execute at @e[tag=spook] if entity @e[type=husk,tag=boss,tag=phase1,scores={atk_cool=0}] run playsound minecraft:willowbee.mob.hurt ambient @a[distance=..36] ~ ~ ~ 2
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=canattack,scores={atk_cool=0}] at @s if entity @a[distance=0..50] run scoreboard players set @s atk_cool 240

#Long Range Attack - Down - Phase One
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={atk_cool=120}] at @s if entity @a[distance=12..50] run function voa:boss/attack_phase1


#Phase1 - Potion Attack
#Potion1
execute as @e[type=minecraft:armor_stand,tag=boss_potion] at @s run particle minecraft:squid_ink ~ ~ ~ .2 1 .2 .2 20 normal
#execute as @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=2}] at @s run summon potion ~ ~2 ~ {Item:{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_harming"}}}
execute as @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",Radius:3.5f,Duration:40,Color:6368406,Tags:["pot_atk"],Potion:"minecraft:strong_harming"}
execute as @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=1}] at @s run kill @s
#Potion2
execute as @e[type=minecraft:armor_stand,tag=boss_potion2] at @s run particle minecraft:squid_ink ~ ~ ~ .2 1 .2 .2 20 normal
#execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=2}] at @s run summon potion ~ ~2 ~ {Item:{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_harming"}}}
execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",Radius:3.5f,Duration:40,Color:6368406,Tags:["pot_atk"],Potion:"minecraft:strong_harming"}
execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",Radius:3.5f,Duration:40,Color:6368406,Tags:["pot_atk"],Potion:"minecraft:strong_harming"}
execute as @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=1}] at @s run kill @s
#Potion3
execute as @e[type=minecraft:armor_stand,tag=boss_potion3] at @s run particle minecraft:squid_ink ~ ~ ~ .2 1 .2 .2 20 normal
#execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon potion ~ ~2 ~ {Item:{id:"minecraft:splash_potion",Count:1b,tag:{Potion:"minecraft:strong_harming"}}}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",Radius:3.5f,Duration:40,Color:6368406,Tags:["pot_atk"],Potion:"minecraft:strong_harming"}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",Radius:3.5f,Duration:40,Color:6368406,Tags:["pot_atk"],Potion:"minecraft:strong_harming"}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=2}] at @s run summon area_effect_cloud ~ ~ ~ {Particle:"dragon_breath",Radius:3.5f,Duration:40,Color:6368406,Tags:["pot_atk"],Potion:"minecraft:strong_harming"}
execute as @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=1}] at @s run kill @s


#Phase2 - Tome Attack

#Casting - First Break
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run tag @s add casting
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=497}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run function voa:boss/phase2/tome_first_break
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:slowness 40 3
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:weakness 40 3
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=497}] at @s run effect give @s minecraft:slowness 40 3
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=480}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=480}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=460}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=460}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=440}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=440}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=420}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=420}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=casting,scores={atk_cool=401}] at @s run particle minecraft:soul_fire_flame ~ ~ ~ .5 1 .5 .2 20
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=401}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:slowness
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=401}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:weakness
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=401}] at @s run effect clear @s minecraft:slowness
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=401}] at @s run function voa:boss/phase2/tome_chaos
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=401}] at @s run function voa:boss/phase2/tome_harmony_cast
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=401}] at @s run tag @s remove tomec
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=401}] at @s run tag @s remove tomeh
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=400}] at @s run tag @s remove casting



#Casting - General Loop
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run tag @s add casting
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run function voa:boss/phase2/tome_choice
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:slowness 40 3
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s if entity @a[distance=..22] run effect give @a[distance=..22] minecraft:weakness 40 3
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=100}] at @s run effect give @s minecraft:slowness 40 3
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=80}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=60}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=40}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=20}] at @s run playsound minecraft:entity.illusioner.prepare_blindness ambient @a ~ ~ ~ 4
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:slowness
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s if entity @a[distance=..22] run effect clear @a[distance=..22] minecraft:weakness
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run effect clear @s minecraft:slowness


#Casting - Chaos Tome
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=99}] at @s run particle minecraft:entity_effect ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=99},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=80}] at @s run particle minecraft:entity_effect ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=80},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
#execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=60}] at @s run say chaos! 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=60}] at @s run particle minecraft:entity_effect ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=60},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=40}] at @s run particle minecraft:entity_effect ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=40},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=20}] at @s run particle minecraft:entity_effect ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=20},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1}] at @s run particle minecraft:entity_effect ~ ~ ~ .5 1 .5 .2 20
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1},distance=..22] run particle minecraft:dragon_breath ~ ~1 ~ .65 .5 .65 .0005 15
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1}] at @s run function voa:boss/phase2/tome_chaos
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomec,scores={atk_cool=1}] at @s run tag @s remove tomec

#Casting - Lucky Tome
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=99}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=80}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
#execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=60}] at @s run say lucky!
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=60}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=40}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=1}] at @s run particle minecraft:happy_villager ~ ~ ~ .5 1 .5 .2 20 
execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=1},distance=..40] run function voa:boss/phase2/tome_lucky
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomel,scores={atk_cool=1}] at @s run tag @s remove tomel
execute as @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=3}] at @s run effect give @a[distance=..5] minecraft:instant_damage 1 1
execute as @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=2}] at @s run summon fireball ~ ~ ~ {HasVisualFire:1b,ExplosionPower:1b,power:[0.0,-4.0,0.0]}
execute as @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=1}] at @s run kill @s

#Casting - Harmony Tome
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=99}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
#execute as @a[] at @s if entity @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=99},distance=..40] run function voa:boss/phase2/tome_harmony
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=80}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
#execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=60}] at @s run say harmony! 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=60}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=40}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=20}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=1}] at @s run particle minecraft:heart ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=1}] at @s run function voa:boss/phase2/tome_harmony_cast
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,tag=tomeh,scores={atk_cool=1}] at @s run tag @s remove tomeh


#Casting - General Loop - Continued
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s if entity @a[distance=..22] run tp @s @r[distance=..22]
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run particle minecraft:smoke ~ ~ ~ .5 1 .5 .2 20 
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=1}] at @s run tag @s remove casting
execute as @e[type=minecraft:husk,tag=boss,tag=phase2,tag=canattack,scores={atk_cool=0}] at @s run scoreboard players set @s atk_cool 400



##Triggers if all Spooks are dead - Phase One
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=!down] at @s unless entity @e[tag=spook,distance=..60] run function voa:boss/boss_down
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=200}] at @s if entity @a[distance=..4] run function voa:boss/attack_phase1_down
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=160}] at @s if entity @a[distance=..4] run function voa:boss/attack_phase1_down
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=120}] at @s if entity @a[distance=..4] run function voa:boss/attack_phase1_down
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=80}] at @s if entity @a[distance=..4] run function voa:boss/attack_phase1_down
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down,scores={boss_cool=40}] at @s if entity @a[distance=..4] run function voa:boss/attack_phase1_down
execute as @e[type=minecraft:husk,tag=boss,tag=down,scores={boss_cool=..1}] at @s run function voa:boss/boss_up
execute as @e[type=minecraft:husk,tag=boss,tag=phase1,tag=down] at @s run particle minecraft:bubble_column_up ~ ~ ~ 2 0 2 .2 100
#Phase One - Spook Particle Animation
execute as @e[tag=spook] at @s run particle minecraft:small_flame ~ ~-1 ~ .5 1 .5 .000005 5
#End Boss Mob#


####Boss Utilities
##Boss Bar
execute store result bossbar bossbar:flower value as @e[type=minecraft:husk,tag=boss,limit=1,sort=nearest] run data get entity @s Health
##Displaying Boss Bar
execute if entity @e[type=minecraft:husk,tag=boss] run bossbar set bossbar:flower visible true
execute unless entity @e[type=minecraft:husk,tag=boss] run bossbar set bossbar:flower visible false
execute unless entity @e[type=minecraft:husk,tag=boss] run bossbar set bossbar:flower players
##Displaying Distance for Boss Bar
execute at @e[type=minecraft:husk,tag=boss] run bossbar set bossbar:flower players @a[distance=..120]
#
##Gets Boss Health
data get entity @e[type=minecraft:husk,tag=boss,sort=nearest,limit=1] Health

#FIXXXXXXXXXXXXXXXXXXXXXXXXXXX THIS! ----------------------------------------------------------------------------------------------------VVVVV
#execute store result entity @e[type=minecraft:husk,tag=boss,sort=nearest,limit=1] Health
#
###Initializes Spectre Animation/Sound function
execute as @e[tag=boss,type=minecraft:husk] at @s if entity @a[distance=..24] run function voa:boss/hurt
#
###Scoreboards
scoreboard players remove @e[tag=boss,type=minecraft:husk,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[tag=boss,type=minecraft:husk,scores={boss_cool=1..}] boss_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion2,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion3,scores={atk_cool=1..}] atk_cool 1
#scoreboard players remove @e[type=minecraft:armor_stand,tag=boss_potion4,scores={atk_cool=1..}] atk_cool 1
scoreboard players remove @e[type=minecraft:bat,tag=lucky_bat,scores={atk_cool=1..}] atk_cool 1

