#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This marks the chunk as generated, and manipulates what happens with each chunk

#say SET CHUNKI

#Checks to see if chunk has been loaded previously or not.
fill ~ 1 ~ ~15 1 ~15 light[level=1]
fill ~ 0 ~ ~15 0 ~15 light[level=1]

#Can cleanup the RNG datapack to just use the lcg
#randomizer function - 
scoreboard players set in math 0
scoreboard players set in1 math 1000
function voa:natural_generation/random/range_lcg


#If 1 is selected, the following happens
execute if score out math matches 200 run function voa:surface_end
execute if score out math matches 900 run function voa:surface_end
