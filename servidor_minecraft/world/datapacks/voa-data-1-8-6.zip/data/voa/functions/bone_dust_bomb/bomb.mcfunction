#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks

#This function spawns an armor stand which we can use to run commands off of.
summon armor_stand ^ ^ ^0.5 {Small:1b,Invisible:1b,Tags:["player"]}

scoreboard players add @e[type=minecraft:armor_stand,tag=player] bdb_cool 0

playsound minecraft:entity.firework_rocket.blast master @a[]

kill @e[type=minecraft:snowball,sort=nearest,limit=1,nbt={Item:{tag:{bdb:1b}}}]
