#All of the code below is part of the Vaults of Abandon datapack created by BeagleBlocks
#Sounds
execute at @s run playsound minecraft:entity.firework_rocket.blast master @a[]

#Particles
execute at @s run particle minecraft:explosion ~ ~ ~ 3 3 3 .3 20 normal
execute at @s run particle minecraft:flash ~ ~ ~ 3 3 3 .0001 20 normal

#Explosion/effects
execute at @s run effect give @e[distance=0..8,type=!player] slowness 12 2
execute at @s run effect give @e[distance=0..8,type=!player] weakness 12 2
execute at @s run effect give @e[distance=0..8,type=player] speed 12 1

#Kills Snowball
execute at @s run kill @s

#B-E-A-G-L-E-B-L-O-C-K-S